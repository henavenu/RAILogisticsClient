"""
Adaptive HITL primitives for governed LangGraph applications.

Two helpers node authors and app authors use:

    evaluate(client, role, content, ...)
        Called from inside a LangGraph node. Runs the governance evaluation
        via the Policy Engine. On REQUIRE_HUMAN_REVIEW the SDK either pauses
        the graph via LangGraph's native ``interrupt()`` (per-node pause,
        checkpoint preserved, no re-run of preceding nodes) OR raises
        ``HITLInterrupt`` (whole-graph pause, exception model). The mode is
        chosen at call time based on the runtime capability probe. Node
        authors write one line and don't need to know which path is active.

    resume(graph, thread_id, decision, original_state=None, ...)
        Called by the app-level wrapper when the reviewer's decision arrives.
        Resumes the paused graph in whichever mode was used to pause. Callers
        write one line regardless of the underlying mechanism.

The capability probe (``can_use_native_interrupt``) checks four things:
    1. LangGraph >= 0.2 (``langgraph.types.interrupt`` importable).
    2. We are inside a node context (``get_config`` returns a config).
    3. A ``thread_id`` is set on that config.
    4. A checkpointer is active on the current run (visible as internal
       markers on ``config.configurable``).

Failing any of the four falls back silently to the exception path. This is
by design — different apps sit at different points on the LangGraph
maturity curve; the SDK adapts to what the app provides rather than
requiring every onboarded app to look like the demo.
"""
from __future__ import annotations

import json as _json
import logging
import os as _os
import threading as _threading
import urllib.request as _urlreq
import urllib.error as _urlerr
from typing import Any, Dict, List, Optional, Union

from rai_trust_sdk.client import TrustClient
from rai_trust_sdk.types  import (
    ContentRole,
    DirectiveAction,
    EnforcementMode,
    EvalMode,
    GovernanceResult,
    HITLInterrupt,
)

logger = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────────────
# PAP URL resolution (App↔Platform boundary)
# ────────────────────────────────────────────────────────────────────────────
# App code MUST NOT reach PAP directly. Apps call the three primitives at the
# bottom of this file (register_pending / query_pending_status / mark_completed)
# and the SDK owns the URL and the wire format.

_DEFAULT_PAP_URL = "http://127.0.0.1:3002"


def _resolve_pap_url(pap_url: Optional[str]) -> str:
    """Explicit arg > RAI_PAP_URL env > localhost fallback. Never derived
    from the PE base URL."""
    if pap_url:
        return pap_url.rstrip("/")
    env = _os.getenv("RAI_PAP_URL") or _os.getenv("PAP_URL")
    if env:
        return env.rstrip("/")
    return _DEFAULT_PAP_URL


# ────────────────────────────────────────────────────────────────────────────
# Capability probe
# ────────────────────────────────────────────────────────────────────────────

def _import_native_interrupt():
    """Return ``langgraph.types.interrupt`` if importable; else ``None``."""
    try:
        from langgraph.types import interrupt
        return interrupt
    except Exception:
        return None


def _import_native_command():
    """Return ``langgraph.types.Command`` if importable; else ``None``."""
    try:
        from langgraph.types import Command
        return Command
    except Exception:
        return None


def _current_langgraph_config() -> Optional[Dict[str, Any]]:
    """
    Return the ``RunnableConfig`` LangGraph is threading through the current
    node call, or ``None`` if we are not inside a node execution context.

    Falls through the two known accessors — the modern ``get_config`` in
    ``langgraph.config`` and the legacy ``ensure_config`` in
    ``langgraph.utils.config``. Both raise when called outside a node.
    """
    # Modern API (LangGraph >= 0.2)
    try:
        from langgraph.config import get_config
        return get_config()
    except Exception:
        pass
    # Legacy fallback
    try:
        from langgraph.utils.config import ensure_config   # type: ignore
        return ensure_config()
    except Exception:
        return None


# Configurable-config keys that LangGraph populates ONLY when a checkpointer
# is active on the current run. Any one of these being present is our best
# cross-version signal that the graph is checkpoint-backed.
_CHECKPOINTER_CONFIG_MARKERS = (
    "__pregel_checkpointer_get_next_version",
    "checkpoint_ns",
    "checkpoint_id",
    "checkpoint_map",
)


def can_use_native_interrupt(config: Optional[Dict[str, Any]] = None) -> bool:
    """
    Probe: can native ``interrupt()`` be used at the current call site?

    Requires all four:
        1. ``langgraph.types.interrupt`` is importable.
        2. We are inside a node execution (config is available).
        3. A ``thread_id`` is set on ``config.configurable``.
        4. A checkpointer is active on the current run.

    Any failure returns ``False``. Never raises. Cheap to call — no I/O.
    """
    if _import_native_interrupt() is None:
        return False
    cfg = config if config is not None else _current_langgraph_config()
    if not cfg:
        return False
    conf = (cfg.get("configurable") or {}) if isinstance(cfg, dict) else {}
    if not conf.get("thread_id"):
        return False
    if not any(m in conf for m in _CHECKPOINTER_CONFIG_MARKERS):
        return False
    return True


def graph_has_checkpointer(graph: Any) -> bool:
    """Best-effort probe on a compiled graph object. Used by ``resume``."""
    # LangGraph 0.2+ exposes .checkpointer on CompiledStateGraph.
    # Older versions used _checkpointer. Check both.
    for attr in ("checkpointer", "_checkpointer"):
        if getattr(graph, attr, None):
            return True
    return False


def _get_checkpointer_saver(graph: Any):
    """Return the underlying checkpointer object on ``graph``, or None."""
    for attr in ("checkpointer", "_checkpointer"):
        saver = getattr(graph, attr, None)
        if saver:
            return saver
    return None


def checkpoint_exists(graph: Any, thread_id: str) -> bool:
    """
    Does the checkpointer actually hold a checkpoint for this thread_id?

    A checkpointer being CONFIGURED (``graph_has_checkpointer``) is not
    enough — a checkpoint is only written when native ``interrupt()`` fires
    inside a node. A HITL that fires at Layer 1 (user prompt, before any
    node runs) never reaches a node, so no checkpoint gets written. ``resume``
    must probe for the actual checkpoint before choosing the native path.
    """
    saver = _get_checkpointer_saver(graph)
    if saver is None:
        return False
    cfg = {"configurable": {"thread_id": thread_id}}
    try:
        tup = saver.get_tuple(cfg)
        return tup is not None
    except Exception as exc:
        logger.debug("checkpoint_exists probe error for %s: %s", thread_id, type(exc).__name__)
        return False


# ────────────────────────────────────────────────────────────────────────────
# The two helpers
# ────────────────────────────────────────────────────────────────────────────

def evaluate(
    client:            TrustClient,
    role:              Union[str, ContentRole],
    content:           str,
    *,
    session_id:        Optional[str] = None,
    metadata:          Optional[Dict[str, Any]] = None,
    eval_mode:         EvalMode = EvalMode.SYNC,
    enforcement_mode:  Optional[EnforcementMode] = None,
) -> GovernanceResult:
    """
    Governance evaluation with adaptive HITL.

    Call this from inside a LangGraph node whenever an act needs review.
    The result carries the verdict, violations, remediation, and (in native
    mode after a resume) the reviewer's decision on ``result.decision``.

    Behaviour:

    * **No HITL directive** — returns the ``GovernanceResult`` normally.
    * **HITL directive + native available** — calls
      ``langgraph.types.interrupt(payload)``. LangGraph pauses the graph at
      the current line, checkpoints the whole state, and returns from
      ``graph.invoke()`` with an ``__interrupt__`` marker in the output.
      When the app later calls ``resume(...)`` with the reviewer's decision,
      ``interrupt()`` returns that decision here and this function attaches
      it as ``result.decision`` before returning.
    * **HITL directive + native NOT available** — raises ``HITLInterrupt``
      with the same payload. The app's ``except HITLInterrupt`` block does
      its own pause bookkeeping (registers with PAP, stores the input to
      resume from later) and re-invokes on approval.

    Node authors write one line; they do not need to know which path is
    active.
    """
    if isinstance(role, str):
        role = ContentRole(role)

    result = client.evaluate(
        content         = content,
        role            = role,
        session_id      = session_id,
        eval_mode       = eval_mode,
        enforcement_mode= enforcement_mode,
        metadata        = metadata,
        raise_on_block  = True,      # unchanged for COERCIVE flow
    )

    directive = _hitl_directive(result)
    if directive is None:
        return result

    payload = _build_payload(result, directive, role, session_id)

    if can_use_native_interrupt():
        native_interrupt = _import_native_interrupt()
        logger.info(
            "hitl.evaluate: native interrupt() path (thread_id=%s, category=%s)",
            session_id, payload.get("category"),
        )
        # interrupt() pauses HERE. When Command(resume=<value>) fires against
        # this thread_id, interrupt() returns <value>.
        decision = native_interrupt(payload)
        # Attach for node-side branch logic. Downstream code can now do:
        #    if result.decision == "approved": ...
        try:
            setattr(result, "decision", decision if isinstance(decision, str) else str(decision))
        except Exception:
            pass
        return result

    # Fallback mode
    logger.info(
        "hitl.evaluate: exception (HITLInterrupt) path — no native interrupt available "
        "(thread_id=%s, category=%s)",
        session_id, payload.get("category"),
    )
    raise HITLInterrupt(payload)


def resume(
    graph:           Any,
    thread_id:       str,
    decision:        Any,
    *,
    original_state:  Optional[Dict[str, Any]] = None,
    config:          Optional[Dict[str, Any]] = None,
) -> Any:
    """
    Resume a paused graph with the reviewer's decision.

    Native path (checkpointer active on the graph):
        graph.invoke(Command(resume=decision),
                     config={"configurable": {"thread_id": thread_id}})

        LangGraph rehydrates state from the checkpointer and continues from
        the interrupted line inside the paused node. The decision value
        becomes the return value of ``interrupt()`` at that line.

    Exception path (no checkpointer):
        graph._hitl_cleared_sessions.add(thread_id)
        graph.invoke(original_state)

        Requires ``original_state`` — the input the graph was originally
        invoked with. This is what MyBank (or any app on the exception path)
        must serialise to its own durable store before the pause.

    Returns whatever the graph returns. Raises ``ValueError`` when we take
    the exception path but ``original_state`` was not supplied.
    """
    # Native path requires BOTH: checkpointer configured AND an actual
    # checkpoint present for this thread. A HITL that fires at Layer 1
    # (user prompt, before any node) reaches no interrupt() call, so no
    # checkpoint gets written even when a checkpointer is configured. In
    # that case we fall through to the exception path.
    if graph_has_checkpointer(graph) and checkpoint_exists(graph, thread_id):
        Command = _import_native_command()
        if Command is None:
            raise RuntimeError(
                "graph has a checkpointer but langgraph.types.Command is not "
                "importable — upgrade LangGraph to >= 0.2 or install the "
                "correct wheel"
            )
        cfg = config or {"configurable": {"thread_id": thread_id}}
        logger.info("hitl.resume: native path (Command.resume) thread_id=%s", thread_id)
        return graph.invoke(Command(resume=decision), config=cfg)

    if original_state is None:
        raise ValueError(
            "resume() requires original_state when there is no native "
            "checkpoint for this thread_id — this happens when the HITL "
            "was raised outside a node (Layer 1) even though the graph "
            "has a checkpointer configured"
        )
    cleared = getattr(graph, "_hitl_cleared_sessions", None)
    if cleared is None:
        # Not a GovernedGraph — nothing to clear. Warn and continue.
        logger.warning(
            "hitl.resume: exception path but graph has no _hitl_cleared_sessions "
            "attribute; the HITL check may re-fire on the next evaluate. "
            "Was the graph wrapped with instrument()?"
        )
    else:
        cleared.add(thread_id)
    # If the graph has a checkpointer, EVERY invoke needs a config with
    # thread_id — LangGraph errors otherwise. We pass one so the run
    # starts writing checkpoints under this thread from now on, even
    # though we're taking the exception path.
    cfg = config or {"configurable": {"thread_id": thread_id}} if graph_has_checkpointer(graph) else None
    logger.info("hitl.resume: exception path (re-invoke + cleared_sessions) thread_id=%s", thread_id)
    if cfg is not None:
        return graph.invoke(original_state, config=cfg)
    return graph.invoke(original_state)


# ────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ────────────────────────────────────────────────────────────────────────────

def _hitl_directive(result: GovernanceResult):
    """Return the REQUIRE_HUMAN_REVIEW directive if present, else None."""
    if not result.directives:
        return None
    for d in result.directives:
        if d.action == DirectiveAction.REQUIRE_HUMAN_REVIEW:
            return d
    return None


def _build_payload(
    result:     GovernanceResult,
    directive:  Any,
    role:       ContentRole,
    session_id: Optional[str],
) -> Dict[str, Any]:
    """Assemble the interrupt / HITLInterrupt payload.

    Includes a `pattern` field the SDK sets deterministically from the layer
    that raised HITL, so the app can render the right UX without inferring:

      * "gate"    — HITL fired at the user_prompt layer, BEFORE any node ran.
                    The graph hasn't started; nothing is suspended. On approve,
                    the graph is re-invoked with the original state.
      * "suspend" — HITL fired mid-graph (tool_call / llm_response /
                    agent_to_agent), INSIDE a running node. The graph state
                    is captured by the checkpointer at the exact interrupt()
                    line; Command(resume=<decision>) continues from that line
                    on approve. Upstream nodes do NOT re-run.
    """
    pattern = "gate" if role == ContentRole.USER_PROMPT else "suspend"
    return {
        "pattern":    pattern,
        "reason":     directive.reason or "governance_review_required",
        "category":   directive.category.value if directive.category else None,
        "options":    list(directive.options or []),
        "source":     directive.source.value,
        "role":       role.value,
        "verdict":    result.verdict.value,
        "violations": list(result.violations or []),
        "session_id": session_id or "",
    }


# ────────────────────────────────────────────────────────────────────────────
# App-side reviewer-queue primitives
# ────────────────────────────────────────────────────────────────────────────
# These three primitives are the ONLY way a governed app should touch the
# reviewer queue that lives on PAP. Apps must never call PAP directly — the
# App↔Platform boundary rule says the SDK is the single interface. Apps
# import from `rai_sdk_langgraph.hitl` and call:
#
#     hitl.register_pending(session_id, payload, app_id=...)
#     row = hitl.query_pending_status(thread_id)
#     hitl.mark_completed(thread_id)
#
# The SDK owns the URL, the wire format, and the fire-and-forget default,
# so the app never has to know that PAP exists as an HTTP service.

def register_pending(
    session_id:      str,
    payload:         Dict[str, Any],
    *,
    app_id:          Optional[str]  = None,
    pap_url:         Optional[str]  = None,
    fire_and_forget: bool           = True,
    timeout:         float          = 5.0,
) -> None:
    """REMOVED 2026-09-21. HITL registration is a PLATFORM responsibility, not the
    SDK's. The Policy Engine records the review item itself — on every
    REQUIRE_HUMAN_REVIEW directive (pack, coordinator, or sentinel) — and the PAP
    builds the reviewer queue from that signal. The app/SDK no longer posts HITL to
    PAP. This stub fails loudly so any lingering caller is found and removed; there
    is no silent fallback.

    Note: reading the reviewer's decision to resume a suspended graph is STILL the
    app's job — use query_pending_status() / mark_completed(). Only the WRITE moved
    server-side.
    """
    raise RuntimeError(
        "rai_sdk_langgraph.hitl.register_pending is removed — HITL registration is "
        "server-side now (the Policy Engine records it; the PAP queues it). The "
        "SDK/app no longer publishes HITL. Delete this call."
    )


def query_pending_status(
    thread_id:  str,
    *,
    pap_url:    Optional[str] = None,
    timeout:    float         = 5.0,
) -> Optional[Dict[str, Any]]:
    """
    Fetch the current reviewer state for a single pending item.

    Returns the item dict on 2xx, or ``None`` when the item is unknown or
    the request failed. The item dict shape is defined by PAP GET
    ``/v1/hitl/{session_id}`` — typically ``{status, decision, reviewer,
    resolved_at, ...}``.

    Used by discovery / reconciliation on customer login and by the client
    polling loop. Callers should treat ``None`` as "no change" and try
    again later — never as a permanent failure.
    """
    base = _resolve_pap_url(pap_url)
    url  = f"{base}/v1/hitl/{thread_id}"
    try:
        req = _urlreq.Request(url, method="GET")
        with _urlreq.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode() or "{}"
            return _json.loads(body)
    except _urlerr.HTTPError as exc:
        if exc.code == 404:
            return None
        logger.warning(
            "hitl.query_pending_status: HTTP %s for thread %s", exc.code, thread_id,
        )
        return None
    except Exception as exc:
        logger.warning(
            "hitl.query_pending_status: failed for thread %s — %s", thread_id, exc,
        )
        return None


def mark_completed(
    thread_id:  str,
    *,
    pap_url:    Optional[str] = None,
    timeout:    float         = 5.0,
) -> bool:
    """
    Remove a resolved item from the reviewer queue.

    Called after the app has finished acting on the reviewer's decision
    (the customer has seen the outcome and the graph has either resumed or
    been dropped). Returns True on 2xx, False otherwise. Idempotent —
    calling twice is safe; the second call just returns False.

    Uses PAP DELETE ``/v1/hitl/{session_id}`` (dismiss-a-single-item).
    """
    base = _resolve_pap_url(pap_url)
    url  = f"{base}/v1/hitl/{thread_id}"
    try:
        req = _urlreq.Request(url, method="DELETE")
        with _urlreq.urlopen(req, timeout=timeout):
            logger.info("hitl.mark_completed: dismissed thread %s from PAP queue", thread_id)
            return True
    except Exception as exc:
        logger.warning(
            "hitl.mark_completed: failed for thread %s — %s", thread_id, exc,
        )
        return False
