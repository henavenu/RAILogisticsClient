"""
instrument() — zero-touch governance wrapper for compiled LangGraph apps.

The entire SDK integration for a LangGraph application is:

    from rai_sdk_langgraph import instrument

    app = instrument(app, base_url="http://pe:3000", app_id="myapp")

    # With REDACT (default) — no exception handling needed:
    result = app.invoke(state)

    # With RAISE (opt-in) — full block detail available:
    from rai_trust_sdk import GovernanceBlock
    try:
        result = app.invoke(state)
    except GovernanceBlock as e:
        print(e.result.violations)

Three governance layers are injected automatically — no changes to nodes,
tools, or graph definition required:

  Layer 1 · USER_PROMPT  — evaluated before the graph runs
            Catches prompt injection before any agent logic executes.

  Layer 2 · TOOL_CALL    — evaluated before sensitive tools execute
            Catches sanctions hits, AML patterns, and policy violations
            at the moment of execution, not just at intent time.

  Layer 3 · LLM_RESPONSE — evaluated after the graph completes
            Catches PII leakage and hallucinated data before delivery.

EnforcementMode controls what happens on a COERCIVE verdict:

  NONE    — log only, execution continues unchanged (shadow/audit mode)
  REDACT  — substitute a safe refusal message; no exception raised (default)
  RAISE   — raise GovernanceBlock; application must catch it (opt-in)
"""
from __future__ import annotations

import contextvars
import functools
import logging
import os
import re
import threading
import uuid
from typing import Any, Callable, Dict, List, Optional, Set, Tuple
from uuid import UUID

import httpx

# Sentinel: distinguishes "privacy_proxy omitted" (→ env RAI_PRIVACY_PROXY, else OFF) from an
# explicit privacy_proxy=None (→ force the proxy OFF, ignoring env). See instrument().
_UNSET = object()

from rai_trust_sdk.client import TrustClient
from rai_trust_sdk.config import RaiConfig
from rai_trust_sdk.types import (
    ContentRole,
    DirectiveAction,
    EnforcementMode,
    EvalMode,
    GovernanceBlock,
    GovernanceHold,
    GovernanceResult,
    HITLInterrupt,
    AgentEvicted,
    PolicyUnavailable,
    ResponseParseError,
    Verdict,
    validate_modes as _validate_modes,   # shared self-test (single source of truth)
    _DIRECTIVE_PRIORITY,
)

# ── LangChain BaseCallbackHandler (optional but strongly recommended) ──────────
# Inheriting from BaseCallbackHandler ensures that LangChain's CallbackManager
# registers this handler into self.handlers for ALL event types — including
# on_llm_end, which is dispatched through CallbackManager.on_chat_model_start()
# and requires a proper BaseCallbackHandler instance.
#
# Without inheritance, on_tool_start works (BaseTool dispatches via duck typing)
# but on_llm_end is silently dropped, so token counts never accumulate.
try:
    from langchain_core.callbacks import BaseCallbackHandler as _LCBaseHandler
    _CALLBACK_BASE: Any = _LCBaseHandler
except ImportError:
    _CALLBACK_BASE = object  # Graceful degradation: token counting disabled

logger = logging.getLogger(__name__)

# Matches snake_case node names used in LangGraph (e.g. router, intl_wire_agent)
# Excludes CamelCase LangChain internals (ChatGroq, RunnableSequence, etc.)
_NODE_NAME_RE = re.compile(r'^[a-z][a-z0-9_]*$')

# create_react_agent names its internal subgraph nodes 'agent' (the model call) and
# 'tools' EVERY time. These match _NODE_NAME_RE but are NOT a top-level agent identity:
# the authoritative owner is the outermost segment of langgraph_checkpoint_ns (resolved
# by _owner_node). When a chain-start carries one of these as serialized['name'], it must
# NOT overwrite that owner — otherwise agent_id/agent_name collapse to the literal "agent"
# and topology typing degrades to "unknown" (the real node's llm_calls stay 0, so
# _classify_node returns UNKNOWN). A real top-level node of the same name still resolves
# via the _owner_node (checkpoint_ns) path, which is unaffected by this guard.
_REACT_INTERNAL_NODES = frozenset({"agent", "tools"})

# ── Agent-as-tool identity: the stack of tools executing in THIS execution context ──
# ((tool_name, caller), ...), innermost last. Read to answer one question: "is some
# tool executing right now, and if so which?" — because reasoning observed beneath a
# tool's execution means that tool IS an agent (Pattern A: the handoff is a tool call,
# not an edge, so a sub-agent is never a graph node and node-seeded discovery is
# structurally blind to it).
#
# A ContextVar, after three weaker keys were measured and rejected:
#   • langgraph_checkpoint_ns — MEASURED IDENTICAL for a tool and the nested tool its
#     sub-agent calls ('agent_00:…|tools:8ec5c743' for BOTH ask_agent_04 and
#     agent_04_stance), and shared by every tool in a ToolNode batch. Cannot name a
#     tool at all; the whole batch raced for one key.
#   • run_id tree — a sub-agent's .invoke() starts its OWN callback tree, so
#     parent_run_id never links back to the calling tool.
#   • thread id — MEASURED to lose the stack exactly where it matters: LangGraph
#     dispatches a sub-agent's own tool onto a FRESH thread (ask_agent_04 on thread
#     47368 → agent_04_stance on 11708), so the nested tool saw an empty stack and
#     fell back to the ns, crediting the COORDINATOR with its reviewers' tool execs.
#     It would also alias silently if the executor ever reused a pooled thread.
# LangGraph hops threads via copy_context(), so a ContextVar rides the hop, and each
# concurrent branch mutates its own copy — no cross-talk between 49 sibling tools, and
# no leak back to the caller's context. (Verified against langgraph 1.1.6.)
_TOOL_STACK: contextvars.ContextVar = contextvars.ContextVar("rai_tool_stack", default=())

# ── Non-heuristic agent discovery (behavioral classification) ─────────────────
# Classifies each LangGraph node by what it DOES at runtime — does it invoke an
# LLM? execute a tool? decide control flow? — rather than by name heuristics.
# The defining discriminator: an AGENT reasons via an LLM and does the work; a
# ROUTER only decides where the work goes. See SDK_Agent_Discovery_Design.md.
#
# "by what it DOES at runtime" is a promise this module OWES and did not always
# keep. `is_subgraph -> AGENT` was a purely STRUCTURAL rule wearing a behavioral
# docstring: it graded a node on how it was BUILT, so a compiled subgraph whose
# only node is `lambda s: {}` classified `agent` on evidence byte-identical to a
# real one. Structure is not agency. AGENT is now only ever reached through an
# OBSERVED llm_call; `is_subgraph` survives solely as corroborating agency
# evidence for a node that demonstrably reasoned.
#
# ADDITIVE: this runs ALONGSIDE the legacy agent_nodes/a2a_tools path; that path
# stays intact until the 50-agent harness validates discovery and the A2A cruft
# is pruned. Classification is observe-only and changes no enforcement behavior.
AGENT_KIND       = "agent"        # LLM + agency (tools / loop / subgraph) — a governed peer
LLM_UTILITY_KIND = "llm_utility"  # LLM, single-shot, no agency (summarizer / extractor)
ROUTER_KIND      = "router"       # decides control flow (LLM or rule) — not a peer
TOOL_KIND        = "tool"         # executes a tool, no LLM
FUNCTION_KIND    = "function"     # deterministic transform, no LLM / no tool
UNKNOWN_KIND     = "unknown"      # not yet observed and no static signal


def _new_node_evidence() -> Dict[str, Any]:
    """Per-node evidence record accumulated across executions (see _classify_node)."""
    return {
        # A "did this node run at all?" signal, NOT a run count — read only as >0.
        # It counts chain-starts attributed to this node, and a nested agent fires
        # many per execution (MEASURED: pattern_c's coordinator shows 71 across 9
        # LLM calls), so the magnitude means nothing. Named 'executions' before it
        # was wired to the ownership chain; the name now overstates it.
        "executions":            0,      # chain-starts owned by this node (>0 == ran)
        "llm_calls":             0,      # on_chat_model_start / on_llm_start fired here (S1)
        "tool_execs":            0,      # on_tool_start fired here, no LLM (S3)
        "emitted_tool_calls":    0,      # node emitted AIMessage with tool_calls (S2 → agency)
        "emitted_toolmsg":       0,      # node emitted ToolMessage (S4)
        "is_subgraph":           False,  # static: node target is a compiled subgraph (S6)
        "is_tool_node":          False,  # static: node IS a ToolNode (S7)
        "tools_bound":           False,  # static: node's model has tools bound (S9)
        "feeds_conditional_edge": False, # static: node output drives a conditional edge (Sr)
        "override":              None,    # explicit @rai_agent / declaration (S10 — locks result)
    }


def _classify_node(ev: Dict[str, Any]) -> str:
    """
    Fuse evidence into a node kind. Precedence: override ▶ runtime behavioral ▶
    static structural. Runtime wins because it is what the node ACTUALLY did on
    the stable langchain-core callback contract; static only seeds unrun nodes.

    AGENT REQUIRES OBSERVED REASONING — structure alone never yields it.
    There used to be a static `is_subgraph -> AGENT` rule here, and it meant
    `kind='agent'` actually asserted "is a compiled subgraph", not "reasons".
    MEASURED: a hollow `lambda s: {}` subgraph classified `agent` on evidence
    identical to a real one, and pattern_c's 45 never-executed spares were all
    graded `agent` — a 50/50 that was structurally incapable of going lower.
    A metric that cannot tell a real agent from an empty one measures nothing.

    The consequence is deliberate: DISCOVERY IS INCREMENTAL. An agent earns the
    label by running. An unrun node is UNKNOWN — honestly absent, not
    optimistically present — so an app that never ran reports zero agents. That
    is the correct answer to "which agents have we observed?", not a regression.
    """
    if ev.get("override"):
        return ev["override"]                                    # S10 — locked
    if ev.get("llm_calls", 0) > 0:                               # LLM observed → LLM-class
        if ev.get("feeds_conditional_edge") and not ev.get("emitted_tool_calls"):
            return ROUTER_KIND                                   # LLM router (control-flow output)
        if ev.get("emitted_tool_calls") or ev.get("is_subgraph") or ev.get("tools_bound"):
            return AGENT_KIND                                    # reasons + has agency
        return LLM_UTILITY_KIND                                  # single-shot LLM, no agency
    # NOTE: no `is_subgraph -> AGENT` fallback. Being a subgraph is structure;
    # agency is behavior. A subgraph that never reasoned is not an agent yet.
    if ev.get("is_tool_node") or ev.get("tool_execs", 0) > 0:    # static ToolNode / runtime tool
        return TOOL_KIND
    if ev.get("feeds_conditional_edge"):                         # static: conditional-edge source, no LLM
        return ROUTER_KIND
    if ev.get("executions", 0) > 0:                             # ran, nothing else observed
        return FUNCTION_KIND
    return UNKNOWN_KIND                                          # unrun + no structural signal


def _derive_a2a_edges(
    kinds: Dict[str, str],
    adjacency: Dict[str, List[str]],
    executed: Optional[Set[str]] = None,
) -> List[Dict[str, Any]]:
    """
    DECLARED agent-to-agent handoffs — derived from the graph's STATIC topology
    plus the classified agent set. This answers **"A may hand off to B"**. It is
    not, and must never be read as, evidence that any handoff occurred: see
    ``GovernedGraph.observed_edges`` for **"A DID hand off to B"**. The two are
    reported separately and never merged — their DIVERGENCE (declared but never
    exercised / exercised but never declared) is the governance signal.

    An edge A->B is a declared handoff when both are AGENTs — directly, or through
    'transparent' plumbing (ROUTER / FUNCTION) which is collapsed and reported as
    the 'via'. TOOL / LLM_UTILITY / UNKNOWN nodes are NOT traversed through (a path
    that runs through them is not a direct agent handoff).

    COLLAPSING THROUGH A NODE REQUIRES THAT THE NODE ACTUALLY RAN (`executed`).
    Calling a node 'transparent plumbing' is an INFERENCE about its behavior, and
    an unrun node's kind is only a static guess — traversing through a guess
    manufactures handoffs out of nothing. MEASURED in pattern_b: every reviewer
    carries feeds_conditional_edge=True seeded from its declared `destinations=`,
    so a reviewer that NEVER RAN classified ROUTER on zero runtime evidence and
    was traversed straight through, fabricating
        agent_00 -> agent_00  via=router  path=['agent_49']
    — a self-handoff that never happened. It scales the wrong way: the more agents
    you declare and the fewer you exercise, the more phantoms, i.e. worst exactly
    at production scale. `executed=None` disables the gate (legacy callers).

    Returns [{"from", "to", "via": "direct"|"router"|"function", "path": [...]}].
    """
    transparent = {ROUTER_KIND, FUNCTION_KIND}
    out: List[Dict[str, Any]] = []
    for a in [n for n, k in kinds.items() if k == AGENT_KIND]:
        seen: Set[str] = set()
        stack: List[tuple] = [(nxt, []) for nxt in adjacency.get(a, [])]
        while stack:
            node, via = stack.pop()
            if node in seen:
                continue
            seen.add(node)
            k = kinds.get(node, UNKNOWN_KIND)
            if k == AGENT_KIND:
                if any(kinds.get(v) == ROUTER_KIND for v in via):
                    vt = "router"
                elif via:
                    vt = "function"
                else:
                    vt = "direct"
                out.append({"from": a, "to": node, "via": vt, "path": list(via)})
            elif k in transparent and (executed is None or node in executed):
                for nxt in adjacency.get(node, []):
                    stack.append((nxt, via + [node]))
    return out


def _node_ran(ev: Dict[str, Any]) -> bool:
    """Did we OBSERVE this node do anything? (Any runtime signal at all.)"""
    return bool(ev.get("executions", 0) or ev.get("llm_calls", 0)
                or ev.get("tool_execs", 0) or ev.get("emitted_tool_calls", 0)
                or ev.get("emitted_toolmsg", 0))


# ── Observed control transfer: Command(goto=...) ──────────────────────────────
# MEASURED (langgraph 1.x / langchain-core 1.2.28), because the SDK spent months
# assuming otherwise — that a handoff which is a graph edge carries no tool call
# and is therefore unobservable:
#
#   • a NODE returning Command(goto='rev')  -> on_chain_end(outputs=<Command>)  ✔
#   • a TOOL returning Command(goto='rev')  -> on_tool_end(output=<Command>)    ✔
#
# Both hand us the real target on `.goto`. The transfer was ALWAYS observable;
# nobody looked. `destinations=` / `Command[Literal[...]]` is an OPTIONAL author
# annotation, and reading edges off it means governance cannot distinguish "these
# two agents talked" from "a developer wrote a type annotation".
try:
    from langgraph.types import Command as _Command
except Exception:                                    # pragma: no cover
    _Command = None                                  # type: ignore[assignment]


def _command_targets(payload: Any) -> List[str]:
    """
    The node name(s) a returned Command transfers control to — the OBSERVED
    target. Handles goto as a str, a list, or Send(node=...). Internal sentinels
    ('__end__', '__start__') are dropped: ending is not a handoff to a peer.
    """
    if _Command is not None and not isinstance(payload, _Command):
        return []
    goto = getattr(payload, "goto", None)
    if goto is None:
        return []
    items = goto if isinstance(goto, (list, tuple)) else [goto]
    out: List[str] = []
    for g in items:
        name = g if isinstance(g, str) else getattr(g, "node", None)   # Send(node=…)
        if isinstance(name, str) and name and not name.startswith("__"):
            out.append(name)
    return out


def _env_truthy(name: str) -> bool:
    """True when an environment flag is set to a truthy value (1/true/yes/on).

    Used for the demo-safe, default-OFF feature flags the hardening branch reads
    directly from the environment (e.g. RAI_GOVERN_HANDOFFS) — matching the
    RAI_GOVERN_RETURNS convention in mybank_clean/server.py. Reading the env here
    (rather than requiring the host app to thread a bool through instrument()) lets
    a flag be honoured with edits confined to this module.
    """
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


# Safe refusal text injected when REDACT mode blocks content.
_REDACT_COERCIVE = (
    "I'm sorry, I'm unable to process that request as it doesn't comply "
    "with our policies. Please contact support if you believe this is an error."
)


# ── Public entry point ────────────────────────────────────────────────────────

def _coerce_govern_roles(govern_roles):
    """None → govern all interception points. Otherwise a set of ContentRole
    (accepts either ContentRole members or their string values, e.g. 'tool_call')."""
    if govern_roles is None:
        return None
    return {r if isinstance(r, ContentRole) else ContentRole(str(r)) for r in govern_roles}


def _role_governed(govern_roles, role) -> bool:
    """True if this interception point is in scope. None = govern everything."""
    return govern_roles is None or role in govern_roles


def instrument(
    graph: Any,
    *,
    base_url: Optional[str] = None,
    app_id: str,
    api_key: Optional[str] = None,
    app_key: Optional[str] = None,
    pap_url: Optional[str] = None,
    tool_filter: Optional[List[str]] = None,
    govern_roles: Optional[List[str]] = None,
    agent_nodes: Optional[List[str]] = None,
    a2a_tools: Optional[Dict[str, str]] = None,
    eval_mode: Optional[EvalMode] = None,
    enforcement_mode: Optional[EnforcementMode] = None,
    on_block: Optional[str] = None,
    on_result: Optional[Callable[[GovernanceResult, ContentRole], None]] = None,
    timeout: Optional[float] = None,
    otel_endpoint: Optional[str] = None,
    otel_protocol: Optional[str] = None,
    privacy_proxy: Any = _UNSET,
    privacy_config: Optional[Any] = None,
    hitl_on_normative_a2a: bool = False,
    hitl_normative_threshold: int = 2,
    govern_returns: Optional[bool] = None,
    govern_handoffs: Optional[bool] = None,
    config: Optional["RaiConfig"] = None,
) -> "GovernedGraph":
    """
    Wrap a compiled LangGraph app with RAI Trust Platform governance.

    Parameters
    ──────────
    graph
        A compiled LangGraph ``StateGraph`` (the object returned by
        ``graph.compile()``).
    base_url : str
        Base URL of the Policy Engine, e.g. ``"http://localhost:3000"``.
    app_id : str
        Application identifier used to scope policy pack selection.
    api_key : str, optional
        Bearer token for Trust Platform authentication.
    tool_filter : list[str], optional
        When provided, Layer 2 evaluation is restricted to only these tool
        names.  When omitted (default), ALL tool calls are evaluated.
    agent_nodes : list[str], optional
        Names of LangGraph nodes whose working context should be evaluated
        as ``AGENT_TO_AGENT`` when they start executing.  Used for
        ``on_chain_start``-based detection (LangGraph version-dependent).
        Pair with ``a2a_tools`` for guaranteed detection across all versions.
        Example: ``agent_nodes=["intl_wire_agent"]``.
    a2a_tools : dict[str, str], optional
        Mapping of ``{tool_name: agent_name}`` that identifies which tools
        represent an agent-to-agent handoff point.  When a listed tool fires,
        an ``AGENT_TO_AGENT`` evaluation is triggered **before** the normal
        ``TOOL_CALL`` evaluation using the tool's input as the working context.
        This is the most reliable A2A trigger across all LangGraph versions
        because it hooks into ``on_tool_start``, which is guaranteed to fire.
        Example: ``a2a_tools={"international_transfer": "intl_wire_agent"}``.
    eval_mode : EvalMode
        ``SYNC`` (default): wait for verdict before proceeding.
        ``ASYNC``: fire-and-log, enforcement_mode is ignored.
    enforcement_mode : EnforcementMode
        Controls what happens when a COERCIVE verdict is returned.

        ``REDACT`` (default): substitute a safe refusal message transparently —
        no exception raised, no error handling required in application code.

        ``RAISE``: raise ``GovernanceBlock`` on COERCIVE verdicts.
        Use this when your application wants to display rich block details
        (violations list, verdict, request_id) in the UI.

        ``NONE``: *(deprecated — use eval_mode=ASYNC)* log only, no runtime effect.

    on_block : str, optional
        Preferred selector for COERCIVE handling: ``"redact"`` or ``"raise"``.
        When set it takes precedence over ``enforcement_mode``.  Names the block
        behaviour directly, separate from ``eval_mode`` (which decides whether to
        block at all).  Example: ``on_block="raise"``.

    on_result : callable, optional
        ``on_result(result: GovernanceResult, role: ContentRole)`` — hook for
        logging, metrics, or OTEL span recording after each evaluation.
    timeout : float
        Per-request HTTP timeout in seconds (default 5.0).
    privacy_proxy : PrivacyProxy, optional
        When provided, every user prompt is run through the proxy **before**
        reaching the Policy Engine.  Stage 1 (pattern match + entity
        tokenization) and Stage 2 (local embedding classifier) both execute
        entirely in-process — no content is sent externally.  A blocked
        result short-circuits all further evaluation and returns a safe
        refusal without any PE call.

    Returns
    ───────
    ``GovernedGraph`` — a drop-in replacement for the original compiled graph.
    Supports ``.invoke()``, ``.stream()``, and ``.get_graph()``.

    Example — REDACT mode (default, zero exception-handling boilerplate)
    ────────────────────────────────────────────────────────────────────
    ::

        from rai_sdk_langgraph import instrument

        app = instrument(
            app,
            base_url="http://localhost:3000",
            app_id="mybank",
        )

        # Blocked requests return a safe refusal message automatically.
        result = app.invoke(state)

    Example — RAISE mode (opt-in, rich block detail in UI)
    ──────────────────────────────────────────────────────
    ::

        from rai_sdk_langgraph import instrument
        from rai_trust_sdk import GovernanceBlock, EnforcementMode

        app = instrument(
            app,
            base_url="http://localhost:3000",
            app_id="mybank",
            enforcement_mode=EnforcementMode.RAISE,
        )

        try:
            result = app.invoke(state)
        except GovernanceBlock as e:
            return {"blocked": True, "violations": e.result.violations}
    """
    # ── Configuration resolution ───────────────────────────────────────────────
    # ALL SDK deployment config resolves through RaiConfig, precedence highest→lowest:
    #   kwargs > OS env (RAI_*/OTEL_*) > rai.env > rai.toml/[tool.rai] > defaults.
    # The SDK reads its own config here — no launcher, no change to how the app starts,
    # no dependency on the application's .env. IDENTITY (app_id, app_key) is NOT config:
    # the app owns its credential and passes it explicitly. A pre-built `config=` wins
    # wholesale (tests / shared config); otherwise we build one from the config-backed
    # kwargs, where None means "defer to env/file/default". pe_url + pap_url are REQUIRED
    # (RaiConfig.load raises a clear error if neither kwarg, env, nor file supplies them).
    _enf_override = (EnforcementMode._from_on_block(on_block) if on_block is not None
                     else enforcement_mode)
    cfg = config or RaiConfig.load(
        pe_url=base_url,
        pap_url=pap_url,
        eval_mode=eval_mode,
        enforcement_mode=_enf_override,
        timeout=timeout,
        otel_endpoint=otel_endpoint,
        otel_protocol=otel_protocol,
        govern_returns=govern_returns,
        govern_handoffs=govern_handoffs,
    )
    for _n in cfg.mode_notes:
        logger.warning("rai_trust_sdk: %s", _n)

    client = TrustClient(
        base_url=cfg.pe_url,
        app_id=app_id,
        api_key=api_key,
        app_key=app_key,
        timeout=cfg.timeout,
        on_result=on_result,               # single owner of the hook (fires it from the ASYNC worker)
        enforcement_mode=cfg.enforcement_mode,   # advertised to the PE on every request
    )

    # OTel — set up when either an OTLP endpoint or a file export path is given.
    # OTEL_FILE_EXPORT_PATH env var enables file-only export without a Phoenix endpoint —
    # useful for local inspection before a collector is available.
    tracer = None
    _file_path = os.environ.get("OTEL_FILE_EXPORT_PATH")
    if cfg.otel_endpoint or _file_path:
        try:
            from rai_trust_sdk.observability import setup_otel
            # x-phoenix-project-name groups all traces for this app under one
            # project tile in the Phoenix dashboard automatically.
            tracer = setup_otel(
                app_id,
                endpoint=cfg.otel_endpoint,   # may be None when file-only
                protocol=cfg.otel_protocol,
                headers={"x-phoenix-project-name": app_id} if cfg.otel_endpoint else {},
                file_export_path=_file_path,
            )
            logger.info(
                "RAI Trust: OTel configured → endpoint=%s file=%s",
                cfg.otel_endpoint or "—", _file_path or "—",
            )
        except ImportError:
            logger.warning(
                "RAI Trust: OTel requested but opentelemetry packages are not installed. "
                "Install with: pip install 'rai-trust-sdk[otel]'"
            )
        except Exception as _otel_exc:
            # A bad OTEL_FILE_EXPORT_PATH (unwritable dir), a bad protocol, or any exporter
            # error must not take down instrument(); the app runs, just without tracing.
            logger.warning(
                "RAI Trust: OTel setup failed (non-fatal — continuing without tracing): %s",
                _otel_exc,
            )

    # (on_block resolution + the eval/enforcement coherence self-test happened inside
    # RaiConfig.load above; cfg.eval_mode + cfg.enforcement_mode are the resolved, validated
    # posture, and the client already advertises cfg.enforcement_mode to the PE.)

    # Expand agent_nodes to match both the node label AND the Python function
    # name.  LangGraph may fire on_chain_start with either:
    #   - the label passed to add_node()  → "intl_wire_agent"
    #   - the wrapped function __name__   → "intl_wire_agent_node"
    # We normalise both sides at instrument() time so no runtime lookup needed.
    expanded_nodes: Optional[Set[str]] = None
    if agent_nodes:
        expanded_nodes = set()
        for n in agent_nodes:
            expanded_nodes.add(n)
            if n.endswith("_node"):
                expanded_nodes.add(n[:-5])       # strip _node  (label → func)
            else:
                expanded_nodes.add(f"{n}_node")  # add   _node  (func → label)

    # PAP URL for agent-topology registration is cfg.pap_url — REQUIRED (RaiConfig raises if
    # absent). The PAP is a SEPARATE, independently-deployed service from the PE and its URL is
    # NEVER derived from the PE URL; a wrong/absent PAP URL degrades loudly (see
    # _degrade_on_registration_failure) rather than silently pointing at the PE's host.

    # Privacy proxy — resolved through the SPI (rai_trust_sdk.privacy). An explicit privacy_proxy
    # kwarg (string | PrivacyProvider | custom .process object | None=off) wins; otherwise use the
    # config spec (cfg.privacy_proxy from RAI_PRIVACY_PROXY / rai.env / rai.toml / default "none").
    # resolve_privacy_proxy NEVER raises — a bad name or missing extras degrade to regex/None.
    from rai_trust_sdk.privacy import resolve_privacy_proxy as _resolve_privacy
    _privacy_spec = cfg.privacy_proxy if privacy_proxy is _UNSET else privacy_proxy
    _resolved_privacy_proxy = _resolve_privacy(_privacy_spec, privacy_config)

    return GovernedGraph(
        graph=graph,
        client=client,
        app_id=app_id,
        app_key=app_key,
        pap_url=cfg.pap_url,
        config=cfg,
        tool_filter=tool_filter,
        govern_roles=govern_roles,
        agent_nodes=expanded_nodes,
        a2a_tools=dict(a2a_tools) if a2a_tools else None,
        eval_mode=cfg.eval_mode,
        enforcement_mode=cfg.enforcement_mode,
        on_result=on_result,
        tracer=tracer,
        privacy_proxy=_resolved_privacy_proxy,
        hitl_on_normative_a2a=hitl_on_normative_a2a,
        hitl_normative_threshold=hitl_normative_threshold,
        govern_returns=cfg.govern_returns,
        govern_handoffs=cfg.govern_handoffs,
    )


# ── GovernedGraph ─────────────────────────────────────────────────────────────

class GovernedGraph:
    """
    Drop-in wrapper around a compiled LangGraph that enforces governance on
    every invocation.

    Do not instantiate directly — use ``instrument()`` instead.
    """

    def __init__(
        self,
        graph: Any,
        client: TrustClient,
        app_id: str,
        app_key: Optional[str],
        tool_filter: Optional[List[str]],
        govern_roles: Optional[List[str]],
        agent_nodes: Optional[Set[str]],
        a2a_tools: Optional[Dict[str, str]],
        eval_mode: EvalMode,
        enforcement_mode: EnforcementMode,
        on_result: Optional[Callable[[GovernanceResult, ContentRole], None]],
        tracer: Any = None,
        privacy_proxy: Any = None,
        hitl_on_normative_a2a: bool = False,
        hitl_normative_threshold: int = 2,
        govern_returns: bool = False,
        govern_handoffs: Optional[bool] = None,
        pap_url: Optional[str] = None,
        config: Optional["RaiConfig"] = None,
    ) -> None:
        self._graph            = graph
        self._client           = client
        self._app_key          = app_key
        self._app_id           = app_id
        self._config           = config            # resolved RaiConfig (banner: per-field sources)
        self._pe_url           = config.pe_url if config else None   # resolved PE URL (banner)
        self._mode_notes       = list(config.mode_notes) if config else []  # self-test notes (mutable: degrade appends)
        self._tool_filter      = set(tool_filter) if tool_filter else None
        self._govern_roles     = _coerce_govern_roles(govern_roles)  # None = govern all roles
        self._agent_nodes      = agent_nodes   # nodes → A2A via on_chain_start
        self._a2a_tools        = a2a_tools     # tools → A2A via on_tool_start (guaranteed)
        self._eval_mode        = eval_mode
        self._enforcement_mode = enforcement_mode
        self._on_result        = on_result
        self._tracer           = tracer
        self._privacy_proxy    = privacy_proxy
        # Intercept + evaluate the tool RETURN (the called agent's RESPONSE), not just the
        # call. Off by default: opt-in (it doubles A2A eval volume) and preserves existing
        # behavior. Governs the ANSWER, and puts the responding agent's content on the feed.
        self._govern_returns   = govern_returns
        # A2A evaluation of Command(goto=...) handoffs (Pattern B/C). A node/tool returning
        # a Command TRANSFERS control — a genuine agent->agent handoff the SDK OBSERVES for
        # discovery (observed_edges). Default ON: these are governed as agent_to_agent and
        # reach the conflict detector. A deployment opts OUT with RAI_GOVERN_HANDOFFS=false;
        # an explicit bool (tests) wins. Resolved to a bool in the callback so the per-invoke
        # handler owns the env read.
        self._govern_handoffs  = govern_handoffs

        # ── HITL: human-in-the-loop on NORMATIVE A2A verdicts ────────────────
        # When hitl_on_normative_a2a=True, NORMATIVE A2A verdicts increment a
        # per-session counter.  Once the counter reaches hitl_normative_threshold,
        # HITLInterrupt is raised so the server can pause and route the request
        # for human review.
        # _hitl_normative_counts and _hitl_cleared_sessions are shared by reference
        # with _ToolGuardCallback so they persist across invocations.
        self._hitl_on_normative_a2a: bool       = hitl_on_normative_a2a
        self._hitl_normative_threshold: int      = hitl_normative_threshold
        self._hitl_normative_counts: Dict[str, int] = {}   # session_id → NORMATIVE count
        self._hitl_cleared_sessions: Set[str]       = set()  # HITL-approved sessions (skip check)

        # B.4 (soft) — the counter-based Path-B HITL is DEPRECATED. The primary
        # mechanism is PE REQUIRE_HUMAN_REVIEW directives, which carry full
        # context (category, options, source) and don't require every app to
        # pick a magic threshold. This warning fires at construction time when
        # an app still sets hitl_on_normative_a2a=True (currently: MyBank's
        # card-denial demo). Kept working for one release; removed after apps
        # migrate. See docs/checkpoints/SDK_Dedup_Review_2026-09-15.md B.4/B.6.
        if hitl_on_normative_a2a:
            logger.warning(
                "GovernedGraph: hitl_on_normative_a2a=True is DEPRECATED. "
                "Use PE REQUIRE_HUMAN_REVIEW directives instead — they carry "
                "category/options/source that the counter cannot. The counter "
                "path will be removed in the next SDK major. See "
                "docs/checkpoints/SDK_Dedup_Review_2026-09-15.md B.4/B.6."
            )

        # ── Non-heuristic agent discovery: per-node behavioral evidence ───────
        # Shared by reference with _ToolGuardCallback so it accumulates across
        # invocations (the callback is rebuilt per invoke). Observe-only.
        self._node_evidence: Dict[str, Dict[str, Any]] = {}
        # OBSERVED agent-to-agent edges — (caller, callee) pairs we WATCHED happen,
        # as distinct from edges derived from graph topology. Held here, not on the
        # callback, because the callback is rebuilt and discarded on every invoke():
        # edges recorded into a per-invoke set are unreadable the moment it returns.
        self._observed_edges: Set[Tuple[str, str]] = set()
        # ONE lock guarding all reads/writes of the shared discovery state (_node_evidence,
        # _observed_edges). Created HERE and passed by reference into the rebuilt-per-invoke
        # callback so the discovery READERS (GovernedGraph.get_discovered_agents / observed_edges)
        # and the WRITERS (the callback's _bump / observed-edge .add) serialize on the SAME lock —
        # otherwise a concurrent request hits "dict/set changed size during iteration".
        self._ev_lock = threading.Lock()
        try:
            self._seed_static_evidence(graph)   # native LangGraph introspection (get_graph + builder)
        except Exception as _sx:
            logger.debug("GovernedGraph: static discovery seed skipped: %s", _sx)
        self._last_topology_sig: Optional[str] = None   # emit topology to PE only on change
        self._last_advisories: List[Dict[str, Any]] = []  # NORMATIVE advisories, reset per invoke
        self._evicted_agents: Set[str] = set()            # standing eviction set (shared w/ callback)
        self._last_platform_evicted: Set[str] = set()     # last platform manifest (reinstate reconcile)

        # ── Option A: graph topology discovery ───────────────────────────────
        # Extract all node names from the compiled graph at startup — before any
        # traffic flows.  This gives structural completeness regardless of which
        # code paths are exercised at runtime.  Internal LangGraph nodes
        # (__start__, __end__) are filtered out; only user-defined nodes remain.
        self._discovered_nodes: List[str] = []
        try:
            raw_nodes = list(graph.nodes.keys())
            self._discovered_nodes = [n for n in raw_nodes if not n.startswith("__")]
            logger.info(
                "GovernedGraph [%s]: discovered %d nodes from graph topology: %s",
                app_id, len(self._discovered_nodes), self._discovered_nodes,
            )
        except Exception as exc:
            logger.debug("GovernedGraph: node topology discovery skipped (%s)", exc)

        # ── Entry-node discovery (for C.8 audit-row `to_agent` at L1) ─────────
        # The router or first user-defined node reached from START. Populated at
        # boot from static topology; None when the graph has a conditional entry
        # or a shape the introspector can't resolve — in which case L1 audit rows
        # get from_agent="user" but omit to_agent (documented, not a bug).
        self._entry_node: Optional[str] = None
        try:
            for e in (getattr(graph.get_graph(), "edges", []) or []):
                src = getattr(e, "source", "") or ""
                tgt = getattr(e, "target", "") or ""
                if src == "__start__" and tgt and not tgt.startswith("__"):
                    self._entry_node = tgt
                    break
        except Exception as exc:
            logger.debug("GovernedGraph: entry-node discovery skipped (%s)", exc)

        # ── Agent registry — SYNCHRONOUS registration with the PAP ───────────
        # register-agents is a PAP endpoint (self._pap_url) — a SEPARATE service from the PE
        # (evaluate → base_url), distributed on its own host in the target state. We register
        # SYNCHRONOUSLY (with retries) at construction so the governance POSTURE is settled BEFORE
        # any traffic: if the platform cannot receive this app's topology, we must NOT enforce in
        # the dark. PAP URL is EXPLICIT — pap_url arg (resolved in instrument()) > RAI_PAP_URL env >
        # local-dev default; never derived from the PE URL.
        self._pap_url: str = pap_url or os.environ.get("RAI_PAP_URL", "http://localhost:3002")
        self._registration_ok: bool = True
        self._registration_error: Optional[str] = None
        self._pe_reachable: Optional[bool] = None
        # Sequenced boot: a clean, step-by-step status log (config self-check -> connectivity
        # -> acquired posture -> discovery -> publish registry -> ready). Runs the SYNCHRONOUS
        # topology registration and settles the governance posture BEFORE any traffic flows.
        self._boot()

    # ── Main invoke ───────────────────────────────────────────────────────────

    def invoke(self, state: Any, config: Optional[Dict] = None, **kwargs: Any) -> Any:
        """
        Governed replacement for ``compiled_graph.invoke()``.

        When OTel is configured, creates a root ``rai.governance.turn`` span
        so that Layer 1, 2 and 3 child spans appear as a waterfall in Phoenix.
        """
        session_id  = _extract_session_id(state)
        customer_id = _extract_customer_id(state)

        if self._tracer:
            with self._tracer.start_as_current_span("rai.governance.turn") as root:
                # OpenInference span kind — "CHAIN" tells Arize/Phoenix this is an
                # orchestration wrapper, not an LLM call.  Without this the span is
                # categorised as UNKNOWN and excluded from most built-in views.
                root.set_attribute("openinference.span.kind", "CHAIN")
                root.set_attribute("graph.node.name",         "rai.governance.turn")
                root.set_attribute("rai.app_id",              self._client._app_id)
                if session_id:
                    root.set_attribute("session.id", session_id)  # OI canonical attr
                    root.set_attribute("rai.session_id", session_id)
                if customer_id:
                    root.set_attribute("user.id", customer_id)    # Arize user attribution
                return self._invoke_governed(state, config, session_id, **kwargs)
        return self._invoke_governed(state, config, session_id, **kwargs)

    def _invoke_governed(
        self,
        state: Any,
        config: Optional[Dict],
        session_id: Optional[str],
        **kwargs: Any,
    ) -> Any:
        """Inner invoke — three governance layers, called from invoke()."""

        # ── Privacy Proxy — shadow-copy pattern ──────────────────────────────────
        # The proxy produces a sanitised EVALUATION COPY used only for the PE
        # call and the audit trail.  The LangGraph execution state is never
        # modified: the LLM and tool execution path always receive the original
        # user text so that tool calls (e.g. domestic_transfer) can use the real
        # routing/account numbers.
        #
        # Why shadow-copy and not state replacement?
        #   Routing numbers and bank account numbers are GLBA NPI / NACHA-
        #   protected data.  They must not appear in requests to external
        #   Guardrail Service providers or in the governance audit trail.  But
        #   tokenising them in the LangGraph state would break tool execution —
        #   the LLM would pass "[ROUTING_NUMBER]" to the tool instead of the
        #   real 9-digit ABA number.  The shadow copy satisfies both constraints.
        user_text = _extract_last_human(state)
        eval_text = user_text   # default: PE evaluates original when no proxy
        self._last_advisories = []   # reset per-invocation NORMATIVE advisory buffer
        _pii_meta: Optional[Dict[str, Any]] = None
        if user_text and self._privacy_proxy is not None:
            proxy_result = self._privacy_proxy.process(user_text)
            if proxy_result.anonymized and proxy_result.anonymized != user_text:
                eval_text = proxy_result.anonymized   # PE/audit sees tokens
                _pii_meta = {
                    "pii_detected":   proxy_result.detections,
                    "pii_anonymized": True,
                }
                logger.info(
                    "GovernedGraph: PrivacyProxy — PII masked before PE evaluation, "
                    "detections=%s", proxy_result.detections
                )
                # state is intentionally NOT modified — LLM sees original

        # ── Layer 1: User input guard ─────────────────────────────────────────
        if eval_text:
            logger.debug("GovernedGraph: Layer 1 — evaluating USER_PROMPT")
            blocked = self._govern_boundary(
                ContentRole.USER_PROMPT, eval_text, session_id,
                metadata=_pii_meta,
                from_agent="user",
                to_agent=self._entry_node,
            )
            if blocked is not None:
                # Graph was not invoked — return synthetic state with refusal
                return _inject_ai_message(state, blocked)

        # ── Layer 2: Tool pre-execution guard (injected via callback) ─────────
        merged_config, tool_cb = self._build_config(config, session_id)

        # ── Run the graph ─────────────────────────────────────────────────────
        try:
            output = self._graph.invoke(state, config=merged_config, **kwargs)
        except HITLInterrupt:
            # HITL interrupt — human review required for NORMATIVE A2A.
            # Always re-raise regardless of enforcement_mode so the application
            # server can implement the pause/review/resume workflow.
            raise
        except AgentEvicted as exc:
            # An evicted agent attempted to act. Halt like a block: RAISE mode
            # propagates; otherwise return a governance refusal in place of output.
            logger.warning("GovernedGraph: agent '%s' evicted — %s", exc.agent, exc.reason)
            if self._enforcement_mode == EnforcementMode.RAISE:
                raise
            return _inject_ai_message(state, f"Agent suspended by governance: {exc.reason}")
        except GovernanceHold as exc:
            # Layer 2 fired a NORMATIVE HOLD from inside the tool callback. A hold is
            # posture-INDEPENDENT (never a terminal raise, even in RAISE): withhold the
            # action and surface the remediation. The request is re-attemptable — once
            # the caller effects the remediation, the same tool call passes next turn.
            logger.info(
                "GovernedGraph: Layer 2 NORMATIVE hold — tool withheld pending remediation. "
                "violations=%s", exc.result.violations
            )
            return _inject_ai_message(state, exc.remediation_text or _REDACT_COERCIVE)
        except GovernanceBlock as exc:
            # Layer 2 fired GovernanceBlock from inside the tool callback.
            # In REDACT mode: absorb it and return the policy remediation as the
            # response (context-specific, template-rendered by the PE).
            # In RAISE mode: re-raise so the application can handle it.
            if self._enforcement_mode == EnforcementMode.REDACT:
                msg = (
                    exc.result.response_text
                    or (exc.result.remediations[0] if exc.result.remediations else None)
                    or _REDACT_COERCIVE
                )
                logger.info(
                    "GovernedGraph: Layer 2 REDACT — tool blocked, returning policy "
                    "remediation. violations=%s", exc.result.violations
                )
                return _inject_ai_message(state, msg)
            raise  # RAISE mode — propagate to caller

        # ── Propagate token counts to the active OTel root span ──────────────
        # tool_cb._token_usage is populated by on_llm_end during graph execution.
        # Setting these as span attributes makes them available in Phoenix / Arize
        # for cost analysis (Tier 2 metrics) and per-model attribution.
        _record_token_usage(tool_cb)

        # ── Close any open node spans ─────────────────────────────────────────
        # Node spans stay open across LLM calls within a node so that tool spans
        # nest correctly.  Close them now that graph execution is complete.
        # Must happen BEFORE Layer 3 so the LLM_RESPONSE guardrail span is a
        # sibling of the agent spans (under the root turn), not nested inside a
        # dangling node span.
        tool_cb._close_all_node_spans()

        # ── Layer 3: Response guard ───────────────────────────────────────────
        # The proxy is applied to the LLM response for PE evaluation only —
        # exactly the same shadow-copy pattern used in Layer 1.  If the LLM
        # echoes back user PII (routing numbers, account numbers) the PE should
        # see tokens, not raw digits, so data_leakage never fires on legitimate
        # transaction confirmations.  The actual response returned to the user
        # is NOT modified here — only the eval_text sent to the PE is masked.
        response_text = _extract_last_ai(output)
        if response_text:
            logger.debug("GovernedGraph: Layer 3 — evaluating LLM_RESPONSE")
            eval_response_text = response_text
            if self._privacy_proxy is not None:
                _resp_proxy = self._privacy_proxy.process(response_text)
                if _resp_proxy.anonymized and _resp_proxy.anonymized != response_text:
                    eval_response_text = _resp_proxy.anonymized
                    logger.info(
                        "GovernedGraph: PrivacyProxy — LLM response PII masked "
                        "before PE evaluation, detections=%s", _resp_proxy.detections
                    )
            _l3_final_node = tool_cb._current_node
            blocked = self._govern_boundary(
                ContentRole.LLM_RESPONSE, eval_response_text, session_id,
                from_agent=_l3_final_node,
                to_agent="user",
                tool_cb=tool_cb,
                final_node=_l3_final_node,
            )
            if blocked is not None:
                # Replace the LLM output with the safe refusal inline
                return _replace_last_ai(output, blocked)

        return output

    def stream(self, state: Any, config: Optional[Dict] = None, **kwargs: Any):
        """
        Governed replacement for ``compiled_graph.stream()``.

        Layer 1 fires before streaming begins; Layer 3 fires when the stream
        is consumed (requires iterating the generator to completion).
        Layer 2 fires inside the stream via the tool callback.
        """
        session_id = _extract_session_id(state)

        # Layer 1 — same shadow-copy pattern as invoke(): PE sees tokenised text,
        # state is never modified so the streamed graph receives original values.
        user_text = _extract_last_human(state)
        eval_text = user_text
        _pii_meta: Optional[Dict[str, Any]] = None
        if user_text and self._privacy_proxy is not None:
            proxy_result = self._privacy_proxy.process(user_text)
            if proxy_result.anonymized and proxy_result.anonymized != user_text:
                eval_text = proxy_result.anonymized
                _pii_meta = {
                    "pii_detected":   proxy_result.detections,
                    "pii_anonymized": True,
                }
                logger.info(
                    "GovernedGraph.stream: PrivacyProxy — PII masked before PE evaluation, "
                    "detections=%s", proxy_result.detections,
                )
        if eval_text:
            blocked = self._govern_boundary(
                ContentRole.USER_PROMPT, eval_text, session_id,
                metadata=_pii_meta,
                from_agent="user",
                to_agent=self._entry_node,
            )
            if blocked is not None:
                yield _inject_ai_message(state, blocked)
                return

        merged_config, tool_cb = self._build_config(config, session_id)

        # Stream — Layer 3 on final chunk
        last_output: Any = None
        try:
            for chunk in self._graph.stream(state, config=merged_config, **kwargs):
                last_output = chunk
                yield chunk
        except GovernanceHold as exc:
            # NORMATIVE hold — posture-independent, re-attemptable (see invoke()).
            tool_cb._close_all_node_spans()
            logger.info(
                "GovernedGraph.stream: Layer 2 NORMATIVE hold — tool withheld pending "
                "remediation. violations=%s", exc.result.violations
            )
            yield _inject_ai_message(state, exc.remediation_text or _REDACT_COERCIVE)
            return
        except GovernanceBlock as exc:
            tool_cb._close_all_node_spans()
            if self._enforcement_mode == EnforcementMode.REDACT:
                msg = (
                    exc.result.response_text
                    or (exc.result.remediations[0] if exc.result.remediations else None)
                    or _REDACT_COERCIVE
                )
                yield _inject_ai_message(state, msg)
                return
            raise

        if last_output is not None:
            _record_token_usage(tool_cb)
            tool_cb._close_all_node_spans()
            response_text = _extract_last_ai(last_output)
            if response_text:
                eval_response_text = response_text
                if self._privacy_proxy is not None:
                    _resp_proxy = self._privacy_proxy.process(response_text)
                    if _resp_proxy.anonymized and _resp_proxy.anonymized != response_text:
                        eval_response_text = _resp_proxy.anonymized
                        logger.info(
                            "GovernedGraph.stream: PrivacyProxy — LLM response PII "
                            "masked before PE evaluation, detections=%s",
                            _resp_proxy.detections,
                        )
                _l3_final_node = tool_cb._current_node
                blocked = self._govern_boundary(
                    ContentRole.LLM_RESPONSE, eval_response_text, session_id,
                    from_agent=_l3_final_node,
                    to_agent="user",
                    tool_cb=tool_cb,
                    final_node=_l3_final_node,
                )
                if blocked is not None:
                    yield _replace_last_ai(last_output, blocked)

    # ── Async execution — GOVERNED (else async hosts run ungoverned, silently) ──
    # Without these, ainvoke/astream fell through __getattr__ to the RAW graph: a FastAPI /
    # streaming host got ZERO governance and no log. These mirror invoke()/stream() and respect
    # the SAME configured posture (ASYNC eval_mode = observe-only; SYNC = blocking gate). Layer 2
    # fires via the tool callback in merged_config, which LangChain invokes during async runs too.

    async def ainvoke(self, state: Any, config: Optional[Dict] = None, **kwargs: Any) -> Any:
        """Governed async replacement for ``compiled_graph.ainvoke()`` (mirror of invoke())."""
        session_id  = _extract_session_id(state)
        customer_id = _extract_customer_id(state)
        if self._tracer:
            with self._tracer.start_as_current_span("rai.governance.turn") as root:
                root.set_attribute("openinference.span.kind", "CHAIN")
                root.set_attribute("graph.node.name",         "rai.governance.turn")
                root.set_attribute("rai.app_id",              self._client._app_id)
                if session_id:
                    root.set_attribute("session.id", session_id)
                    root.set_attribute("rai.session_id", session_id)
                if customer_id:
                    root.set_attribute("user.id", customer_id)
                return await self._ainvoke_governed(state, config, session_id, **kwargs)
        return await self._ainvoke_governed(state, config, session_id, **kwargs)

    async def _ainvoke_governed(self, state: Any, config: Optional[Dict],
                                session_id: Optional[str], **kwargs: Any) -> Any:
        # ── Layer 1 — same shadow-copy pattern as _invoke_governed ────────────
        user_text = _extract_last_human(state)
        eval_text = user_text
        self._last_advisories = []
        _pii_meta: Optional[Dict[str, Any]] = None
        if user_text and self._privacy_proxy is not None:
            proxy_result = self._privacy_proxy.process(user_text)
            if proxy_result.anonymized and proxy_result.anonymized != user_text:
                eval_text = proxy_result.anonymized
                _pii_meta = {"pii_detected": proxy_result.detections, "pii_anonymized": True}
                logger.info("GovernedGraph.ainvoke: PrivacyProxy — PII masked before PE evaluation, "
                            "detections=%s", proxy_result.detections)
        if eval_text:
            blocked = self._govern_boundary(
                ContentRole.USER_PROMPT, eval_text, session_id,
                metadata=_pii_meta,
                from_agent="user",
                to_agent=self._entry_node,
            )
            if blocked is not None:
                return _inject_ai_message(state, blocked)

        merged_config, tool_cb = self._build_config(config, session_id)
        try:
            output = await self._graph.ainvoke(state, config=merged_config, **kwargs)
        except HITLInterrupt:
            raise
        except AgentEvicted as exc:
            logger.warning("GovernedGraph.ainvoke: agent '%s' evicted — %s", exc.agent, exc.reason)
            if self._enforcement_mode == EnforcementMode.RAISE:
                raise
            return _inject_ai_message(state, f"Agent suspended by governance: {exc.reason}")
        except GovernanceHold as exc:
            # NORMATIVE hold — posture-independent, re-attemptable (see invoke()).
            logger.info("GovernedGraph.ainvoke: Layer 2 NORMATIVE hold — tool withheld pending "
                        "remediation. violations=%s", exc.result.violations)
            return _inject_ai_message(state, exc.remediation_text or _REDACT_COERCIVE)
        except GovernanceBlock as exc:
            if self._enforcement_mode == EnforcementMode.REDACT:
                msg = (exc.result.response_text
                       or (exc.result.remediations[0] if exc.result.remediations else None)
                       or _REDACT_COERCIVE)
                logger.info("GovernedGraph.ainvoke: Layer 2 REDACT — tool blocked, returning policy "
                            "remediation. violations=%s", exc.result.violations)
                return _inject_ai_message(state, msg)
            raise

        _record_token_usage(tool_cb)
        tool_cb._close_all_node_spans()

        # ── Layer 3 — response guard ──────────────────────────────────────────
        response_text = _extract_last_ai(output)
        if response_text:
            eval_response_text = response_text
            if self._privacy_proxy is not None:
                _resp_proxy = self._privacy_proxy.process(response_text)
                if _resp_proxy.anonymized and _resp_proxy.anonymized != response_text:
                    eval_response_text = _resp_proxy.anonymized
                    logger.info("GovernedGraph.ainvoke: PrivacyProxy — LLM response PII masked "
                                "before PE evaluation, detections=%s", _resp_proxy.detections)
            _l3_final_node = tool_cb._current_node
            blocked = self._govern_boundary(
                ContentRole.LLM_RESPONSE, eval_response_text, session_id,
                from_agent=_l3_final_node,
                to_agent="user",
                tool_cb=tool_cb,
                final_node=_l3_final_node,
            )
            if blocked is not None:
                return _replace_last_ai(output, blocked)
        return output

    async def astream(self, state: Any, config: Optional[Dict] = None, **kwargs: Any):
        """Governed async replacement for ``compiled_graph.astream()`` (mirror of stream())."""
        session_id = _extract_session_id(state)
        user_text = _extract_last_human(state)
        eval_text = user_text
        _pii_meta: Optional[Dict[str, Any]] = None
        if user_text and self._privacy_proxy is not None:
            proxy_result = self._privacy_proxy.process(user_text)
            if proxy_result.anonymized and proxy_result.anonymized != user_text:
                eval_text = proxy_result.anonymized
                _pii_meta = {"pii_detected": proxy_result.detections, "pii_anonymized": True}
                logger.info("GovernedGraph.astream: PrivacyProxy — PII masked before PE evaluation, "
                            "detections=%s", proxy_result.detections)
        if eval_text:
            blocked = self._govern_boundary(
                ContentRole.USER_PROMPT, eval_text, session_id,
                metadata=_pii_meta,
                from_agent="user",
                to_agent=self._entry_node,
            )
            if blocked is not None:
                yield _inject_ai_message(state, blocked)
                return

        merged_config, tool_cb = self._build_config(config, session_id)
        last_output: Any = None
        try:
            async for chunk in self._graph.astream(state, config=merged_config, **kwargs):
                last_output = chunk
                yield chunk
        except GovernanceHold as exc:
            # NORMATIVE hold — posture-independent, re-attemptable (see invoke()).
            tool_cb._close_all_node_spans()
            logger.info("GovernedGraph.astream: Layer 2 NORMATIVE hold — tool withheld pending "
                        "remediation. violations=%s", exc.result.violations)
            yield _inject_ai_message(state, exc.remediation_text or _REDACT_COERCIVE)
            return
        except GovernanceBlock as exc:
            tool_cb._close_all_node_spans()
            if self._enforcement_mode == EnforcementMode.REDACT:
                msg = (exc.result.response_text
                       or (exc.result.remediations[0] if exc.result.remediations else None)
                       or _REDACT_COERCIVE)
                yield _inject_ai_message(state, msg)
                return
            raise

        if last_output is not None:
            _record_token_usage(tool_cb)
            tool_cb._close_all_node_spans()
            response_text = _extract_last_ai(last_output)
            if response_text:
                eval_response_text = response_text
                if self._privacy_proxy is not None:
                    _resp_proxy = self._privacy_proxy.process(response_text)
                    if _resp_proxy.anonymized and _resp_proxy.anonymized != response_text:
                        eval_response_text = _resp_proxy.anonymized
                        logger.info("GovernedGraph.astream: PrivacyProxy — LLM response PII masked "
                                    "before PE evaluation, detections=%s", _resp_proxy.detections)
                _l3_final_node = tool_cb._current_node
                blocked = self._govern_boundary(
                    ContentRole.LLM_RESPONSE, eval_response_text, session_id,
                    from_agent=_l3_final_node,
                    to_agent="user",
                    tool_cb=tool_cb,
                    final_node=_l3_final_node,
                )
                if blocked is not None:
                    yield _replace_last_ai(last_output, blocked)

    # ── Ungoverned async/batch surfaces — FAIL LOUD, never silently bypass ──────
    # These execution modes are not yet wrapped with governance. Rather than let __getattr__
    # proxy them to the raw graph (silent, total un-governing — the exact bug #1 fixes), refuse
    # loudly and point the caller at the governed path.
    def batch(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError(
            "RAI Trust: GovernedGraph.batch() is not governed. Call .invoke() per item (governed).")

    async def abatch(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError(
            "RAI Trust: GovernedGraph.abatch() is not governed. Call .ainvoke() per item (governed).")

    async def astream_events(self, *args: Any, **kwargs: Any):
        raise NotImplementedError(
            "RAI Trust: GovernedGraph.astream_events() is not yet governed. Use .astream() (governed).")
        yield  # pragma: no cover — makes this an async generator so the raise fires on iteration

    async def astream_log(self, *args: Any, **kwargs: Any):
        raise NotImplementedError(
            "RAI Trust: GovernedGraph.astream_log() is not yet governed. Use .astream() (governed).")
        yield  # pragma: no cover

    # ── Pass-through for graph inspection ────────────────────────────────────

    def get_graph(self, *args: Any, **kwargs: Any) -> Any:
        return self._graph.get_graph(*args, **kwargs)

    @property
    def last_advisories(self) -> List[Dict[str, Any]]:
        """
        NORMATIVE advisories collected during the most recent invoke() — the SDK
        surfacing advisory verdicts to the governed app first-class. The verdict
        still proceeds (NORMATIVE never blocks); the app reads these to warn,
        disclaim, or log the PE's guidance as it sees fit. Empty when none fired.
        """
        return list(self._last_advisories)

    @property
    def privacy_proxy(self):
        """The resolved privacy-proxy provider (or None when disabled). Exposed so the app can
        reuse the SAME configured proxy for its own pre-scans (e.g. a UI 'PII masked' badge)
        without importing or constructing a proxy itself: ``governed.privacy_proxy.process(text)``."""
        return self._privacy_proxy

    @property
    def evicted_agents(self) -> Set[str]:
        """Agents under a standing eviction — enforced at their next node/tool start."""
        return set(self._evicted_agents)

    @property
    def observed_edges(self) -> Set[Tuple[str, str]]:
        """
        (caller, callee) agent-to-agent handoffs this graph was WATCHED performing,
        accumulated across invocations.

        Distinct from get_discovered_agents()['a2a_edges'], which is DECLARED from
        graph topology. Declared says "may talk to"; this says "DID". They are
        reported separately and never merged — the divergence is the finding.

        Three handoff shapes, three observations, no author annotation required:

          A · agent-as-tool  — the coordinator calls a tool that wraps a sub-agent;
              control STAYS. An LLM call observed BENEATH the tool's execution
              means the tool reasoned, so caller -> tool is a real handoff.
              (Topology yields nothing here: the sub-agent is not a graph node.)
          B · graph edge      — a NODE returns Command(goto=X); control TRANSFERS.
              Read from on_chain_end's Command, sourced by the run_id stashed at
              on_chain_start.
          C · handoff tool    — a TOOL returns Command(goto=X); control TRANSFERS,
              so the callee never nests under the tool and A's mechanism cannot
              apply. Read from on_tool_end's Command, sourced by the caller stashed
              at on_tool_start.

        B and C were long assumed unobservable ("no tool call at the moment of
        handoff" / "control transfers away"). Both assumptions were measured false:
        the Command carries `.goto`, so the app names its own target. The mechanism
        differs per shape; the guarantee does not — delete every `destinations=` in
        the app and this set is unchanged, because the handoffs still happened.
        """
        with self._ev_lock:                      # snapshot under lock — writers .add() concurrently
            return set(self._observed_edges)

    def _apply_eviction(self, result: GovernanceResult) -> None:
        """
        Apply EVICT_AGENT directives from a governance result to the standing
        evicted-agent set. Target = directive.metadata['agent'] (fallback:
        directive.reason). Enforced at the agent's next node/tool start (raises
        AgentEvicted). Idempotent; works in SYNC and ASYNC.
        """
        for d in (getattr(result, "directives", None) or []):
            if getattr(d, "action", None) == DirectiveAction.EVICT_AGENT:
                meta = getattr(d, "metadata", None) or {}
                target = meta.get("agent") or getattr(d, "reason", "") or ""
                target = target.strip() if isinstance(target, str) else ""
                if target and target not in self._evicted_agents:
                    self._evicted_agents.add(target)
                    logger.warning("GovernedGraph: EVICT_AGENT — '%s' evicted (reason=%s)",
                                   target, getattr(d, "reason", ""))

    def _reconcile_platform_evictions(self, result: GovernanceResult) -> None:
        """
        Reconcile the standing evicted-set with the platform's authoritative
        eviction manifest carried on every evaluate response (result.evicted_agents).
        Replace-semantics for platform-driven evictions so an operator REINSTATE
        (agent drops off the manifest) actually un-blocks it — while preserving
        directive-driven (in-session) evictions added by _apply_eviction. Works in
        SYNC and ASYNC (the SDK reads the response in both).
        """
        new = set(getattr(result, "evicted_agents", None) or [])
        if new == self._last_platform_evicted:
            return
        reinstated = self._last_platform_evicted - new
        if reinstated:
            self._evicted_agents -= reinstated
            logger.info("GovernedGraph: platform reinstated agent(s): %s", sorted(reinstated))
        added = new - self._last_platform_evicted
        if added:
            self._evicted_agents |= added
            logger.warning("GovernedGraph: platform evicted agent(s): %s", sorted(added))
        self._last_platform_evicted = new

    # ── The single governance-boundary choreography ──────────────────────────
    # Every L1 and L3 boundary — invoke, stream, ainvoke, astream — routes
    # through this helper. Before it existed, the five-step choreography
    # (evaluate -> apply_eviction -> reconcile -> hitl_check -> enforce) was
    # copy-pasted across eight sites and drifted: the streaming paths silently
    # skipped `_apply_eviction` and `_reconcile_platform_evictions`, so agent
    # evictions from the platform never took effect on `stream()` / `astream()`
    # (a real correctness bug hidden behind the copy-paste; see
    # docs/checkpoints/SDK_Dedup_Review_2026-09-15.md item A.2).
    #
    # from_agent / to_agent are populated here per C.8 so every governance row
    # carries them; `agent_name` is kept as an alias for one release.
    # L3 token metadata is folded in here per B.5 — one build site instead of
    # four call-site copies.
    def _govern_boundary(
        self,
        role:         "ContentRole",
        content:      str,
        session_id:   Optional[str],
        *,
        metadata:     Optional[Dict[str, Any]] = None,
        from_agent:   Optional[str] = None,
        to_agent:     Optional[str] = None,
        tool_cb:      Optional[Any] = None,
        final_node:   Optional[str] = None,
        emit_topology: bool = True,
    ) -> Optional[str]:
        """
        Unified L1/L3 governance boundary.

        Returns:
          None — nothing blocked; caller proceeds unchanged.
          str  — substitute content the caller returns in place of the original
                 (via `_inject_ai_message` at L1 or `_replace_last_ai` at L3).

        Raises:
          HITLInterrupt — REQUIRE_HUMAN_REVIEW directive, exception-path HITL.
                          The adaptive middleware calls native `interrupt()`
                          instead when it can (see rai_sdk_langgraph.hitl).
          GovernanceBlock — enforcement_mode=RAISE + COERCIVE verdict.
        """
        meta: Dict[str, Any] = dict(metadata) if metadata else {}
        # C.8 — every audit row carries from/to_agent. `agent_name` alias kept
        # for one release for wire-compat with existing consumers.
        #
        # ── agent_name semantics (per the 2026-09-01 baseline) ────────────────
        # For L1 / L2 / L3 rows, `agent_name` has always meant the ACTING agent
        # for the row — the generator of the content, not the recipient:
        #   L1 (user_prompt)   — actor is the user; historically NOT set
        #   L2 (tool_call)     — actor is the calling agent (from_agent)
        #   L3 (llm_response)  — actor is the final generating node (from_agent)
        #   A2A                — the A2A sites emit their own metadata directly,
        #                        with their own semantics (agent_name = target);
        #                        the helper is not used for A2A.
        #
        # An earlier version of this helper set `agent_name = to_agent`. That
        # broke L3: to_agent at L3 is "user" (the recipient), which then made
        # core client derive `agent_id="user"` for every L3 row — clobbering
        # agent-cards, trust-score attribution, and every agent-scoped tag.
        # The correct alias is from_agent (skipping L1 where from_agent="user").
        if from_agent:
            meta["from_agent"] = from_agent
            # Set the deprecated alias only when from_agent names an actual
            # agent, not the user. L1's from_agent is "user"; keeping
            # agent_name unset at L1 matches the 9/1 baseline.
            if from_agent != "user":
                meta.setdefault("agent_name", from_agent)
        if to_agent:
            meta["to_agent"] = to_agent
        # Discovered-topology delta — emit on both L1 and L3, only when it
        # changes (see _topology_delta). Preserves existing behavior.
        if emit_topology:
            topo = self._topology_delta()
            if topo is not None:
                meta["discovered_topology"] = topo
        # B.5 — L3 token metadata folded into the helper. Only builds when a
        # tool_cb is passed (L3 sites do; L1 sites leave tool_cb=None).
        if tool_cb is not None:
            meta.update(_build_l3_token_meta(tool_cb, final_node))
            if final_node:
                meta["final_node"] = final_node

        result = self._evaluate(content, role, session_id, metadata=(meta or None))
        if result is None:
            return None

        # A.2 — eviction + platform-reconcile now fire uniformly on every
        # boundary. Before this helper existed, stream/astream skipped both.
        self._apply_eviction(result)
        self._reconcile_platform_evictions(result)

        _raise_if_hitl_directive(
            result, session_id,
            cleared_sessions=self._hitl_cleared_sessions,
            role=role.value if hasattr(role, "value") else str(role),
        )

        return self._enforce(result, role)

    def get_discovered_agents(self) -> Dict[str, Any]:
        """
        Non-heuristic topology discovery: classify every node by what it DID at
        runtime (LLM call? tool exec? control-flow decision?) rather than by name.
        Seeded from the static node list so unrun nodes appear as 'unknown'.

        Returns {"nodes": {name: {"kind", "evidence"}}, "agents": [names],
                 "a2a_edges": [...DECLARED — from static topology...],
                 "observed_edges": [(from, to)...OBSERVED — actually watched...]}.

        THE TWO EDGE SETS ARE DIFFERENT CLAIMS AND ARE NEVER MERGED:
          • ``a2a_edges``      — DECLARED. "A *may* hand off to B", read out of the
            graph the developer wrote (`destinations=` / `Command[Literal[...]]` /
            add_edge). Complete before a single request is served; proves nothing
            about what ran.
          • ``observed_edges`` — OBSERVED. "A *DID* hand off to B", watched at
            runtime via a tool call (Pattern A) or a Command's `.goto` (Patterns
            B/C). Grows only as agents actually execute.
        Their DIVERGENCE is the product: declared-but-never-exercised paths, and
        exercised-but-never-declared ones, are both governance findings. Summing
        them into one number destroys exactly the signal worth having.

        Observe-only — does not affect enforcement or the legacy
        agent_nodes/a2a_tools path.

        CONTRACT NOTE (changed deliberately, not silently): `a2a_edges` no longer
        collapses paths through nodes that never ran, and `kind='agent'` now
        requires an observed LLM call rather than merely being a compiled
        subgraph. Both previously produced confident claims about code that had
        never executed. Unrun agents are now reported 'unknown' until they run.
        """
        # Snapshot the shared discovery state under the lock so a concurrent writer
        # (_bump's evidence add / observed-edge .add) cannot mutate it mid-read →
        # "dict/set changed size during iteration". Compute on the private copies.
        with self._ev_lock:
            _ev_items  = {name: dict(ev) for name, ev in self._node_evidence.items()}
            _obs_edges = sorted(self._observed_edges)
        topo: Dict[str, Any] = {}
        for name in self._discovered_nodes:                      # static seed
            ev = _ev_items.get(name)
            topo[name] = {
                "kind":     _classify_node(ev) if ev else UNKNOWN_KIND,
                "evidence": dict(ev) if ev else _new_node_evidence(),
            }
        for name, ev in _ev_items.items():                       # observed-but-unlisted
            if name not in topo:
                topo[name] = {"kind": _classify_node(ev), "evidence": dict(ev)}
        # ── A2A handoffs from native topology + the classified agent set ──────
        kinds = {n: d["kind"] for n, d in topo.items()}
        adjacency: Dict[str, List[str]] = {}
        try:
            for e in (getattr(self._graph.get_graph(), "edges", []) or []):
                s = getattr(e, "source", "") or ""
                t = getattr(e, "target", "") or ""
                if s and t and not s.startswith("__") and not t.startswith("__"):
                    adjacency.setdefault(s, []).append(t)
        except Exception:
            pass
        # Only collapse through nodes we WATCHED behave — never through a static
        # guess about a node that has not run (that is what forged the phantom
        # self-loops). See _derive_a2a_edges.
        executed = {n for n, d in topo.items() if _node_ran(d["evidence"])}
        a2a = _derive_a2a_edges(kinds, adjacency, executed)

        agents = sorted(n for n, d in topo.items() if d["kind"] == AGENT_KIND)
        return {
            "nodes":          topo,
            "agents":         agents,
            "a2a_edges":      a2a,                              # DECLARED (static topology)
            "observed_edges": _obs_edges,                        # OBSERVED (watched at runtime; snapshot above)
        }

    def _topology_delta(self) -> Optional[Dict[str, Any]]:
        """
        Compact discovered-topology payload for the platform, emitted on the PE
        evaluate() metadata (no new channel) ONLY when it changes — so a 50-agent
        graph doesn't re-send every turn. Returns None when unchanged since last emit.
        """
        try:
            disco = self.get_discovered_agents()
        except Exception:
            return None
        kinds = {n: d["kind"] for n, d in disco["nodes"].items()}
        counts: Dict[str, int] = {}
        for k in kinds.values():
            counts[k] = counts.get(k, 0) + 1
        sig = repr((sorted(disco["agents"]), sorted(kinds.items()), len(disco["a2a_edges"])))
        if sig == self._last_topology_sig:
            return None
        self._last_topology_sig = sig
        return {
            "agents":    disco["agents"],
            "kinds":     kinds,
            "counts":    counts,
            "a2a_edges": disco["a2a_edges"],
        }

    def _ev_seed(self, node: str) -> Dict[str, Any]:
        ev = self._node_evidence.get(node)
        if ev is None:
            ev = _new_node_evidence()
            self._node_evidence[node] = ev
        return ev

    def _seed_static_evidence(self, graph: Any) -> None:
        """
        Seed per-node evidence from NATIVE LangGraph introspection (no name heuristics):
          • conditional-edge sources → feeds_conditional_edge (router signal)
          • ToolNode runnables       → is_tool_node (TOOL)
          • subgraph (Pregel) nodes  → is_subgraph  (nested AGENT)
        Necessary because in LangGraph 1.x plain function/router nodes fire no
        callback we observe — the graph structure is the only way to see them.
        Runtime signals (llm_calls / tool_execs) then refine/upgrade these.
        """
        # (a) conditional edges via the public get_graph() drawable
        try:
            dg = graph.get_graph()
            for e in getattr(dg, "edges", []) or []:
                if getattr(e, "conditional", False):
                    src = getattr(e, "source", "") or ""
                    if src and not src.startswith("__"):
                        self._ev_seed(src)["feeds_conditional_edge"] = True
        except Exception:
            pass
        # (b) node runnable types via builder.nodes
        try:
            from langgraph.prebuilt import ToolNode as _TN
        except Exception:
            _TN = None
        try:
            from langgraph.pregel.protocol import PregelProtocol as _PP
        except Exception:
            _PP = None
        try:
            for name, spec in (getattr(getattr(graph, "builder", None), "nodes", {}) or {}).items():
                if name.startswith("__"):
                    continue
                r = getattr(spec, "runnable", None)
                ev = self._ev_seed(name)
                if _TN is not None and isinstance(r, _TN):
                    ev["is_tool_node"] = True
                if _PP is not None and isinstance(r, _PP):
                    ev["is_subgraph"] = True
        except Exception:
            pass

    def __getattr__(self, name: str) -> Any:
        """Proxy any other attribute to the underlying compiled graph."""
        return getattr(self._graph, name)

    # ── Agent registry ────────────────────────────────────────────────────────

    def _register_agents(self) -> bool:
        """SYNCHRONOUSLY register the discovered topology with the PAP (/internal/register-agents),
        with retries. Returns True on success, False if nothing was discovered or the POST failed.

        Synchronous BY DESIGN: the governance posture (enforce vs observe-only) depends on whether
        the platform received this app's topology, so it must be known before any traffic. Delegates
        the transport to the shared core so every SDK adapter uses ONE implementation."""
        # Reconstruct base agent names from the expanded set (strip the _node variant).
        base_agent_nodes: List[str] = []
        if self._agent_nodes:
            seen: Set[str] = set()
            for n in self._agent_nodes:
                base = n[:-5] if n.endswith("_node") else n
                if base not in seen:
                    seen.add(base)
                    base_agent_nodes.append(base)
        try:
            from rai_trust_sdk import __version__ as _sdkver
        except Exception:
            _sdkver = "0.1.0"
        # Per-node classified kind (agent/tool/router) — best-effort static introspection; PAP
        # reconciles these into agent-card agent_type (discovery-owned, mask-don't-clobber).
        try:
            _disco = self.get_discovered_agents()
            node_kinds = {n: d.get("kind") for n, d in _disco.get("nodes", {}).items()}
        except Exception:
            node_kinds = {}
        from rai_trust_sdk.registry import register_agents
        return register_agents(
            pap_url=self._pap_url,
            app_id=self._app_id,
            discovered_nodes=self._discovered_nodes,
            agent_nodes=base_agent_nodes,
            a2a_tools=self._a2a_tools or {},
            framework="langgraph",
            app_key=getattr(self, "_app_key", None),
            sdk_version=_sdkver,
            node_kinds=node_kinds,
            logger=logger,
        )

    def _degrade_on_registration_failure(self) -> None:
        """Topology could not be transferred to the PAP → the operator loses Agent Activity and
        Agent Cards, so we refuse to enforce in the dark: drop to OBSERVE-ONLY (eval_mode=ASYNC,
        enforcement_mode=NONE). Deliberate, confirmed policy — governance degrades rather than block
        traffic on a platform whose control plane we cannot fully reach. Enforcement resumes on a
        restart once the PAP is reachable (registration succeeds). The loud ALERT is in the boot
        banner (see _boot_banner) so there is exactly one clear boot message."""
        if not self._registration_error:
            self._registration_error = (
                "no agent nodes discovered" if not self._discovered_nodes
                else "agent-topology registration to %s did not succeed" % self._pap_url)
        self._eval_mode = EvalMode.ASYNC
        self._enforcement_mode = EnforcementMode.NONE
        # Keep the client's advertised posture in sync so the PE sees observe-only too.
        try:
            self._client._enforcement_mode = EnforcementMode.NONE
        except Exception:
            pass
        self._mode_notes.append(
            "DEGRADED to observe-only (ASYNC + NONE) — agent topology could not be "
            "registered with the PAP; enforcement is suspended until a successful restart."
        )

    def _bootlog(self, msg: str) -> None:
        """Emit ONE clean SDK status line to stdout (always visible under uvicorn/
        gunicorn, where a module logger at INFO is swallowed). Never raises."""
        try:
            print("[RAI Trust SDK] " + msg, flush=True)
        except Exception:
            try:
                logger.info("[RAI Trust SDK] %s", msg)
            except Exception:
                pass

    @staticmethod
    def _fmt_names(names: List[str]) -> str:
        """Compact roster: the full list up to 6, else first/second ... last + total."""
        if not names:
            return "-"
        if len(names) <= 6:
            return ", ".join(names)
        return "%s, %s ... %s (%d total)" % (names[0], names[1], names[-1], len(names))

    def _probe_url(self, url: Optional[str]) -> Optional[bool]:
        """Best-effort connectivity probe. True if the host answered (any HTTP status
        counts as resolved & connected), False if it did not resolve / connect, None if
        there is nothing to probe. NEVER raises — a health check must not stop boot."""
        if not url or url == "?":
            return None
        import urllib.error as _ue
        import urllib.request as _ur
        try:
            with _ur.urlopen(url.rstrip("/") + "/health", timeout=2.0):
                return True
        except _ue.HTTPError:
            return True     # server answered (4xx/5xx) => resolved & connected
        except Exception:
            return False

    def _boot(self) -> None:
        """Sequenced, human-readable boot log, in operator order:
          a) configuration self-check + DESIRED posture (what you asked for)
          b) platform connectivity (PE + PAP)
          c) ACQUIRED posture (what connectivity actually permits)
          d) agent discovery
          e) publish agent registry / topology
          f) Ready (final effective posture)
        Runs the SYNCHRONOUS topology registration and settles the governance posture
        before any traffic. Each step prints as it happens. NEVER raises."""
        try:
            from rai_trust_sdk import __version__ as _sdkver
        except Exception:
            _sdkver = "?"
        base_url = str(getattr(getattr(self._client, "_http", None), "base_url", None)
                       or getattr(self._client, "base_url", None) or "?")
        _cfg     = self._config
        _pe_src  = _cfg.sources.get("pe_url", "?") if _cfg else "?"
        _pap_src = _cfg.sources.get("pap_url", "?") if _cfg else "?"
        eval_m   = getattr(self._eval_mode, "value", self._eval_mode)
        enf_m    = getattr(self._enforcement_mode, "value", self._enforcement_mode)
        _desired = ("observe-only (non-blocking)" if self._eval_mode == EvalMode.ASYNC
                    else "enforce (blocking gate)")

        # a) Configuration self-check + DESIRED posture
        self._bootlog("Initializing  app_id=%s  framework=langgraph  sdk=%s" % (self._app_id, _sdkver))
        if _cfg and getattr(_cfg, "file_paths", None):
            self._bootlog("Config: loaded from %s" % ", ".join(_cfg.file_paths))
        for _n in self._mode_notes:
            self._bootlog("Config: mode self-test corrected -> %s" % _n)
        self._bootlog("Config: PE=%s [%s]  PAP=%s [%s]" % (base_url, _pe_src, self._pap_url, _pap_src))
        self._bootlog("Desired posture: eval=%s  enforce=%s  ->  %s" % (eval_m, enf_m, _desired))

        # b) Connectivity — probe BOTH endpoints
        self._bootlog("Checking platform connectivity ...")
        self._pe_reachable = self._probe_url(base_url)
        self._bootlog("  PE   %s  ...  %s" % (base_url, "connected" if self._pe_reachable else "UNREACHABLE"))
        _pap_reachable = self._probe_url(self._pap_url)
        self._bootlog("  PAP  %s  ...  %s" % (self._pap_url, "connected" if _pap_reachable else "UNREACHABLE"))

        # c) ACQUIRED posture — what connectivity actually permits (finalised after publish)
        if _pap_reachable is False:
            self._bootlog("Acquired posture: DEGRADED -> observe-only  (PAP unreachable; topology cannot be published)")
        elif self._pe_reachable is False:
            self._bootlog("Acquired posture: enforce configured, but PE unreachable -> evals FAIL-OPEN until PE recovers")
        else:
            self._bootlog("Acquired posture: %s  (connectivity OK)" % _desired)

        # d) Discovery (introspected from the compiled graph at instrument() time)
        self._bootlog("Discovering agents ...")
        self._bootlog("Discovery complete -- %d agent(s): %s"
                      % (len(self._discovered_nodes), self._fmt_names(self._discovered_nodes)))
        # C.10 — classification-coverage diagnostic: at boot every node's kind
        # is derived from static seeds only (runtime signals haven't fired yet).
        # A node with no static seed will classify UNKNOWN until it runs. Print
        # a summary so the operator knows which nodes to expect to classify
        # only after traffic — and warns loud if the *static* coverage is poor.
        try:
            _static_unknown = [n for n in self._discovered_nodes
                               if _classify_node(self._ev_seed(n)) == UNKNOWN_KIND]
            _static_known   = len(self._discovered_nodes) - len(_static_unknown)
            if _static_unknown:
                self._bootlog("Classification: %d/%d nodes have static kind signals; "
                              "%d will classify after first execution: %s"
                              % (_static_known, len(self._discovered_nodes),
                                 len(_static_unknown), self._fmt_names(_static_unknown)))
        except Exception as _cx:
            logger.debug("GovernedGraph: classification diagnostic skipped: %s", _cx)

        # e) Publish agent registry / topology — SYNCHRONOUS registration with the PAP
        self._bootlog("Publishing agent registry to Trust Platform (%s) ..." % self._pap_url)
        self._registration_ok = self._register_agents()
        if self._registration_ok:
            self._bootlog("Registry published -> Agent Activity & Agent Cards available")
        else:
            self._degrade_on_registration_failure()
            self._bootlog("Registry publish FAILED: %s" % (self._registration_error or "unreachable"))
            self._bootlog("  -> DEGRADED to observe-only; Agent Activity & Agent Cards unavailable")
            self._bootlog("  -> Fix: ensure the PAP is running and pap_url|RAI_PAP_URL is correct, then restart")

        # App credential (never print the secret — presence + length only)
        if self._app_key:
            self._bootlog("App credential: present (client secret, %d chars)" % len(self._app_key))
        else:
            self._bootlog("App credential: NOT SET (PE will not authenticate this app -> evals may 401)")

        # f) Ready — the FINAL effective posture (a failed publish may have flipped it)
        eval_m = getattr(self._eval_mode, "value", self._eval_mode)
        enf_m  = getattr(self._enforcement_mode, "value", self._enforcement_mode)
        _final = ("observe-only (non-blocking)" if self._eval_mode == EvalMode.ASYNC
                  else "enforce (blocking gate)")
        if not self._registration_ok:
            self._bootlog("Ready (DEGRADED) -- observe-only   eval=%s  enforce=%s   (NO enforcement/blocking)"
                          % (eval_m, enf_m))
        elif self._pe_reachable is False:
            # The PE is the actual enforcement gate. If it is unreachable, EVERY eval fails open
            # (content is allowed through). Do NOT claim ACTIVE — say so plainly, so an operator
            # grepping the boot log for "ACTIVE" is not told governance is on while every request
            # flows ungoverned. (PE reachability is re-probed only at boot; a mid-run recovery is
            # picked up per-eval — this line reflects the posture AS OF startup.)
            self._bootlog("Ready (DEGRADED) -- PE UNREACHABLE -> evals FAIL-OPEN (content allowed through)   "
                          "eval=%s  enforce=%s   (governance blind until the PE recovers)" % (eval_m, enf_m))
        else:
            self._bootlog("Ready -- governance ACTIVE   eval=%s  enforce=%s   (%s)" % (eval_m, enf_m, _final))

    # ── Internal ──────────────────────────────────────────────────────────────

    @property
    def _observe_only(self) -> bool:
        """ASYNC eval mode = observe-only: evaluations still run, log, and fire
        on_result, but the SDK never blocks, redacts, raises, or interrupts on the
        verdict. This is the single source of truth for the ASYNC enforcement guard."""
        return self._eval_mode == EvalMode.ASYNC

    def _evaluate(
        self,
        content: str,
        role: ContentRole,
        session_id: Optional[str],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[GovernanceResult]:
        """
        Call the Policy Engine.  Returns None if evaluation is ASYNC or if
        the PE is unreachable (fail-open).  Never raises GovernanceBlock here —
        enforcement decisions are made by _enforce().

        Parameters
        ──────────
        metadata : dict, optional
            Extra metadata forwarded to the PE audit trail.  Used to surface
            Privacy Proxy detections as ``pii_detected`` / ``pii_anonymized``
            fields so the PAP audit log can show the "🔏 pii masked" badge.

        OTel note
        ─────────
        TrustClient.evaluate() always creates a GUARDRAIL child span internally
        via _guardrail_span() using the global TracerProvider.  Because the root
        ``rai.governance.turn`` span is active on the OTel context stack (set in
        invoke()), the client span automatically becomes its child — no extra
        wrapping needed here.  Adding a GovernanceSpan wrapper here would produce
        two nested spans with identical names and attributes (the client span
        inside the wrapper span), corrupting the Phoenix / Arize trace tree.
        """
        if not _role_governed(self._govern_roles, role):
            logger.debug(
                "GovernedGraph: role=%s excluded by govern_roles — not evaluated", role.value,
            )
            return None
        # A.3 — per-class exception disposition. See
        # docs/checkpoints/SDK_Dedup_Review_2026-09-15.md item A.3 and ground
        # rule feedback_no_broad_except_on_governance. Rules:
        #
        #   Transient network/server failures -> fail-open (return None). This is
        #     the only class governance can legitimately fail-open on; the PE is
        #     reachable-but-flaky, the app should keep serving, and the operator
        #     sees a WARN.
        #
        #   Contract-broken failures (4xx from us, pydantic ValidationError,
        #     unknown exceptions) -> fail-loud (re-raise). These indicate an SDK
        #     bug or a wire-shape mismatch — silently swallowing them is what
        #     caused the v1.42 governance-bypass (blank remediation slipping
        #     through as PERMISSIVE). A staging fail-loud beats a prod bypass.
        try:
            request_id = str(uuid.uuid4())
            result = self._client.evaluate(
                content=content,
                role=role,
                request_id=request_id,
                session_id=session_id,
                eval_mode=self._eval_mode,
                raise_on_block=False,
                metadata=metadata,
            )
        except (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadTimeout,
                httpx.WriteTimeout, httpx.PoolTimeout, httpx.NetworkError) as exc:
            # PE unreachable — transient network failure, fail-open.
            logger.warning(
                "[RAI Trust] Policy Engine UNREACHABLE (%s) — this %s evaluation was skipped "
                "and is treated as PERMISSIVE (not enforced). Governance is degraded until the "
                "PE is reachable again. error=%s",
                type(exc).__name__, role.value, exc,
            )
            return None
        except httpx.HTTPStatusError as exc:
            status = getattr(exc.response, "status_code", 0) if exc.response is not None else 0
            if 500 <= status < 600:
                # PE reachable, PE broken — server-side transient, fail-open.
                logger.warning(
                    "[RAI Trust] Policy Engine returned %d for %s — evaluation SKIPPED and "
                    "treated as PERMISSIVE (not enforced). error=%s",
                    status, role.value, exc,
                )
                return None
            # 4xx — our request is malformed. Fail LOUD so the broken release is
            # caught in staging, not silently unenforced in production.
            logger.error(
                "[RAI Trust] Policy Engine returned %d for %s — request malformed. "
                "This is an SDK bug and MUST be surfaced (fail-loud). error=%s",
                status, role.value, exc,
            )
            raise
        except ResponseParseError as exc:
            # SDK<->PE wire contract broken (unknown/missing verdict, malformed body).
            # Fail LOUD — from_response()'s null-coercion catches the common null cases;
            # anything reaching here is a genuine shape/verdict mismatch (version drift).
            # Log the error TYPE only (never the raw exception — data-leakage safe).
            logger.error(
                "[RAI Trust] wire contract violation on %s evaluation — response could not be "
                "parsed into a GovernanceResult (%s). SDK<->PE version drift and MUST be surfaced.",
                role.value, type(exc).__name__,
            )
            raise
        except PolicyUnavailable as exc:
            # PE reachable but has NO policies loaded (HTTP 563). The client already
            # retried (honouring Retry-After) and the PE self-heals once the seed lands,
            # so this is a transient-server condition — SAME disposition as the 5xx/
            # unreachable branches above: fail-open (skip = PERMISSIVE, not enforced) with
            # a distinct, actionable WARN. This does NOT fail-loud, because an unseeded/
            # recovering PE is an operational state, not an SDK bug or contract break.
            logger.warning(
                "[RAI Trust] Policy Engine policy store UNAVAILABLE (HTTP %s) for %s — "
                "evaluation SKIPPED and treated as PERMISSIVE (not enforced). The PE has no "
                "policies loaded yet (unseeded/empty config_policies); it self-heals once the "
                "seed Job runs. request_id=%s",
                getattr(exc, "status", 563), role.value,
                getattr(exc, "request_id", "?"),
            )
            return None
        except (GovernanceBlock, HITLInterrupt, AgentEvicted):
            # Governance control-flow signals — not errors. Let them propagate.
            raise
        except Exception as exc:
            # Unknown exception. Fail LOUD with a traceback — an unknown class
            # here is almost certainly an SDK bug that a broad fail-open would
            # hide. If a NEW transient class shows up in production and needs to
            # be fail-open, add it as a named branch above with a comment.
            logger.exception(
                "[RAI Trust] Unknown exception on %s evaluation — fail-loud (surface the bug). "
                "class=%s error=%s", role.value, type(exc).__name__, exc,
            )
            raise

        # Skip the synthetic ASYNC ack (async_dispatched) — the background worker
        # fires on_result with the REAL verdict; firing here too would double/mislead.
        if self._on_result and not getattr(result, "async_dispatched", False):
            try:
                self._on_result(result, role)
            except Exception:
                pass
        return result

    def _enforce(
        self,
        result: GovernanceResult,
        role: ContentRole,
    ) -> Optional[str]:
        """
        Apply enforcement policy to a GovernanceResult.

        Returns a substitute message string if the content should be replaced
        (REDACT mode, COERCIVE verdict), or raises GovernanceBlock (RAISE mode).
        Returns None when execution should continue unchanged.
        """
        if result.verdict != Verdict.COERCIVE:
            if result.verdict == Verdict.NORMATIVE:
                logger.info(
                    "GovernedGraph: NORMATIVE verdict — role=%s violations=%s",
                    role.value, result.violations,
                )
                # ADVISE: surface the advisory to the app first-class, not just a log
                # line. The app reads gov.last_advisories to warn / disclaim / log.
                #
                # NOTE — the NORMATIVE *gated hold* ("cannot proceed until the remediation
                # is effected") is actuated on the ACTION request, i.e. the tool_call at
                # Layer 2 (see _ToolGuardCallback.on_tool_start → GovernanceHold). L1
                # (user_prompt) and L3 (llm_response) remain ADVISORY here on purpose: an
                # llm_response is an output, whose NORMATIVE actuation is REVISION, not a
                # hold — extending the hold to L1/L3 is a deliberate follow-on, not an
                # oversight, so existing response-revision flows are not silently replaced.
                self._last_advisories.append({
                    "role":          role.value,
                    "violations":    list(result.violations or []),
                    "response_text": getattr(result, "response_text", "") or "",
                })
            return None   # PERMISSIVE or NORMATIVE (advisory at L1/L3) — proceed

        # COERCIVE verdict below
        logger.warning(
            "GovernedGraph: COERCIVE verdict — role=%s enforcement=%s violations=%s",
            role.value, self._enforcement_mode.value, result.violations,
        )

        # ASYNC = observe-only: the evaluation still ran, logged, and fired on_result,
        # but enforcement is suppressed — a COERCIVE verdict never blocks/redacts/raises.
        # (enforcement_mode is intentionally ignored in ASYNC; see instrument() docstring.)
        if self._observe_only:
            logger.info(
                "GovernedGraph: ASYNC observe-only — COERCIVE NOT enforced (role=%s)",
                role.value,
            )
            return None

        if self._enforcement_mode == EnforcementMode.RAISE:
            raise GovernanceBlock(result)

        if self._enforcement_mode == EnforcementMode.REDACT:
            # Prefer response_text (PE-rendered, context-aware refusal via MessageWriter).
            # Fall back to legacy remediations[0], then the generic safe refusal.
            return (
                result.response_text
                or (result.remediations[0] if result.remediations else None)
                or _REDACT_COERCIVE
            )

        # NONE — log only, return None so execution continues
        return None

    def _build_config(
        self,
        config: Optional[Dict],
        session_id: Optional[str],
    ) -> tuple:
        """
        Merge user config with the Layer 2 tool guard callback.

        Returns ``(merged_config_dict, tool_cb)`` so callers can read
        accumulated token usage from the callback after graph execution.
        """
        merged = dict(config or {})
        tool_cb = _ToolGuardCallback(
            client=self._client,
            app_id=self._app_id,
            tool_filter=self._tool_filter,
            govern_roles=self._govern_roles,
            agent_nodes=self._agent_nodes,
            a2a_tools=self._a2a_tools,
            session_id=session_id,
            eval_mode=self._eval_mode,
            enforcement_mode=self._enforcement_mode,
            on_result=self._on_result,
            tracer=self._tracer,
            hitl_on_normative_a2a=self._hitl_on_normative_a2a,
            hitl_normative_threshold=self._hitl_normative_threshold,
            hitl_normative_counts=self._hitl_normative_counts,   # shared by reference
            hitl_cleared_sessions=self._hitl_cleared_sessions,   # shared by reference
            node_evidence=self._node_evidence,                   # shared by reference (discovery)
            evicted_agents=self._evicted_agents,                 # shared by reference (eviction)
            observed_edges=self._observed_edges,                 # shared by reference (observed A2A)
            ev_lock=self._ev_lock,                               # shared by reference (one discovery lock)
            govern_returns=self._govern_returns,
            govern_handoffs=self._govern_handoffs,
        )
        existing = merged.get("callbacks", [])
        merged["callbacks"] = list(existing) + [tool_cb]
        return merged, tool_cb


# ── Layer 2: Tool callback ────────────────────────────────────────────────────

# The three intentional control-flow signals a governance callback is ALLOWED to raise into
# the host graph. Matched by class NAME so the guard never depends on how/where these
# exceptions are imported within this module.
_CONTROL_FLOW_EXC = frozenset({"GovernanceBlock", "GovernanceHold", "HITLInterrupt", "AgentEvicted"})


def _never_crash(method):
    """Bulletproof a governance callback: it may raise ONLY the intentional control-flow
    signals (GovernanceBlock / GovernanceHold / HITLInterrupt / AgentEvicted). Every OTHER exception — a
    malformed LangChain payload (serialized=None), a None state, a misbehaving custom proxy,
    a provider quirk — is logged and SWALLOWED, protecting the host. `_ToolGuardCallback`
    sets ``raise_error = True``, which makes LangChain re-raise anything a callback throws
    straight into the customer's ``app.invoke()``; this decorator is the guarantee that only
    the three intended signals ever reach there. The SDK is a lynchpin — it must NEVER crash
    the host application."""
    @functools.wraps(method)
    def _wrapped(self, *args, **kwargs):
        try:
            return method(self, *args, **kwargs)
        except Exception as exc:
            if type(exc).__name__ in _CONTROL_FLOW_EXC:
                raise                                              # intentional governance signal
            try:
                logger.warning("[RAI Trust] governance callback %s swallowed a non-fatal error "
                               "(host protected): %s", getattr(method, "__name__", "?"), exc)
            except Exception:
                pass
            return None
    return _wrapped


class _ToolGuardCallback(_CALLBACK_BASE):
    """
    LangChain callback that intercepts tool and LLM lifecycle events to
    enforce governance policies via the RAI Trust Platform.

    Inherits from BaseCallbackHandler so LangChain's CallbackManager registers
    this handler for ALL event types — including on_llm_end (token counting)
    and on_tool_start (tool-call governance and A2A evaluation).

    Without BaseCallbackHandler inheritance, on_tool_start fires (BaseTool uses
    duck typing) but on_llm_end is silently dropped by CallbackManager, causing
    token counts to never accumulate.
    """

    # raise_error=True: when on_tool_start or on_chain_start raises GovernanceBlock
    # or HITLInterrupt, LangChain's CallbackManager re-raises it instead of
    # swallowing it.  Without this, both exceptions are caught and logged as
    # warnings and the tool executes regardless of the governance verdict.
    raise_error        = True
    ignore_llm         = False
    ignore_chain       = False
    ignore_agent       = False
    ignore_retriever   = False
    ignore_chat_model  = False
    ignore_custom_event = False

    def __init__(
        self,
        client: TrustClient,
        app_id: str,
        tool_filter: Optional[Set[str]],
        agent_nodes: Optional[Set[str]],
        a2a_tools: Optional[Dict[str, str]],
        session_id: Optional[str],
        eval_mode: EvalMode,
        enforcement_mode: EnforcementMode,
        on_result: Optional[Callable],
        tracer: Any = None,
        govern_roles: Optional[Set[Any]] = None,
        hitl_on_normative_a2a: bool = False,
        hitl_normative_threshold: int = 2,
        hitl_normative_counts: Optional[Dict[str, int]] = None,
        hitl_cleared_sessions: Optional[Set[str]] = None,
        node_evidence: Optional[Dict[str, Any]] = None,
        evicted_agents: Optional[Set[str]] = None,
        govern_returns: bool = False,
        govern_handoffs: Optional[bool] = None,
        observed_edges: Optional[Set[Tuple[str, str]]] = None,
        ev_lock: Optional[Any] = None,
    ) -> None:
        # Initialise BaseCallbackHandler (sets up internal run tracking dicts).
        # Use try/except so the SDK still works if langchain_core is unavailable.
        try:
            super().__init__()
        except Exception:
            pass

        self._client           = client
        self._app_id           = app_id
        self._tool_filter      = tool_filter
        self._govern_roles     = govern_roles   # None = govern all roles (scoping, Concern 4)
        self._agent_nodes      = agent_nodes   # on_chain_start-based A2A (version-dependent)
        self._a2a_tools        = a2a_tools     # on_tool_start-based A2A (guaranteed)
        self._session_id       = session_id
        self._eval_mode        = eval_mode
        self._enforcement_mode = enforcement_mode
        self._on_result        = on_result
        self._tracer           = tracer        # OTel tracer (None = no spans)
        self._govern_returns   = govern_returns
        # A2A evaluation of Command(goto=...) handoffs (Pattern B/C) is ON by default:
        # a node/tool returning Command(goto=X) is a genuine agent->agent handoff, so the
        # SDK governs it as agent_to_agent out of the box. A deployment opts OUT with
        # RAI_GOVERN_HANDOFFS=false; an explicit bool from instrument()/GovernedGraph wins.
        _gh_env = os.getenv("RAI_GOVERN_HANDOFFS")
        self._govern_handoffs  = (
            govern_handoffs if govern_handoffs is not None
            else True if _gh_env in (None, "")
            else _env_truthy("RAI_GOVERN_HANDOFFS")
        )
        # run_id -> (responding_agent, calling_agent, tool_name), stashed at on_tool_start so
        # on_tool_end can attribute the RETURN correctly (source = responder, target = caller).
        self._a2a_return_ctx: Dict[Any, tuple] = {}
        # run_ids for which on_tool_start ALREADY fired an AGENT_TO_AGENT eval via the
        # a2a_tools allowlist. on_tool_end consults this to DEDUP: a handoff tool that
        # was already governed as A2A at call-time must not be RE-evaluated as a
        # Pattern-C Command handoff (that would double-count MyBank's council). Popped
        # in on_tool_end / on_tool_error so it cannot leak across runs.
        self._a2a_evaluated_runs: Set[Any] = set()

        # HITL state (shared references from GovernedGraph — persist across turns)
        self._hitl_on_normative_a2a    = hitl_on_normative_a2a
        self._hitl_normative_threshold = hitl_normative_threshold
        self._hitl_normative_counts    = hitl_normative_counts if hitl_normative_counts is not None else {}
        self._hitl_cleared_sessions    = hitl_cleared_sessions if hitl_cleared_sessions is not None else set()

        # ── Runtime state (updated during graph execution) ────────────────
        self._current_node: Optional[str] = None
        # Agent-as-tool identity lives in the _TOOL_STACK ContextVar (see module top),
        # not on the instance: it is a property of the execution context, and LangGraph
        # runs a ToolNode's batch on concurrent threads spawned via copy_context().
        # (caller, agent) pairs that ACTUALLY ran. Shared by reference from
        # GovernedGraph: this callback is rebuilt per invoke() and dropped, so an
        # edge set owned HERE dies with it and is unreadable from the instrumented
        # graph. (That unreachability is exactly why observed edges were once
        # reported as 0 — the number was never measured. They are reachable now via
        # GovernedGraph.observed_edges / get_discovered_agents()['observed_edges'].)
        self._observed_edges: Set[Tuple[str, str]] = (
            observed_edges if observed_edges is not None else set())
        # run_id -> owning agent, stashed at on_chat_model_start so on_llm_end can
        # attribute its result WITHOUT reading the shared self._current_node.
        # run_id is unique per LLM call and identical across that call's start/end.
        self._llm_owner: Dict[Any, str] = {}
        # run_id -> owning node, stashed at on_chain_start so on_chain_end can name
        # the SOURCE of a Command(goto=...) it returns (Pattern B's handoff).
        # MEASURED: on_chain_end receives NO metadata at all — kwargs are exactly
        # ('parent_run_id', 'tags') — so it can see the Command but cannot say who
        # returned it. on_chain_start DOES carry metadata, and fires with the SAME
        # run_id. That correlation is the only bridge between the two facts, and
        # without it the target is knowable while the source is not.
        self._chain_owner: Dict[Any, str] = {}
        # run_id -> (tool_name, caller), stashed at on_tool_start so on_tool_end can
        # name the SOURCE of a Command a handoff TOOL returns (Pattern C's handoff).
        # Keyed by run_id rather than read off _TOOL_STACK because on_tool_end must
        # pop its frame before any early return; run_id is stable across the pair.
        self._tool_ctx: Dict[Any, Tuple[str, Optional[str]]] = {}
        # Shared by reference from GovernedGraph so readers (there) and writers (here) take the
        # SAME lock. Falls back to a private lock only if constructed standalone (e.g. tests).
        self._ev_lock = ev_lock if ev_lock is not None else threading.Lock()
        self._current_model: Optional[str] = None   # legacy fallback; the run_id-keyed _llm_model wins
        # run_id -> model id, stashed at on_chat_model_start so on_llm_end attributes the model
        # to THIS call rather than reading the racy shared _current_model scalar (mirrors _llm_owner).
        self._llm_model: Dict[Any, str] = {}
        self._tok_lock = threading.Lock()           # guards the _token_usage RMW (concurrent ToolNode batch)
        # token_usage[node_name] = {prompt_tokens, completion_tokens, total_tokens, model}
        self._token_usage: Dict[str, Dict[str, Any]] = {}
        # Per-node behavioral evidence for non-heuristic agent discovery (observe-only).
        # Shared by reference from GovernedGraph so it persists across invocations.
        self._node_evidence: Dict[str, Dict[str, Any]] = node_evidence if node_evidence is not None else {}
        # Standing eviction set, shared by reference from GovernedGraph.
        self._evicted_agents: Set[str] = evicted_agents if evicted_agents is not None else set()
        # OTel span context managers:
        # _active_node_spans  — keyed by node name; a node span stays open until
        #                       the NEXT different node starts (or turn ends).
        #                       Value is (span, ctx_mgr) tuple so we can fall back
        #                       to span.end() if the context manager's __exit__
        #                       fails across LangGraph copy_context() boundaries.
        # _node_span_ctxs     — keyed by LangChain run_id (on_chain_start path,
        #                       kept for compatibility when on_chain_start fires).
        # _tool_span_ctxs     — keyed by LangChain run_id (on_tool_start/end path).
        self._active_node_spans: Dict[str, Any] = {}  # node_name → (span, ctx_mgr)
        self._node_span_ctxs:   Dict[UUID, Any] = {}  # run_id → ctx_mgr
        self._tool_span_ctxs:   Dict[UUID, Any] = {}  # run_id → ctx_mgr

    # ── Agent-discovery evidence helpers (observe-only) ───────────────────────
    def _ev(self, node: str) -> Dict[str, Any]:
        """Get-or-create the behavioral evidence record for a node.

        setdefault, not get-then-set: a ToolNode runs its batch of tool calls on
        CONCURRENT THREADS, so check-then-act here lets two threads each build a
        fresh record and the second clobber the first's counts. setdefault is a
        single atomic dict operation.
        """
        return self._node_evidence.setdefault(node, _new_node_evidence())

    def _bump(self, node: str, field: str, n: int = 1) -> None:
        """Increment one evidence counter for `node`, atomically.

        `ev[field] += n` is a read-modify-write over THREE bytecodes; the 49
        concurrent tool threads of a ToolNode batch all credit the coordinator's
        tool_execs, so unlocked increments silently lose updates. The lock is
        free relative to the LLM call that triggered it.

        Callers MUST pass the owner resolved on THIS thread (_owner_node /
        _active_tool), never self._current_node — see on_chat_model_start.
        """
        if not node:
            return
        with self._ev_lock:
            self._ev(node)[field] += n

    def _owner_node(self, metadata: Optional[Dict[str, Any]],
                    parent_run_id: Optional[Any] = None) -> Optional[str]:
        """WHICH AGENT does this callback belong to?

        `metadata['langgraph_node']` alone is NOT the answer for a nested agent. A subgraph
        built by `create_react_agent` names its inner nodes 'agent' and 'tools' — EVERY time.
        So attributing on langgraph_node collapses every agent in the app onto two shared
        buckets, and their evidence SUMS into a record belonging to nobody. Measured: 50
        distinct agents deliberating produced one 'agent' record with llm_calls=28, and two
        agents (one that ran everything, one that never ran) held byte-identical evidence.
        That is worse than missing data — it is confident, wrong data.

        LangGraph gives us the ownership chain in `langgraph_checkpoint_ns`:

            'risk_agent:a0b97ebe-…|agent:c7a115c9-…'
             ^ owning parent node   ^ create_react_agent's internal node

        The OUTERMOST segment is the node the host graph actually knows — the agent whose name
        appears in the topology and on a governance card. Attribute there.

        (Verified against langgraph 1.1.6 by dumping live callback metadata. Note also that
        `serialized['name']` is None for LangGraph node chain-starts, so it is not a usable
        identity source — metadata is.)
        """
        # AGENT-AS-TOOL (Pattern A): the tool currently executing in THIS context. A sub-agent
        # reached through a tool is not a graph node, so node-seeded discovery is structurally
        # blind to it — but running it gives it away: work happening beneath a tool's own
        # execution means that tool did not merely compute, something inside it thought. We
        # name it by the tool, because that is the only identity its caller ever has. No code
        # reading, no name heuristics — the graph is discovered by executing it.
        active = self._active_tool()
        if active is not None:
            return active[0]

        md = metadata or {}
        ns = md.get("langgraph_checkpoint_ns") or ""
        if ns:
            return (ns.split("|", 1)[0].split(":", 1)[0] or None)   # outermost owning node
        return (md.get("langgraph_node") or "") or None

    def _active_tool(self) -> Optional[Tuple[str, Optional[str]]]:
        """(tool_name, caller) of the innermost tool executing in this context, if any."""
        st = _TOOL_STACK.get()
        return st[-1] if st else None

    def _record_command_edges(self, source: Optional[str], payload: Any) -> None:
        """
        Record ``source -> target`` for every target a returned Command hands
        control to — an OBSERVED handoff, taken from the Command the app really
        returned rather than from an optional `destinations=` annotation.

        This is the whole difference between "these two agents talked" and "a
        developer wrote a type annotation": delete the annotation and this still
        fires, because the transfer still happened.

        Self-edges are dropped: `from == to` is not a handoff between peers by
        definition (the same invariant the agent-as-tool path holds).
        """
        if not source or payload is None:
            return
        for target in _command_targets(payload):
            if target != source:
                with self._ev_lock:              # serialize with the discovery readers' snapshot
                    self._observed_edges.add((source, target))

    def _govern_handoff(
        self,
        source: Optional[str],
        payload: Any,
        *,
        tool_name: Optional[str] = None,
    ) -> None:
        """OBSERVE-ONLY AGENT_TO_AGENT evaluation of a Command(goto=...) handoff.

        A node (Pattern B) or tool (Pattern C) returning a Command TRANSFERS control
        `source -> target` — a genuine inter-agent handoff. The SDK already OBSERVES
        this for discovery (see _record_command_edges) but has never EVALUATED it, so
        Pattern-B/C handoffs reach the PE only as `tool_call` and never as
        `agent_to_agent` — which is exactly the role the conflict/deadlock detector
        consumes. This closes that gap: same `source`/`target` the edge uses, emitted
        as an A2A turn so the detector sees the coordinator<->specialist cycle.

        Contract (matches the whole hardening branch's demo-safe posture):
          • OBSERVE-ONLY — the transfer already happened (node finished / tool
            returned), so it CANNOT be blocked. raise_on_block=False; this feeds the
            async detector, it is not a synchronous gate.
          • FLAG-GATED — callers only reach here when self._govern_handoffs is True
            (RAI_GOVERN_HANDOFFS). Default OFF ⇒ no extra evaluate() calls.
          • CAP-CLEAN — metadata carries tool_name="__handoff__" (a synthetic marker,
            never a real council tool). The PE only counts A2A messages whose
            tool_name is in _A2A_SENTINEL_TOOLS toward the legacy A2A HITL cap
            (accumulate_a2a); "__handoff__" is excluded there, so these observations
            do NOT move MyBank's card-denial council HITL trigger. handoff_observed
            is also stamped so the PE (or a detector) can distinguish these from
            allowlisted a2a_tools evals. NOTE: an EMPTY tool_name would be treated as
            eligible by the PE and counted — so a non-empty marker is REQUIRED here.
        """
        if not source or payload is None:
            return
        for target in _command_targets(payload):
            if not target or target == source:
                continue   # self-edges aren't peer handoffs (mirrors _record_command_edges)
            content = self._format_handoff_content(source, target, tool_name, payload)
            try:
                result = self._client.evaluate(
                    content=content,
                    role=ContentRole.AGENT_TO_AGENT,
                    request_id=str(uuid.uuid4()),
                    session_id=self._session_id,
                    eval_mode=self._eval_mode,
                    raise_on_block=False,          # OBSERVE-ONLY: the handoff already happened
                    metadata={
                        # C.8 canonical edge keys — the ACTOR is the caller (source); target is
                        # the callee. from_agent drives agent_id (see core-client resolution).
                        "from_agent":       source,          # caller   (A2A source, the actor)
                        "to_agent":         target,          # callee   (A2A target)
                        "agent_name":       target,          # legacy alias (callee) — kept for wire-compat
                        "source_agent":     source,          # A2A source alias — kept for wire-compat
                        "tool_name":        "__handoff__",   # cap-clean marker (NOT in _A2A_SENTINEL_TOOLS)
                        "handoff_observed": True,            # distinguishes from allowlisted a2a_tools evals
                        "handoff_tool":     tool_name or "", # audit: the real tool (Pattern C) or "" (Pattern B)
                    },
                )
                if self._on_result and not getattr(result, "async_dispatched", False):
                    try:
                        self._on_result(result, ContentRole.AGENT_TO_AGENT)
                    except Exception:
                        pass
            except Exception as _hex:
                logger.warning(
                    "GovernedGraph: handoff governance failed (non-fatal) %s -> %s: %s",
                    source, target, _hex,
                )

    def _format_handoff_content(
        self,
        source: str,
        target: str,
        tool_name: Optional[str],
        payload: Any,
    ) -> str:
        """Build the evaluable content for an observed handoff.

        The edge (source -> target) is the primary signal the structural detector
        keys on; the Command's `update` (minus the raw message objects) supplies the
        semantic substance — e.g. a specialist's computed card position — that the
        Stage-B judge can read.
        """
        parts = [f"Agent handoff (observed): {source} -> {target}"]
        if tool_name:
            parts.append(f"via tool: {tool_name}")
        upd = getattr(payload, "update", None)
        if isinstance(upd, dict):
            summary = {k: v for k, v in upd.items() if k != "messages"}
            if summary:
                parts.append(f"context: {str(summary)[:1500]}")
        return "\n".join(parts)

    def discovered_topology(self) -> Dict[str, Any]:
        """
        Classify every observed node from accumulated evidence. Returns
        {node_name: {"kind": <...>, "evidence": {...}}}. Additive/observe-only —
        does not affect enforcement or the legacy agent_nodes/a2a_tools path.
        """
        with self._ev_lock:                      # snapshot under lock — writers add keys concurrently
            _items = {name: dict(ev) for name, ev in self._node_evidence.items()}
        return {
            name: {"kind": _classify_node(ev), "evidence": ev}
            for name, ev in _items.items()
        }

    @_never_crash
    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Fire BEFORE a tool executes."""
        serialized = serialized or {}                # LangChain can dispatch serialized=None
        tool_name = serialized.get("name", "")
        # Discovery signal: attribute the tool exec to the OWNING agent — see
        # _owner_node (metadata['langgraph_node'] alone cannot name a nested agent).
        _md = kwargs.get("metadata") or {}
        # WHO called this tool — resolved BEFORE pushing, so a tool is never its own caller.
        _caller = self._owner_node(_md)
        if tool_name:
            _TOOL_STACK.set(_TOOL_STACK.get() + ((tool_name, _caller),))
            # Pattern C: this tool may RETURN a Command(goto=...) and transfer
            # control. on_tool_end sees the Command but gets no metadata, so stash
            # who called us now, while we can still tell.
            self._tool_ctx[run_id] = (tool_name, _caller)

        # ATTRIBUTE ON THE CONTEXT-LOCAL OWNER, NEVER ON self._current_node.
        # _owner_node() resolves the caller correctly for THIS context, but laundering
        # it through the ONE shared _current_node scalar throws that away: a ToolNode
        # runs its batch concurrently, so between the store and the load below any of
        # the other 48 threads can overwrite it and the increment — and the eviction
        # check — land on the wrong agent. `owner` is THIS context's answer.
        # Identical to the old value single-threaded; only concurrency differs.
        owner = _caller or self._current_node
        if _caller:
            self._current_node = _caller   # still maintained for the OTel/audit paths
        if owner:
            self._bump(owner, "tool_execs")
            # eviction enforcement: an evicted agent must not invoke tools
            if owner in self._evicted_agents:
                raise AgentEvicted(owner)

        # ── OTel tool span ────────────────────────────────────────────────────
        # Opens a TOOL span as a child of the active node span.
        # Tool spans use start_as_current_span (unlike node spans) because
        # on_tool_start and on_tool_end fire within the same BaseTool.invoke()
        # call, so they are always in the same copy_context — no boundary issue.
        # Span is stored in _tool_span_ctxs and closed in on_tool_end /
        # on_tool_error.  If GovernanceBlock is raised below (tool blocked),
        # the span is closed inline before re-raising.
        if self._tracer:
            try:
                # Use the node span's context as explicit parent so the tool
                # span nests correctly even though the node span was created
                # via start_span() (not start_as_current_span).
                node_entry = self._active_node_spans.get(self._current_node or "")
                parent_ctx = node_entry[1] if node_entry else None  # (span, ctx)[1]

                ctx_mgr = self._tracer.start_as_current_span(
                    f"rai.tool.{tool_name}",
                    context=parent_ctx,  # explicit parent = active node span
                )
                span = ctx_mgr.__enter__()
                span.set_attribute("openinference.span.kind", "TOOL")
                span.set_attribute("tool.name", tool_name)
                # Truncate large inputs so Phoenix doesn't reject the span
                span.set_attribute("input.value", input_str[:2000])
                if self._session_id:
                    span.set_attribute("session.id", self._session_id)
                self._tool_span_ctxs[run_id] = ctx_mgr
            except Exception as _exc:
                logger.debug("GovernedGraph: tool span open failed: %s", _exc)

        if self._tool_filter is not None and tool_name not in self._tool_filter:
            return  # Not in filter list — skip governance evaluation

        # ── A2A via tool trigger (guaranteed across all LangGraph versions) ──
        # When a tool is declared in a2a_tools, the act of calling it
        # represents an inter-agent handoff.  Evaluate the tool's input
        # (which contains the agent's working context — e.g. wire details)
        # as AGENT_TO_AGENT *before* the normal TOOL_CALL evaluation.
        #
        # SELF-LOOP GUARD. a2a_tools maps "<tool> → <owner agent>", i.e. calling
        # <tool> is a handoff TO <owner>. But when the CALLER already IS <owner>,
        # the agent is invoking its OWN tool — not an inter-agent handoff. Firing
        # AGENT_TO_AGENT here forges a from==to self-edge (e.g. intl_wire_agent →
        # intl_wire_agent on its own international_transfer call) — the exact
        # phantom the interaction graph must never show — and the same self-loop
        # on the RESPONSE via govern_returns. Pre-resolve caller + owner so a
        # self-handoff falls through to the normal TOOL_CALL path below. A
        # DIFFERENT caller (e.g. domestic_agent reaching across) still yields a
        # genuine A2A with source != target.
        _a2a_owner  = self._a2a_tools.get(tool_name) if self._a2a_tools else None
        _a2a_caller = self._declared_from_agent(input_str) or self._current_node
        _a2a_self_loop = bool(_a2a_owner and _a2a_caller and _a2a_caller == _a2a_owner)
        if _a2a_self_loop:
            logger.info(
                "GovernedGraph: A2A self-loop suppressed — '%s' called its own tool "
                "'%s'; governing as TOOL_CALL (no from==to edge).", _a2a_caller, tool_name,
            )
        if (self._a2a_tools and tool_name in self._a2a_tools
                and _role_governed(self._govern_roles, ContentRole.AGENT_TO_AGENT)
                and not _a2a_self_loop):
            a2a_agent = self._a2a_tools[tool_name]
            # DEDUP marker for the Pattern-C handoff path: this tool call is being
            # governed as AGENT_TO_AGENT right here. If it ALSO returns a Command(goto=)
            # (a handoff tool), on_tool_end must NOT re-evaluate that transfer — the
            # act is already on the feed. Recorded before any raise below so a blocked
            # handoff tool is still correctly marked (on_tool_error clears it).
            self._a2a_evaluated_runs.add(run_id)
            # Capture the CALLING agent before potentially overwriting _current_node.
            # This becomes source_agent in the A2A audit metadata so the interaction
            # graph can derive a meaningful edge (source ≠ target).
            _src_agent = self._current_node  # may be None if on_chain_start never fired
            # A graph may DECLARE the handoff source explicitly by passing
            # `from_agent` in the tool input. on_chain_start does not reliably set
            # _current_node across LangGraph versions, so an explicit from_agent is
            # authoritative for the interaction graph — it lets a front-line agent
            # (e.g. "banking_agent") appear as the source of its handoff to the
            # coordinator instead of being dropped (empty source → no edge).
            _declared_src = self._declared_from_agent(input_str)
            if _declared_src:
                _src_agent = _declared_src
            if self._current_node is None:
                self._current_node = a2a_agent

            # Remember who called whom, so on_tool_end can govern the RESPONSE with the
            # direction flipped (responder -> caller). Cheap map, popped on return.
            if self._govern_returns:
                self._a2a_return_ctx[run_id] = (a2a_agent, _src_agent or "", tool_name)

            # ── Token attribution resolution ──────────────────────────────
            # LangGraph fires on_chain_start with the Python function name
            # (e.g. "intl_wire_agent_node") rather than the label we used in
            # a2a_tools ("intl_wire_agent"), or may not fire it at all.
            # Try all three possible keys the pre-tool LLM calls may be under.
            a2a_tok = (
                self._token_usage.get(a2a_agent)           # exact match
                or self._token_usage.get(f"{a2a_agent}_node")  # _node suffix variant
                or self._token_usage.get("_unknown")        # on_chain_start didn't fire
                or {}
            )
            logger.info(
                "GovernedGraph: Layer A2A (tool-trigger) — evaluating "
                "AGENT_TO_AGENT for tool '%s' → agent '%s' tokens=%s",
                tool_name, a2a_agent, a2a_tok.get("total_tokens", 0),
            )
            a2a_content = self._format_a2a_tool_content(tool_name, input_str, a2a_agent)
            try:
                a2a_result = self._client.evaluate(
                    content=a2a_content,
                    role=ContentRole.AGENT_TO_AGENT,
                    request_id=str(uuid.uuid4()),
                    session_id=self._session_id,
                    eval_mode=self._eval_mode,
                    raise_on_block=False,
                    metadata={
                        # C.8 — from_agent + to_agent on every audit row.
                        # A2A: from = calling agent, to = target agent.
                        "from_agent":    _src_agent or "",
                        "to_agent":      a2a_agent,
                        # Deprecated aliases kept for one release for wire-compat:
                        "agent_name":    a2a_agent,
                        "source_agent":  _src_agent or "",
                        "tool_name":     tool_name,
                        "agent_tokens":  a2a_tok,
                    },
                )
                if self._on_result and not getattr(a2a_result, "async_dispatched", False):
                    try:
                        self._on_result(a2a_result, ContentRole.AGENT_TO_AGENT)
                    except Exception:
                        pass
                if (a2a_result.verdict == Verdict.COERCIVE
                        and self._enforcement_mode != EnforcementMode.NONE
                        and self._eval_mode != EvalMode.ASYNC):   # ASYNC = observe-only
                    logger.warning(
                        "GovernedGraph: A2A COERCIVE (tool-trigger) — blocking "
                        "tool '%s' violations=%s", tool_name, a2a_result.violations,
                    )
                    # Close tool span before blocking so it's properly exported
                    _close_span_ctx(self._tool_span_ctxs.pop(run_id, None))
                    raise GovernanceBlock(a2a_result)

                # ── HITL: directive-based check (primary path) ────────────
                # The PE signals REQUIRE_HUMAN_REVIEW via a Directive in the
                # response.  Check directives first — they carry full context
                # (category, options, source) needed for the HITL UI.
                # agent=a2a_agent / tool=tool_name propagate into the payload
                # so server-side handlers can identify the originating agent
                # (e.g. distinguish card_advisor A2A from transfer_agent HITL).
                if self._eval_mode != EvalMode.ASYNC:   # ASYNC = observe-only, no HITL pause
                    _raise_if_hitl_directive(
                        a2a_result,
                        self._session_id,
                        run_id=run_id,
                        span_ctxs=self._tool_span_ctxs,
                        agent=a2a_agent,
                        tool=tool_name,
                        cleared_sessions=self._hitl_cleared_sessions,
                        role="agent_to_agent",
                    )

                # ── HITL: deprecated counter fallback ────────────────────
                # Legacy mechanism kept for backward compatibility when
                # hitl_on_normative_a2a=True is explicitly set and no PE
                # directive was present. Slated for removal — the primary
                # mechanism is now PE REQUIRE_HUMAN_REVIEW directives.
                # B.6 — when the counter DOES fire, take the same adaptive
                # path as the primary handler: call native interrupt() when the
                # graph is checkpointer-wired inside a node, else raise
                # HITLInterrupt. This unifies pause semantics across sources.
                if (a2a_result.verdict != Verdict.COERCIVE
                        and self._hitl_on_normative_a2a
                        and self._eval_mode != EvalMode.ASYNC):   # ASYNC = observe-only
                    sid = self._session_id or ""
                    if sid not in self._hitl_cleared_sessions:
                        self._hitl_normative_counts[sid] = (
                            self._hitl_normative_counts.get(sid, 0) + 1
                        )
                        count = self._hitl_normative_counts[sid]
                        logger.info(
                            "GovernedGraph: [DEPRECATED] counter-based NORMATIVE "
                            "A2A count=%d/%d session=%s tool=%s — "
                            "prefer PE REQUIRE_HUMAN_REVIEW directive instead",
                            count, self._hitl_normative_threshold, sid, tool_name,
                        )
                        if count >= self._hitl_normative_threshold:
                            _close_span_ctx(self._tool_span_ctxs.pop(run_id, None))
                            _payload = {
                                "pattern":         "suspend",
                                "reason":          "governance_review_required",
                                "category":        None,
                                "options":         [],
                                "source":          "sdk_counter",
                                "violations":      a2a_result.violations or [],
                                "agent":           a2a_agent,
                                "tool":            tool_name,
                                "session_id":      sid,
                                "normative_count": count,
                            }
                            # B.6 — adaptive path selection.
                            try:
                                from rai_sdk_langgraph import hitl as _hitl_mod
                                if _hitl_mod.can_use_native_interrupt():
                                    _native_interrupt = _hitl_mod._import_native_interrupt()
                                    if _native_interrupt is not None:
                                        decision = _native_interrupt(_payload)
                                        # Resumed with a decision — treat as approved.
                                        # (No further action; return to normal flow.)
                                        logger.info(
                                            "GovernedGraph: Path-B counter resumed via "
                                            "native interrupt with decision=%r", decision,
                                        )
                                        return
                            except Exception as _adx:
                                logger.debug(
                                    "GovernedGraph: adaptive HITL probe failed on Path-B "
                                    "counter, falling back to exception path: %s", _adx,
                                )
                            raise HITLInterrupt(_payload)
            except (GovernanceBlock, HITLInterrupt):
                raise  # Propagate both block and HITL interrupt to the graph caller
            except Exception as exc:
                logger.warning(
                    "[RAI Trust] Policy Engine UNREACHABLE — agent-to-agent handoff via tool "
                    "'%s' was not evaluated and is treated as PERMISSIVE (allowed to proceed). "
                    "error=%s", tool_name, exc,
                )

        # Layer 2 (TOOL_CALL) scoping: skip entirely if tool_call is not in govern_roles.
        if not _role_governed(self._govern_roles, ContentRole.TOOL_CALL):
            return

        # NONE enforcement: evaluate for observability but never block
        if self._enforcement_mode == EnforcementMode.NONE:
            self._evaluate_and_notify(tool_name, input_str, run_id)
            return

        content = f"Tool: {tool_name}\nInput: {input_str}"
        logger.debug("GovernedGraph: Layer 2 — evaluating TOOL_CALL for '%s'", tool_name)

        try:
            node = self._current_node or ""
            result = self._client.evaluate(
                content=content,
                role=ContentRole.TOOL_CALL,
                request_id=str(run_id),
                session_id=self._session_id,
                eval_mode=self._eval_mode,
                raise_on_block=False,
                metadata={
                    # C.8 — L2 TOOL_CALL: from = calling agent (node), to = tool.
                    "from_agent":   node,
                    "to_agent":     tool_name,
                    # Deprecated alias kept for one release for wire-compat:
                    "agent_name":   node,
                    "tool_name":    tool_name,
                    "agent_tokens": (
                        self._token_usage.get(node)
                        or self._token_usage.get("_unknown")
                        or {}
                    ),
                },
            )
            if self._on_result and not getattr(result, "async_dispatched", False):
                try:
                    self._on_result(result, ContentRole.TOOL_CALL)
                except Exception:
                    pass

            if result.verdict == Verdict.COERCIVE and self._eval_mode != EvalMode.ASYNC:
                # Both REDACT and RAISE modes must block the tool call. ASYNC is
                # observe-only, so a COERCIVE tool verdict is logged but not blocked.
                # GovernedGraph.invoke() catches this and applies the mode-specific
                # response (substitute message for REDACT, re-raise for RAISE).
                logger.warning(
                    "GovernedGraph: Layer 2 COERCIVE — blocking tool '%s' violations=%s",
                    tool_name, result.violations,
                )
                # Close tool span before blocking so it's properly exported
                _close_span_ctx(self._tool_span_ctxs.pop(run_id, None))
                raise GovernanceBlock(result)

            # Check for HITL directives (e.g. SANCTIONS_REVIEW on tool execution).
            # ASYNC is observe-only — never pause for HITL.
            if self._eval_mode != EvalMode.ASYNC:
                _raise_if_hitl_directive(
                    result,
                    self._session_id,
                    run_id=run_id,
                    span_ctxs=self._tool_span_ctxs,
                    cleared_sessions=self._hitl_cleared_sessions,
                    role="tool_call",
                    agent=node,          # calling agent (the node executing the tool)
                    tool=tool_name,      # the tool whose invocation triggered HITL
                )

            # NORMATIVE on a tool_call is a GATED HOLD: the request cannot be
            # processed UNTIL the remediation is effected. Withhold the tool and
            # surface the remediation (GovernedGraph absorbs the hold in BOTH
            # postures — never a terminal raise — so the caller can re-attempt once
            # the remediation is effected). Only when a remediation exists; a
            # NORMATIVE with none to effect degrades to advisory (logged). ASYNC is
            # observe-only, so it never holds.
            if (
                result.verdict == Verdict.NORMATIVE
                and self._eval_mode != EvalMode.ASYNC
            ):
                if result.response_text or result.remediations:
                    logger.info(
                        "GovernedGraph: Layer 2 NORMATIVE — holding tool '%s' pending "
                        "remediation (re-attemptable) violations=%s",
                        tool_name, result.violations,
                    )
                    _close_span_ctx(self._tool_span_ctxs.pop(run_id, None))
                    raise GovernanceHold(result)
                logger.warning(
                    "GovernedGraph: Layer 2 NORMATIVE with NO remediation — tool '%s' "
                    "PROCEEDS (advisory only; policy authored no remediation to effect)",
                    tool_name,
                )

        except (GovernanceBlock, GovernanceHold, HITLInterrupt):
            raise  # Propagate to GovernedGraph.invoke()
        except Exception as exc:
            logger.warning(
                "[RAI Trust] Policy Engine UNREACHABLE — tool call '%s' was not evaluated and "
                "is treated as PERMISSIVE (allowed to proceed). error=%s",
                tool_name, exc,
            )

    def _evaluate_and_notify(self, tool_name: str, input_str: str, run_id: UUID) -> None:
        """NONE mode: evaluate for audit trail only, never block."""
        try:
            content = f"Tool: {tool_name}\nInput: {input_str}"
            node = self._current_node            # capture ONCE (was read twice across the eval)
            result = self._client.evaluate(
                content=content,
                role=ContentRole.TOOL_CALL,
                request_id=str(run_id),
                session_id=self._session_id,
                eval_mode=self._eval_mode,
                raise_on_block=False,
                metadata={
                    "tool_name":    tool_name,
                    "agent_name":   node,
                    # C.8 parity — canonical edge keys on the observe-only (NONE-mode)
                    # tool row too, matching the blocking tool path (L2 edge =
                    # calling node -> tool). Previously omitted here, so observe-only
                    # tool_call audit rows lacked from/to_agent.
                    "from_agent":   node,
                    "to_agent":     tool_name,
                    "agent_tokens": (
                        self._token_usage.get(node or "")
                        or self._token_usage.get("_unknown")
                        or {}
                    ),
                },
            )
            if self._on_result and not getattr(result, "async_dispatched", False):
                try:
                    self._on_result(result, ContentRole.TOOL_CALL)
                except Exception:
                    pass
        except Exception as exc:
            logger.warning("GovernedGraph: Layer 2 (NONE) PE error: %s", exc)

    # ── Agent name discovery ──────────────────────────────────────────────

    @_never_crash
    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Any = None,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """
        Fires when any LangGraph node (or LangChain chain) begins execution.

        We update _current_node only for snake_case node names — this matches
        user-defined LangGraph nodes (router, intl_wire_agent, etc.) and
        excludes LangChain internals (ChatGroq, RunnableSequence, etc.).

        When a node is in _agent_nodes, its working context (state messages +
        routing metadata) is evaluated as AGENT_TO_AGENT before it executes.
        """
        # Capture the CURRENT node BEFORE any _current_node mutation below. For a
        # Command(goto) handoff INTO this node, self._current_node still holds the
        # SOURCE (the node that handed off) — the actor for the A2A edge. Without
        # this, the on_chain_start A2A site stamped only agent_name=this node, so
        # the handoff was attributed to the RECEIVER and carried no from/to.
        _prev_node = self._current_node
        # ── Identity stash for on_chain_end (Pattern B's handoff source) ──────
        # MEASURED: for a LangGraph node chain-start, serialized['name'] is None —
        # so the snake_case path below NEVER matches for plain function nodes.
        # metadata IS populated (langgraph_node / checkpoint_ns), and it is the
        # only identity source here.
        #
        # Stash it under run_id: on_chain_end receives the node's Command(goto=…)
        # but NO metadata, so this is the only way to name who handed off.
        _md = kwargs.get("metadata") or {}
        _owner = self._owner_node(_md)
        if _owner and _NODE_NAME_RE.match(_owner):
            self._chain_owner[run_id] = _owner
            self._bump(_owner, "executions")   # discovery: this node genuinely ran
            # C.10 — also set _current_node from the metadata owner so plain
            # function nodes that wrap LLM calls get token/L3 attribution.
            # Before this, _current_node stayed None for the 90% of graphs whose
            # nodes are plain callables (serialized.name None), so on_llm_end's
            # token attribution fell back to "_unknown" and L3 rows had no
            # from_agent. Cascade: llm_calls stayed 0 → _classify_node returned
            # UNKNOWN → discovered_topology's "36/39 unknown" symptom.
            self._current_node = _owner

        # LangGraph fires on_chain_start with serialized=None for some internal
        # chain events (e.g. RunnableLambda wrappers with no metadata).  Guard
        # before .get() to avoid AttributeError propagating through LangChain's
        # CallbackManager as a WARNING and leaving _current_node unset.
        if not serialized:
            return
        node_name = serialized.get("name", "")
        # Guard: create_react_agent's internal 'agent'/'tools' nodes match the regex but
        # must never clobber the checkpoint_ns owner resolved above (_owner). Doing so
        # collapsed agent_id/agent_name to the literal "agent" and cascaded the topology
        # to "unknown". A genuine top-level node of that name is still set via _owner.
        if node_name and _NODE_NAME_RE.match(node_name) and node_name not in _REACT_INTERNAL_NODES:
            self._current_node = node_name
            self._bump(node_name, "executions")      # discovery signal (observe-only)
            logger.info(
                "GovernedGraph: node start — '%s' (a2a_watch=%s)",
                node_name,
                node_name in self._agent_nodes if self._agent_nodes else False,
            )

            # ── OTel node span ────────────────────────────────────────────
            # Opens an AGENT span as a child of the active root
            # (rai.governance.turn).  GUARDRAIL child spans emitted by
            # TrustClient.evaluate() inside this node will automatically nest
            # under it in Phoenix/Arize because start_as_current_span() sets
            # this span as the active context.
            if self._tracer:
                try:
                    ctx_mgr = self._tracer.start_as_current_span(
                        f"rai.agent.{node_name}"
                    )
                    span = ctx_mgr.__enter__()
                    span.set_attribute("openinference.span.kind", "AGENT")
                    span.set_attribute("rai.agent.id",   node_name)
                    span.set_attribute("rai.app_id",     self._app_id)
                    if self._session_id:
                        span.set_attribute("session.id", self._session_id)
                    self._node_span_ctxs[run_id] = ctx_mgr
                except Exception as _exc:
                    logger.debug("GovernedGraph: node span open failed: %s", _exc)

            # ── A2A evaluation ────────────────────────────────────────────
            if self._agent_nodes and node_name in self._agent_nodes and inputs:
                content = self._extract_a2a_content(inputs, node_name)
                if content:
                    logger.info(
                        "GovernedGraph: Layer A2A — evaluating AGENT_TO_AGENT "
                        "for node '%s'", node_name
                    )
                    try:
                        result = self._client.evaluate(
                            content=content,
                            role=ContentRole.AGENT_TO_AGENT,
                            request_id=str(run_id),
                            session_id=self._session_id,
                            eval_mode=self._eval_mode,
                            raise_on_block=False,
                            metadata={
                                # C.8 edge keys — attribute to the SOURCE (the node that handed
                                # off), with this node as the target. When there is no distinct
                                # prior node (graph entry), fall back to this node so from_agent
                                # is never blank.
                                "from_agent":   (_prev_node if (_prev_node and _prev_node != node_name) else node_name),
                                "to_agent":     node_name,
                                "agent_name":   node_name,
                                "agent_tokens": self._token_usage.get(node_name, {}),
                            },
                        )
                        if self._on_result and not getattr(result, "async_dispatched", False):
                            try:
                                self._on_result(result, ContentRole.AGENT_TO_AGENT)
                            except Exception:
                                pass

                        if (result.verdict == Verdict.COERCIVE
                                and self._enforcement_mode != EnforcementMode.NONE):
                            logger.warning(
                                "GovernedGraph: A2A COERCIVE — blocking node '%s' "
                                "violations=%s", node_name, result.violations,
                            )
                            raise GovernanceBlock(result)

                        # Check for HITL directives (e.g. AGENT_ARBITRATION on chain A2A)
                        _raise_if_hitl_directive(
                            result, self._session_id,
                            cleared_sessions=self._hitl_cleared_sessions,
                            role="agent_to_agent",
                        )

                    except (GovernanceBlock, HITLInterrupt):
                        raise
                    except Exception as exc:
                        logger.warning(
                            "GovernedGraph: A2A PE error for node '%s' — "
                            "failing open: %s", node_name, exc,
                        )

    def _extract_a2a_content(self, inputs: Any, node_name: str) -> str:
        """
        Build an evaluable content string from the agent's working context
        (LangGraph state dict passed to the node on entry).
        """
        if not isinstance(inputs, dict):
            try:
                inputs = dict(inputs)
            except Exception:
                return ""

        parts = [f"Agent: {node_name}"]

        # Routing metadata (intent, transfer_type, etc.)
        for key in ("intent", "transfer_type"):
            val = inputs.get(key)
            if val:
                parts.append(f"{key}: {val}")

        # Last 5 messages for context
        messages = inputs.get("messages", [])
        for msg in messages[-5:]:
            role    = getattr(msg, "type", None) or getattr(msg, "role", None)
            content = getattr(msg, "content", "")
            if isinstance(content, str) and content.strip():
                if role == "human":
                    parts.append(f"User: {content.strip()}")
                elif role == "ai":
                    # Truncate long AI messages
                    text = content.strip()
                    parts.append(f"Prior agent: {text[:300]}{'…' if len(text) > 300 else ''}")

        return "\n".join(parts)

    @staticmethod
    def _declared_from_agent(input_str: str) -> Optional[str]:
        """
        Return an explicitly-declared handoff source (``from_agent``) from a
        tool's input, or None. Lets a graph author make the interaction graph
        reflect the real handoff direction (front-line agent → coordinator)
        instead of relying on version-dependent on_chain_start node attribution.
        Only honoured when the tool input declares it — all other A2A tools are
        unaffected.

        The tool input arrives either as JSON (double-quoted) or as a Python dict
        repr (single-quoted, e.g. ``{'from_agent': 'banking_agent'}``) depending on
        the LangChain version, so try JSON first then ``ast.literal_eval``.
        """
        if not input_str:
            return None
        parsed = None
        try:
            import json
            parsed = json.loads(input_str)
        except Exception:
            try:
                import ast
                parsed = ast.literal_eval(input_str)
            except Exception:
                return None
        if isinstance(parsed, dict):
            v = parsed.get("from_agent")
            if isinstance(v, str) and v.strip():
                return v.strip()
        return None

    def _format_a2a_tool_content(
        self, tool_name: str, input_str: str, agent_name: str
    ) -> str:
        """
        Format the A2A evaluation content from a tool's input.

        The tool input (e.g. international_transfer args) IS the inter-agent
        working context — it contains all the sensitive data (beneficiary,
        SWIFT code, country, amount) that sanctions / AML policies need to see.
        """
        parts = [f"Agent: {agent_name}", f"Invoked tool: {tool_name}"]
        # Try to parse the input_str as JSON for cleaner formatting
        try:
            import json
            parsed = json.loads(input_str)
            if isinstance(parsed, dict):
                for k, v in parsed.items():
                    parts.append(f"{k}: {v}")
            else:
                parts.append(f"Input: {input_str}")
        except Exception:
            parts.append(f"Input: {input_str}")
        return "\n".join(parts)

    # ── Token usage + cost capture ────────────────────────────────────────

    @_never_crash
    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: Any,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """
        Fires when a ChatModel (ChatGroq, ChatOpenAI, etc.) begins inference.

        We capture the model name here as a fallback, in case llm_output does
        not include it in on_llm_end (can happen with certain LangChain versions
        or when using bind_tools wrappers).

        In LangGraph 1.x, on_chain_start does not fire for individual nodes.
        LangGraph passes the node name in kwargs['metadata']['langgraph_node']
        which we use to update _current_node and emit node spans here instead.
        """
        # ── LangGraph 1.x node attribution ────────────────────────────────────
        # In LangGraph >= 1.0, individual node execution does not fire
        # on_chain_start.  The node name is available in the 'metadata' kwarg
        # as metadata['langgraph_node'].  We use this to set _current_node and,
        # when the tracer is active, open an AGENT span for the node.
        metadata = kwargs.get("metadata") or {}
        # Attribute to the OWNING node (see _owner_node): a nested create_react_agent reports
        # langgraph_node='agent' for every agent in the app, so attributing on it merges them.
        lg_node = self._owner_node(metadata) or ""
        # Only a snake_case name is a real node/agent identity; the rest are LangChain
        # internals (ChatGroq, RunnableSequence). Gate ONCE here so the span path and the
        # evidence path cannot disagree about who owns this call.
        _named = bool(lg_node) and bool(_NODE_NAME_RE.match(lg_node))

        # THE OBSERVED EDGE. An LLM call beneath a tool's execution means that tool is an
        # AGENT, and its caller genuinely handed work to it — an agent-to-agent edge we
        # WATCHED happen, not one read off an optional type annotation. This is the whole
        # distinction: declared says "may talk to"; observed says "DID talk to".
        _active = self._active_tool()
        if _active is not None:
            _callee, _caller = _active
            if _callee and _caller and _caller != _callee:
                with self._ev_lock:              # serialize with the discovery readers' snapshot
                    self._observed_edges.add((_caller, _callee))

        if _named:
            if self._current_node != lg_node:
                logger.info(
                    "GovernedGraph: node (via LLM) start — '%s'", lg_node,
                )
                # ── OTel node span lifecycle (LangGraph 1.x) ─────────────────
                # Node spans use tracer.start_span() — NOT start_as_current_span —
                # because LangGraph 1.x runs callbacks inside copy_context() and
                # start_as_current_span attaches a token that can only be detached
                # within the same context copy, causing
                #   "ValueError: Token was created in a different Context"
                # when we try to close spans from the main invocation context.
                #
                # Using start_span() + span.end() sidesteps context tokens entirely.
                # Tool spans still nest correctly because we pass node_span_ctx as
                # the explicit parent context when creating tool spans.
                #
                # Lifecycle:
                #   on_chat_model_start(nodeA) → close prev node span, open nodeA
                #   on_tool_start(tool)         → opens TOOL with nodeA as parent ✓
                #   on_tool_end(tool)           → closes tool span
                #   on_chat_model_start(nodeA)  → same node, no-op
                #   on_chat_model_start(nodeB)  → close nodeA, open nodeB
                #   _close_all_node_spans()     → called after graph.invoke() ends
                if self._tracer:
                    try:
                        from opentelemetry import trace as _ot_trace
                        from opentelemetry import context as _ot_ctx

                        # Close previous node span via span.end() (no context mgr)
                        prev = self._active_node_spans.pop(self._current_node, None) \
                            if self._current_node else None
                        if prev is not None:
                            _end_span_safe(prev[0])   # prev = (span, ctx)

                        # Create new node span as child of whatever is current
                        # in THIS copy context (root turn span, or parent node).
                        parent_ctx = _ot_ctx.get_current()
                        node_span = self._tracer.start_span(
                            f"rai.agent.{lg_node}",
                            context=parent_ctx,
                        )
                        node_span.set_attribute("openinference.span.kind", "AGENT")
                        node_span.set_attribute("rai.agent.id",   lg_node)
                        node_span.set_attribute("rai.app_id",     self._app_id)
                        if self._session_id:
                            node_span.set_attribute("session.id", self._session_id)

                        # Capture a context snapshot with this span as current
                        # so tool spans can use it as explicit parent.
                        node_span_ctx = _ot_trace.set_span_in_context(node_span)
                        self._active_node_spans[lg_node] = (node_span, node_span_ctx)
                    except Exception as _exc:
                        logger.debug("GovernedGraph: node span (LLM path) open failed: %s", _exc)
                self._current_node = lg_node
        # discovery signal: an LLM call started in this node → LLM-class node.
        # Attribute on lg_node (resolved in THIS context), not on the shared
        # _current_node — see the on_tool_start note. Stash the owner under run_id
        # so on_llm_end can credit emitted_tool_calls to the agent that actually
        # made THIS call rather than to whichever thread last touched the scalar.
        # Falls back to _current_node when lg_node is not a usable identity, which
        # is exactly what attributing via _current_node did before.
        owner = (lg_node if _named else None) or self._current_node
        if owner:
            self._llm_owner[run_id] = owner
            self._bump(owner, "llm_calls")
            # eviction enforcement: an evicted agent must not take its next step
            if owner in self._evicted_agents:
                raise AgentEvicted(owner)
        _ser = serialized or {}                      # LangChain can dispatch serialized=None
        _kw = _ser.get("kwargs") or {}               # kwargs may be present-but-None
        # Prefer the ACTUAL model id from the model's kwargs. The LangChain class name
        # (_ser["name"], e.g. "ChatBedrockConverse") is a LAST resort — ChatBedrockConverse keeps
        # the id under `model_id` (alias `model`), and its response metadata carries no `model_name`,
        # so without this it reported the class name.
        model_name = (
            _kw.get("model")
            or _kw.get("model_id")
            or _kw.get("model_name")
            or _kw.get("deployment_name")   # Azure OpenAI
            or ""
            # NOTE: _ser.get("name") — the LangChain CLASS name (e.g. "ChatMistralAI") — is
            # deliberately NOT a fallback here. It is never a real model id, and reporting it
            # mislabels cost (the generalized form of the "ChatBedrockConverse" bug). If no
            # kwarg carries the id, leave it empty: on_llm_end resolves the real model from the
            # response (llm_output / response_metadata), else it stays honestly unknown.
        )
        if model_name:
            # Stash under run_id (like _llm_owner) so on_llm_end attributes the model to THIS
            # call, not to whichever concurrent node last overwrote the shared scalar.
            self._llm_model[run_id] = model_name
            self._current_model = model_name    # kept only as a legacy fallback; run_id wins
            logger.debug("GovernedGraph: chat model start — model='%s' node='%s'", model_name, self._current_node)

    @_never_crash
    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """
        Fires after every LLM call completes (ChatGroq, ChatOpenAI, etc.).

        Accumulates token counts and model name per node.  Results are carried
        in ``metadata.agent_tokens`` on subsequent PE evaluate() calls so the
        PAP Agent Activity table can compute cost and display per-agent totals.
        Cost computation is done platform-side (PAP) using litellm.

        Requires BaseCallbackHandler inheritance — without it, LangChain's
        CallbackManager silently drops this handler for LLM-lifecycle events
        even when the handler is correctly listed in config["callbacks"].
        """
        try:
            # discovery signal: did this LLM output decide a tool call?  Emitting
            # tool_calls = agency → AGENT (vs LLM_UTILITY).  Must run BEFORE the
            # zero-token early-return below — belt-and-suspenders: token usage is now read
            # from usage_metadata too (so Gemini/Anthropic no longer report 0), but if usage
            # is ever genuinely absent the early-return must not also drop this agency signal.
            #
            # Attribute via run_id, NOT self._current_node. This is the single line
            # that decides agent-vs-llm_utility, and reading the shared scalar here
            # was the whole non-determinism: with a concurrent ToolNode batch, the
            # agent that made this call is often no longer the one _current_node
            # points at by the time its own result comes back, so its agency was
            # credited to a bystander and it demoted itself to 'llm_utility'.
            # MEASURED: totals stayed conserved (49 reviewers → exactly 49
            # emitted_tool_calls) while individuals were credited up to 6 apiece on
            # 2 llm_calls — proof of misattribution, not of lost work.
            _owner = self._llm_owner.pop(run_id, None) or self._current_node
            # Pop the run-scoped model too (stashed at on_chat_model_start) HERE — before any
            # early return below — so a zero-token call cannot leak the _llm_model map.
            _run_model = self._llm_model.pop(run_id, None)
            if _owner:
                _has_tc = False
                try:
                    for _gl in (getattr(response, "generations", None) or []):
                        for _g in _gl:
                            _m = getattr(_g, "message", None)
                            if _m is not None and getattr(_m, "tool_calls", None):
                                _has_tc = True
                                break
                        if _has_tc:
                            break
                except Exception:
                    pass
                if _has_tc:
                    self._bump(_owner, "emitted_tool_calls")

            llm_output = getattr(response, "llm_output", None) or {}

            # ── Token extraction ─────────────────────────────────────────
            # Try standard locations in priority order.
            usage = (
                llm_output.get("token_usage")      # langchain_groq primary
                or llm_output.get("usage")          # OpenAI-compat fallback
                or {}
            )

            # Fallback: check generation_info on first generation (some versions)
            if not usage:
                try:
                    gens = getattr(response, "generations", [[]])
                    if gens and gens[0]:
                        gen_info = getattr(gens[0][0], "generation_info", {}) or {}
                        usage = (
                            gen_info.get("token_usage")
                            or gen_info.get("usage")
                            or {}
                        )
                        # OpenAI-style object with attributes instead of dict keys
                        if not isinstance(usage, dict) and hasattr(usage, "prompt_tokens"):
                            usage = {
                                "prompt_tokens":     getattr(usage, "prompt_tokens",     0),
                                "completion_tokens": getattr(usage, "completion_tokens", 0),
                                "total_tokens":      getattr(usage, "total_tokens",      0),
                            }
                except Exception:
                    pass

            # Handle CompletionUsage objects (pydantic models from openai SDK)
            if not isinstance(usage, dict) and hasattr(usage, "prompt_tokens"):
                usage = {
                    "prompt_tokens":     getattr(usage, "prompt_tokens",     0),
                    "completion_tokens": getattr(usage, "completion_tokens", 0),
                    "total_tokens":      getattr(usage, "total_tokens",      0),
                }

            # Standardized per-message usage (``AIMessage.usage_metadata``) — the PROVIDER-AGNOSTIC
            # location. Gemini (ChatGoogleGenerativeAI / ChatVertexAI) and modern Anthropic
            # (ChatAnthropic) put counts HERE and leave ``llm_output`` empty — the reason the note
            # above says "Gemini/Anthropic report 0 here today". Reading it is what makes non-Groq
            # token usage actually propagate. Shape: {input_tokens, output_tokens, total_tokens}.
            if not usage:
                try:
                    for _gl in (getattr(response, "generations", None) or []):
                        for _g in _gl:
                            _m = getattr(_g, "message", None)
                            _um = getattr(_m, "usage_metadata", None) if _m is not None else None
                            if _um:
                                _get = _um.get if isinstance(_um, dict) else (lambda k, d=0: getattr(_um, k, d))
                                usage = {
                                    "prompt_tokens":     int(_get("input_tokens", 0) or 0),
                                    "completion_tokens": int(_get("output_tokens", 0) or 0),
                                    "total_tokens":      int(_get("total_tokens", 0) or 0),
                                }
                                break
                        if usage:
                            break
                except Exception:
                    pass

            # int(dict.get(k, 0)) raises on a present-but-null field (int(None)); some
            # OpenAI-compatible / cached / streaming responses emit {"completion_tokens": null}.
            # `or 0` makes a null field contribute 0 rather than dropping the whole record.
            prompt_tokens     = int(usage.get("prompt_tokens")     or 0)
            completion_tokens = int(usage.get("completion_tokens") or 0)
            total_tokens      = int(usage.get("total_tokens")      or (prompt_tokens + completion_tokens))

            # Attribute to the run-scoped owner computed above (_owner), NOT the shared
            # self._current_node — in a concurrent node batch the scalar has often advanced
            # to a sibling by the time THIS call's result returns, crediting its tokens to a
            # bystander. _owner is THIS call's agent (keyed by run_id).
            node = _owner or "_unknown"

            if total_tokens == 0:
                # #11 — usage genuinely unavailable (common when streaming without stream_usage).
                # Record an explicit marker under the owner node instead of silently reading as 0
                # cost, so a downstream cost view can show "unknown" rather than "free". Kept as a
                # SEPARATE flag (never a token count) so it can't corrupt cost math; consumers that
                # don't understand it simply ignore it. Rides the existing agent_tokens metadata
                # channel to PAP (no new field on the wire).
                logger.debug("GovernedGraph: on_llm_end — no token data (node=%s) — marking usage_unknown", node)
                if node and node != "_unknown":
                    with self._tok_lock:
                        entry = self._token_usage.setdefault(
                            node, {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0})
                        entry["usage_unknown"] = True
                        if _run_model:
                            entry.setdefault("model", _run_model)
                return

            # ── Model name (forwarded in metadata so PAP can compute cost) ─
            # Response first (authoritative), then the run_id-keyed capture from
            # on_chat_model_start (_run_model — was the racy shared _current_model).
            model_name = (
                llm_output.get("model_name")
                or llm_output.get("model")
                or llm_output.get("model_id")     # Bedrock Converse exposes the id here
                or _run_model
                or ""
            )
            if not model_name:
                try:
                    gens = getattr(response, "generations", [[]])
                    if gens and gens[0]:
                        gen0 = gens[0][0]
                        gen_info = getattr(gen0, "generation_info", {}) or {}
                        msg = getattr(gen0, "message", None)
                        rmeta = getattr(msg, "response_metadata", {}) or {}   # Converse puts model here
                        model_name = (gen_info.get("model") or rmeta.get("model_name")
                                      or rmeta.get("model_id") or rmeta.get("model") or "")
                except Exception:
                    pass

            # RMW under a lock: a ToolNode runs its batch on concurrent threads, so the
            # setdefault + three += (+ model set) are otherwise a lost-update race.
            with self._tok_lock:
                entry = self._token_usage.setdefault(
                    node,
                    {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
                )
                entry["prompt_tokens"]     += prompt_tokens
                entry["completion_tokens"] += completion_tokens
                entry["total_tokens"]      += total_tokens
                if model_name:
                    entry["model"] = model_name

            logger.info(
                "GovernedGraph: on_llm_end [%s] prompt=%d completion=%d total=%d model=%s",
                node, prompt_tokens, completion_tokens, total_tokens, model_name or "unknown",
            )
        except Exception as exc:
            logger.warning("GovernedGraph: token capture error: %s", exc)

    # ── Node span cleanup ─────────────────────────────────────────────────

    def _close_all_node_spans(self) -> None:
        """
        Close all open node spans at end of a governed turn.

        Node spans are kept open across LLM calls so that tool spans can nest
        inside them.  This method flushes whatever is left when graph.invoke()
        or graph.stream() finishes (normally or via GovernanceBlock).

        Uses _close_node_span() which falls back to span.end() if the OTel
        context manager's __exit__ fails across LangGraph copy_context() boundaries.
        """
        for _node_name, (span, _ctx) in list(self._active_node_spans.items()):
            _end_span_safe(span)
        self._active_node_spans.clear()

    # ── Span lifecycle: tool end / error ──────────────────────────────────

    def _pop_tool_frame(self) -> None:
        """Release this context's innermost tool. MUST run on both end and error.

        Load-bearing only for tools that run INLINE (same context as the caller —
        e.g. a lone tool call with no batch to parallelise): without the pop, work
        after the tool returns would still be attributed to it. A tool dispatched to
        its own context copy would be released anyway when that copy is discarded.
        """
        st = _TOOL_STACK.get()
        if st:
            _TOOL_STACK.set(st[:-1])

    @_never_crash
    def on_tool_end(
        self,
        output: Any = None,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Close the OTel tool span; and, when govern_returns is on, evaluate the tool's
        OUTPUT — the called agent's RESPONSE — as a responder->caller AGENT_TO_AGENT turn.

        This governs the ANSWER, not only the ask, and puts the responding agent's content
        on the eval-events feed (so a detection agent sees the actual disagreement, and the
        response itself is auditable). Observe-only: the response has already been produced,
        so raise_on_block=False — enforcement-on-returns is a separate, later decision.
        on_tool_end fires in the same BaseTool.invoke() as on_tool_start, so it is as
        reliable as the call-side interception.

        ALSO: the OBSERVED handoff for Pattern C. A handoff tool RETURNS
        Command(goto=X, graph=Command.PARENT) — control TRANSFERS, so unlike
        Pattern A the callee never nests under the tool and no reasoning is
        observed beneath it. MEASURED: the Command arrives here intact
        (output.goto='rev', output.graph='__parent__'), so the target is stated by
        the app itself. caller -> output.goto is then a handoff we WATCHED, and it
        needs no `destinations=` annotation to exist."""
        self._pop_tool_frame()   # release BEFORE any early return below
        # Was this tool ALREADY governed as AGENT_TO_AGENT at on_tool_start (a2a_tools)?
        # Consume the dedup marker unconditionally (independent of the flag) so it can
        # never leak across runs.
        _was_a2a_eval = run_id in self._a2a_evaluated_runs
        self._a2a_evaluated_runs.discard(run_id)
        # OBSERVED EDGE (Pattern C): the tool returned a control transfer.
        _tctx = self._tool_ctx.pop(run_id, None)
        if _tctx is not None:
            self._record_command_edges(_tctx[1], output)   # (tool_name, caller)[1]
            # Pattern-C handoff governance (observe-only, RAI_GOVERN_HANDOFFS). A tool
            # returning Command(goto=X) transferred control caller -> X: evaluate it as
            # AGENT_TO_AGENT so the conflict detector sees the edge (today it is only a
            # tool_call). SKIP when this tool was already governed as A2A at call-time
            # (a2a_tools, e.g. MyBank's council) — that transfer is already on the feed;
            # re-evaluating here would double-count. raise_on_block=False: it happened.
            if self._govern_handoffs and not _was_a2a_eval:
                self._govern_handoff(_tctx[1], output, tool_name=_tctx[0])
        ret = self._a2a_return_ctx.pop(run_id, None)
        if self._govern_returns and ret is not None and output is not None:
            responder, caller, tool_name = ret
            try:
                self._client.evaluate(
                    content=f"Response from {responder}: {output}"[:8000],
                    role=ContentRole.AGENT_TO_AGENT,
                    request_id=str(uuid.uuid4()),
                    session_id=self._session_id,
                    eval_mode=self._eval_mode,
                    raise_on_block=False,                # the response already happened
                    metadata={
                        # A return flows responder -> caller. The ACTOR is the responder
                        # (who produced the response), so from_agent = responder.
                        "from_agent":   responder,       # source = the responding agent (actor)
                        "to_agent":     caller,          # target = the calling agent
                        "agent_name":   caller,          # legacy alias (kept for wire-compat)
                        "source_agent": responder,       # A2A source alias (kept for wire-compat)
                        "tool_name":    tool_name,
                        "direction":    "return",
                    },
                )
            except Exception as _rex:
                logger.warning("GovernedGraph: return governance failed (non-fatal): %s", _rex)

        ctx_mgr = self._tool_span_ctxs.pop(run_id, None)
        if ctx_mgr and output is not None:
            try:
                # Attach output before closing so Phoenix shows it in the span
                from opentelemetry import trace as _trace
                span = _trace.get_current_span()
                if span.is_recording():
                    out_str = str(output)
                    span.set_attribute("output.value", out_str[:2000])
            except Exception:
                pass
        _close_span_ctx(ctx_mgr)

    @_never_crash
    def on_tool_error(
        self,
        error: Any = None,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Close the OTel tool span, recording the error status."""
        self._pop_tool_frame()   # a failed tool must release its frame too
        self._tool_ctx.pop(run_id, None)   # ...and its handoff context (no edge: it failed)
        self._a2a_evaluated_runs.discard(run_id)   # ...and its A2A dedup marker (no leak)
        ctx_mgr = self._tool_span_ctxs.pop(run_id, None)
        if ctx_mgr:
            try:
                from opentelemetry import trace as _trace
                from opentelemetry.trace import StatusCode
                span = _trace.get_current_span()
                if span.is_recording():
                    span.set_status(StatusCode.ERROR, str(error)[:500])
            except Exception:
                pass
        _close_span_ctx(ctx_mgr)

    # ── Span lifecycle: chain (node) end / error ──────────────────────────

    @_never_crash
    def on_chain_end(
        self,
        outputs: Any = None,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Close the OTel node span when a LangGraph node completes; and record the
        OBSERVED handoff for Pattern B.

        Pattern B's handoff IS a graph edge: a node returns Command(goto=X) and
        control transfers with no tool call anywhere. The SDK's standing assumption
        was that this made it structurally invisible, so edges were read off the
        author's OPTIONAL `destinations=` / `Command[Literal[...]]` annotation
        instead — meaning governance could not tell "these two agents talked" from
        "a developer wrote a type annotation" (delete the annotation, keep the real
        handoffs: 98 edges -> 0).

        MEASURED against langgraph 1.x: the assumption is FALSE. on_chain_end
        receives the Command itself (outputs.goto='rev'), i.e. the app states its
        own target. Paired with the source stashed at on_chain_start under this
        same run_id, the transfer is fully observable and always was.
        """
        _src = self._chain_owner.pop(run_id, None)
        self._record_command_edges(_src, outputs)
        # Pattern-B handoff governance (observe-only, RAI_GOVERN_HANDOFFS). A node
        # returning Command(goto=X) transferred control _src -> X: evaluate it as
        # AGENT_TO_AGENT so the conflict detector sees the edge (today it is invisible
        # — a node handoff carries no tool call, so nothing is emitted). No a2a_tools
        # dedup applies: a node transition is never an allowlisted tool. It already
        # happened, so raise_on_block=False.
        if self._govern_handoffs:
            self._govern_handoff(_src, outputs)
        _close_span_ctx(self._node_span_ctxs.pop(run_id, None))

    @_never_crash
    def on_chain_error(
        self,
        error: Any = None,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Close the OTel node span with error status on node failure."""
        self._chain_owner.pop(run_id, None)   # a failed node handed off to nobody
        ctx_mgr = self._node_span_ctxs.pop(run_id, None)
        if ctx_mgr:
            try:
                from opentelemetry import trace as _trace
                from opentelemetry.trace import StatusCode
                span = _trace.get_current_span()
                if span.is_recording():
                    span.set_status(StatusCode.ERROR, str(error)[:500])
            except Exception:
                pass
        _close_span_ctx(ctx_mgr)

    # ── No-ops for remaining callback hooks ───────────────────────────────
    def on_llm_start(self, *a: Any, **kw: Any) -> None: pass

    def on_llm_error(self, *a: Any, **kw: Any) -> None:
        """Release the run_id→owner entry so a failed call cannot leak it."""
        self._llm_owner.pop(kw.get("run_id"), None)

    def on_agent_action(self, *a: Any, **kw: Any) -> None: pass
    def on_agent_finish(self, *a: Any, **kw: Any) -> None: pass


# ── Directive enforcement helper ──────────────────────────────────────────────

def _raise_if_hitl_directive(
    result:            GovernanceResult,
    session_id:        Optional[str],
    run_id:            Any = None,
    span_ctxs:         Optional[Dict] = None,
    agent:             Optional[str] = None,
    tool:              Optional[str] = None,
    cleared_sessions:  Optional[Set[str]] = None,
    role:              Optional[str] = None,
) -> None:
    """
    Inspect ``result.directives`` for a REQUIRE_HUMAN_REVIEW directive and,
    if found, raise ``HITLInterrupt`` with the full directive payload.

    Called after every PE ``evaluate()`` response so that governance pauses
    requested by the Policy Engine (or routed from Sentinel via the PE) are
    honoured at every evaluation point — user prompt, A2A, tool call, and
    LLM response layers.

    Parameters
    ──────────
    result      : GovernanceResult from the PE evaluation call.
    session_id  : Active session ID — included in the interrupt payload.
    run_id      : LangChain run_id; when provided the matching entry is popped
                  from ``span_ctxs`` and closed before raising, so OTel traces
                  are not left in a dangling open state.
    span_ctxs   : Callback span dict (e.g. ``_tool_span_ctxs``) to close the
                  ``run_id`` entry from before raising.
    agent       : Name of the agent that triggered this evaluation (e.g. the
                  A2A target agent or the node currently executing).  Included
                  in the HITLInterrupt payload so server-side handlers can
                  identify which agent caused the interrupt without parsing
                  directive metadata.
    tool        : Name of the tool whose invocation triggered the evaluation.
                  Included in the payload for the same reason as ``agent``.
    """
    if not result.directives:
        return
    # If this session has already been through human review and been cleared for
    # resume, do NOT re-raise HITL on the SAME thread's next evaluation. The
    # application signals resume by adding the thread_id to _hitl_cleared_sessions
    # BEFORE re-invoking the graph. Applies to both Path A (PE-directive HITL)
    # and Path B (SDK-counter HITL — Path B was already gated separately).
    if cleared_sessions is not None and session_id and session_id in cleared_sessions:
        return
    for directive in sorted(
        result.directives,
        key=lambda d: _DIRECTIVE_PRIORITY.get(d.action, 0),
        reverse=True,
    ):
        if directive.action == DirectiveAction.REQUIRE_HUMAN_REVIEW:
            if run_id is not None and span_ctxs is not None:
                _close_span_ctx(span_ctxs.pop(run_id, None))
            # `pattern` — the SDK deterministically labels the HITL by the layer
            # that raised it:
            #   * "gate"    — user_prompt layer, BEFORE any node ran. The graph
            #                 hasn't started; nothing is suspended. On approve,
            #                 the graph is re-invoked with the original state.
            #   * "suspend" — mid-graph (tool_call / llm_response / A2A), INSIDE
            #                 a running node. When a checkpointer is active the
            #                 native interrupt() path above captures the exact
            #                 line; when it isn't, the exception path here still
            #                 semantically represents an in-node pause.
            pattern = "gate" if (role or "").lower() == "user_prompt" else "suspend"
            payload = {
                "pattern":    pattern,
                "reason":     directive.reason or "governance_review_required",
                "category":   directive.category.value if directive.category else None,
                "options":    directive.options,
                "source":     directive.source.value,
                "session_id": session_id or "",
                "directive":  directive.to_dict(),
                "agent":      agent or "",
                "tool":       tool  or "",
                "role":       role or "",
            }
            # ── Adaptive HITL — native LangGraph interrupt() when available ─────
            # Probe: (a) LangGraph >= 0.2, (b) inside a node context, (c) a
            # thread_id on the config, (d) a checkpointer active on this run.
            # If all four are true, call interrupt() so the graph pauses at
            # this exact line inside the node, checkpointed by LangGraph — no
            # re-run of preceding nodes on resume. Otherwise, fall back to the
            # exception model that the app catches around graph.invoke().
            #
            # The reviewer's decision (whatever value is passed to
            # Command(resume=<value>)) becomes the return value of interrupt()
            # and is available to the paused node.
            try:
                from .hitl import can_use_native_interrupt, _import_native_interrupt
                if can_use_native_interrupt():
                    _native = _import_native_interrupt()
                    if _native is not None:
                        _decision = _native(payload)
                        # Attach the decision on a result-like carrier so callers
                        # can inspect it. Return quietly; the paused node continues.
                        try:
                            setattr(result, "decision",
                                    _decision if isinstance(_decision, str) else str(_decision))
                        except Exception:
                            pass
                        return
            except Exception as _probe_exc:
                # Probe failure MUST NOT prevent HITL from firing — fall through
                # to the exception path below.
                logger.debug("HITL adaptive probe error (falling back to exception): %s", _probe_exc)
            raise HITLInterrupt(payload)


# ── OTel span helpers ────────────────────────────────────────────────────────

def _close_span_ctx(ctx_mgr: Any) -> None:
    """
    Safely close an OTel context manager returned by
    ``tracer.start_as_current_span()``.  Never raises — span cleanup must
    never propagate errors into application code.
    """
    if ctx_mgr is None:
        return
    try:
        ctx_mgr.__exit__(None, None, None)
    except Exception as _exc:
        logger.debug("GovernedGraph: span close error (ignored): %s", _exc)


def _end_span_safe(span: Any) -> None:
    """
    End an OTel span by calling ``span.end()`` directly.

    Used for node spans that were created with ``tracer.start_span()`` (not
    ``start_as_current_span``) to avoid OTel context-token cross-boundary
    errors in LangGraph 1.x, where callbacks run inside ``copy_context().run()``.
    """
    if span is None:
        return
    try:
        span.end()
    except Exception as _exc:
        logger.debug("GovernedGraph: span.end() error (ignored): %s", _exc)


# ── State mutation helpers ────────────────────────────────────────────────────

def _state_to_dict(state: Any) -> dict:
    """Best-effort extraction of a graph state's fields into a dict, so a Layer-1 block
    synthesises an output that PRESERVES the host's other state fields rather than dropping
    everything but ``messages`` (a plain ``{}`` for non-dict state was the bug). Handles
    dict, Pydantic v2/v1 models, and dataclasses; returns {} only for a truly opaque object."""
    if isinstance(state, dict):
        return dict(state)
    for attr in ("model_dump", "dict"):          # pydantic v2, then v1
        fn = getattr(state, attr, None)
        if callable(fn):
            try:
                d = fn()
                if isinstance(d, dict):
                    return d
            except Exception:
                pass
    try:
        import dataclasses
        if dataclasses.is_dataclass(state) and not isinstance(state, type):
            return dataclasses.asdict(state)
    except Exception:
        pass
    try:
        d = vars(state)
        if isinstance(d, dict):
            return dict(d)
    except Exception:
        pass
    logger.debug("GovernedGraph: could not extract fields from non-dict state %s "
                 "— block output carries only 'messages'", type(state).__name__)
    return {}


def _inject_ai_message(state: Any, text: str) -> dict:
    """
    Return a copy of *state* (or any dict) with a new AIMessage appended.
    Used when the graph was not invoked (Layer 1 block) so we need to
    synthesise a full output dict.
    """
    try:
        from langchain_core.messages import AIMessage
        ai_msg: Any = AIMessage(content=text)
    except ImportError:
        ai_msg = {"role": "assistant", "content": text}

    base = _state_to_dict(state)                 # preserve non-dict state fields, not just messages
    existing = list(_get_messages(state))
    return {**base, "messages": existing + [ai_msg]}


def _replace_last_human(state: Any, text: str) -> Any:
    """Return a copy of state with the last HumanMessage content replaced."""
    try:
        from langchain_core.messages import HumanMessage
    except ImportError:
        return state
    if not isinstance(state, dict):
        return state
    messages = list(state.get("messages", []))
    for i in reversed(range(len(messages))):
        if getattr(messages[i], "type", None) == "human":
            messages[i] = HumanMessage(content=text)
            break
    return {**state, "messages": messages}


def _replace_last_ai(output: Any, text: str) -> Any:
    """
    Return a copy of *output* with the last AIMessage replaced by *text*.
    Used for Layer 3 redaction — graph has already run, output exists.
    """
    try:
        from langchain_core.messages import AIMessage
    except ImportError:
        return output  # Can't manipulate messages without langchain-core

    if not isinstance(output, dict):
        return output

    messages = list(output.get("messages", []))
    for i in reversed(range(len(messages))):
        if getattr(messages[i], "type", None) == "ai":
            # Preserve the replaced message's id so downstream consumers that key on it
            # still resolve the message. tool_calls are intentionally NOT carried — a
            # redacted final answer must not still trigger tool execution.
            _old_id = getattr(messages[i], "id", None)
            messages[i] = AIMessage(content=text, id=_old_id)
            break

    return {**output, "messages": messages}


# ── Content extraction helpers ────────────────────────────────────────────────

def _extract_last_human(state: Any) -> str:
    """Pull the most recent human message text from graph state."""
    messages = _get_messages(state)
    for msg in reversed(messages):
        role = getattr(msg, "type", None) or getattr(msg, "role", None)
        if role == "human":
            return _msg_content(msg)
    return ""


def _extract_last_ai(state: Any) -> str:
    """Pull the most recent AI message text from graph state."""
    messages = _get_messages(state)
    for msg in reversed(messages):
        role = getattr(msg, "type", None) or getattr(msg, "role", None)
        if role == "ai":
            content = _msg_content(msg)
            # Skip tool-call-only AI messages (no text content)
            if content:
                return content
    return ""


def _get_messages(state: Any) -> list:
    # dict.get("messages", []) only defaults when the key is ABSENT — a present-but-None
    # (or a non-sequence) value falls through and later crashes reversed()/list() with a
    # TypeError that propagates into the host's invoke(). Guard the type here so all three
    # consumers (_extract_last_human, _inject_ai_message, _extract_last_ai) stay safe.
    msgs = state.get("messages") if isinstance(state, dict) else getattr(state, "messages", None)
    return msgs if isinstance(msgs, (list, tuple)) else []


def _msg_content(msg: Any) -> str:
    content = getattr(msg, "content", "")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = [
            b.get("text", "") for b in content
            if isinstance(b, dict) and b.get("type") == "text"
        ]
        return "\n".join(p for p in parts if p).strip()
    return str(content).strip()


def _extract_session_id(state: Any) -> Optional[str]:
    if isinstance(state, dict):
        return state.get("session_id")
    return getattr(state, "session_id", None)


def _extract_customer_id(state: Any) -> Optional[str]:
    """Extract customer/user ID from graph state for Arize ``user.id`` attribution."""
    if isinstance(state, dict):
        return state.get("customer_id")
    return getattr(state, "customer_id", None)


def _build_l3_token_meta(
    tool_cb: "_ToolGuardCallback",
    final_node: Optional[str],
) -> Dict[str, Any]:
    """
    Build the token-usage slice of Layer-3 (LLM_RESPONSE) metadata so the PE
    audit trail records tokens on llm_response rows, not just on A2A / tool
    rows. Provider-agnostic — reads the per-node dict that ``on_llm_end``
    fills for every mainstream provider (OpenAI / Azure OpenAI / Anthropic /
    Gemini / Bedrock Converse / Groq).

    Two scopes emitted, both unambiguous by name (per C.9 in the SDK Dedup
    Review — dev team was misreading the old top-level `token_usage` as the
    turn total when it was really the final node only):

      agent_tokens : {node: {prompt_tokens, completion_tokens, total_tokens,
                             model, usage_unknown?}}
                     Per-node breakdown — the authoritative detail level.

      turn_tokens  : per-turn aggregate {prompt_tokens, completion_tokens,
                     total_tokens}. Sum across every node that ran this turn.

      model        : model of the final generating node.

    Deprecated (kept for one release for wire-compat with existing consumers):
      token_usage  : alias for agent_tokens[final_node] (what it used to be).
                     Remove after downstream consumers have migrated to
                     `agent_tokens[final_node]` explicitly.

    Snapshots ``tool_cb._token_usage`` under the tool_cb's token lock so a
    concurrent ToolNode batch cannot mutate the dict mid-copy.
    """
    if not tool_cb or not getattr(tool_cb, "_token_usage", None):
        return {}
    try:
        with tool_cb._tok_lock:
            snapshot = {k: dict(v) for k, v in tool_cb._token_usage.items()}
    except Exception:
        return {}
    if not snapshot:
        return {}

    meta: Dict[str, Any] = {"agent_tokens": snapshot}
    # Per-turn roll-up across every node that produced tokens this turn.
    prompt_sum     = sum(int(v.get("prompt_tokens")     or 0) for v in snapshot.values())
    completion_sum = sum(int(v.get("completion_tokens") or 0) for v in snapshot.values())
    total_sum      = sum(int(v.get("total_tokens")      or 0) for v in snapshot.values())
    if total_sum > 0:
        _turn_tokens_val = {
            "prompt_tokens":     prompt_sum,
            "completion_tokens": completion_sum,
            "total_tokens":      total_sum,
        }
        meta["turn_tokens"] = _turn_tokens_val
        # DEPRECATED alias — the v1.42 (2026-09-01) shape emitted this as
        # `token_usage_total`. Renamed to `turn_tokens` on 2026-09-16 for clarity
        # (C.9). Kept as an alias for one release so any downstream consumer
        # built against the v1.42 baseline continues to work; remove after
        # consumers have migrated to `turn_tokens`.
        meta["token_usage_total"] = dict(_turn_tokens_val)
    # Final-generating-node attribution + deprecated alias.
    if final_node:
        final = snapshot.get(final_node)
        if final:
            # DEPRECATED alias — remove after downstream consumers migrate to
            # agent_tokens[final_node]. Kept intentionally for one release so
            # a PAP UI or exporter reading `token_usage` continues to work.
            meta["token_usage"] = {
                "prompt_tokens":     int(final.get("prompt_tokens")     or 0),
                "completion_tokens": int(final.get("completion_tokens") or 0),
                "total_tokens":      int(final.get("total_tokens")      or 0),
            }
            _mdl = final.get("model")
            if _mdl:
                meta["model"] = _mdl
            if final.get("usage_unknown"):
                meta["token_usage_unknown"] = True
    return meta


def _record_token_usage(tool_cb: "_ToolGuardCallback") -> None:
    """
    Write accumulated LLM token counts onto the currently-active OTel span.

    Called after ``graph.invoke()`` / ``graph.stream()`` completes so that the
    root ``rai.governance.turn`` span carries Arize Tier 2 cost attributes:

      llm.token_count.prompt      — total prompt tokens across all nodes
      llm.token_count.completion  — total completion tokens
      llm.token_count.total       — grand total
      llm.model_name              — model used (first observed, e.g. "llama3-70b")
    """
    if not tool_cb._token_usage:
        return
    try:
        from opentelemetry import trace as _trace
        from openinference.semconv.trace import SpanAttributes as _SA
        span = _trace.get_current_span()
        if not span.is_recording():
            return
        prompt     = sum(t.get("prompt_tokens",     0) for t in tool_cb._token_usage.values())
        completion = sum(t.get("completion_tokens", 0) for t in tool_cb._token_usage.values())
        total      = sum(t.get("total_tokens",      0) for t in tool_cb._token_usage.values())
        if total:
            span.set_attribute(_SA.LLM_TOKEN_COUNT_PROMPT,     prompt)
            span.set_attribute(_SA.LLM_TOKEN_COUNT_COMPLETION, completion)
            span.set_attribute(_SA.LLM_TOKEN_COUNT_TOTAL,      total)
        models = {t["model"] for t in tool_cb._token_usage.values() if t.get("model")}
        if models:
            span.set_attribute(_SA.LLM_MODEL_NAME, next(iter(models)))
    except ImportError:
        # openinference not installed — fall back to raw string literals (same values)
        try:
            from opentelemetry import trace as _trace2
            span = _trace2.get_current_span()
            if span.is_recording():
                prompt     = sum(t.get("prompt_tokens",     0) for t in tool_cb._token_usage.values())
                completion = sum(t.get("completion_tokens", 0) for t in tool_cb._token_usage.values())
                total      = sum(t.get("total_tokens",      0) for t in tool_cb._token_usage.values())
                if total:
                    span.set_attribute("llm.token_count.prompt",     prompt)
                    span.set_attribute("llm.token_count.completion", completion)
                    span.set_attribute("llm.token_count.total",      total)
                models = {t["model"] for t in tool_cb._token_usage.values() if t.get("model")}
                if models:
                    span.set_attribute("llm.model_name", next(iter(models)))
        except Exception:
            pass
    except Exception:
        pass  # Never let OTel errors surface to the application
