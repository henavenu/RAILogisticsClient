"""
rai-sdk-langgraph
─────────────────
Single-import distribution of the RAI Trust SDK for LangGraph applications.

Usage
─────
::

    pip install rai-sdk-langgraph

    from rai_sdk_langgraph import instrument, EnforcementMode

    app = instrument(
        app,
        base_url="http://localhost:3000",
        app_id="mybank",
        enforcement_mode=EnforcementMode.REDACT,
        otel_endpoint="http://localhost:4317",
    )

Everything needed is available from this single namespace — no sub-module
imports required.
"""

# ── Core instrumentation (this distribution now OWNS the LangGraph middleware) ──
from .middleware import instrument
from .guard import LangGraphGuard
from . import hitl                    # adaptive HITL primitives (probe + helpers)
from .hitl import (
    evaluate                as hitl_evaluate,
    resume                  as hitl_resume,
    can_use_native_interrupt,
    graph_has_checkpointer,
)

# ── Enforcement and evaluation control ───────────────────────────────────────
from rai_trust_sdk.types import (
    EnforcementMode,
    EvalMode,
    PrivacyProvider,
    ContentRole,
    Verdict,
)

# ── Result types ──────────────────────────────────────────────────────────────
from rai_trust_sdk.types import (
    GovernanceResult,
    GovernanceBlock,
    HITLInterrupt,
    AgentEvicted,
    FailedEvaluation,
    PolicyResult,
    SessionSummary,
)

# ── Client + config (for advanced / deep-embedded use) ────────────────────────
from rai_trust_sdk.client import TrustClient
from rai_trust_sdk.config import RaiConfig
from rai_trust_sdk.identity import AgentIdentity, MockIdentity

__version__ = "0.1.3"   # keep in lockstep with pyproject/wheel; sent to PAP at registration

__all__ = [
    # Instrumentation
    "instrument",
    "LangGraphGuard",
    # Enforcement
    "EnforcementMode",
    "EvalMode",
    "PrivacyProvider",
    "ContentRole",
    "Verdict",
    # Result types
    "GovernanceResult",
    "GovernanceBlock",
    "HITLInterrupt",
    "AgentEvicted",
    "FailedEvaluation",
    "PolicyResult",
    "SessionSummary",
    # Client + config
    "TrustClient",
    "RaiConfig",
    "AgentIdentity",
    "MockIdentity",
    # Adaptive HITL primitives (native interrupt when available, exception fallback)
    "hitl",
    "hitl_evaluate",
    "hitl_resume",
    "can_use_native_interrupt",
    "graph_has_checkpointer",
]
