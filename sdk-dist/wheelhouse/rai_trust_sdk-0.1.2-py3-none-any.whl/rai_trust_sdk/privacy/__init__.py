"""
rai_trust_sdk.privacy — plug & play privacy proxy layer.

Two provider implementations share the same .process(text) → ProxyResult
interface, making them drop-in replacements for each other and for the
privacy_proxy= parameter of instrument().

  PrivacyProxy         — regex + entity-name tokenization (zero ML deps)
  PresidioPrivacyProxy — Presidio NLP + regex + entity-name tokenization

Use create_proxy() to select a provider by name:

    from rai_trust_sdk.privacy import create_proxy, ProxyConfig

    # Zero-dependency regex provider (default)
    proxy = create_proxy("regex", ProxyConfig(project_names=["Atlas"]))

    # NLP provider — requires: pip install rai-trust-sdk[presidio]
    #                          python -m spacy download en_core_web_lg
    proxy = create_proxy("presidio", ProxyConfig(project_names=["Atlas"]))

    # Pass either directly to instrument():
    from rai_sdk_langgraph import instrument
    app = instrument(app, ..., privacy_proxy=proxy)
"""
from __future__ import annotations

import logging
import os
from typing import Any, Optional, Protocol, Union, runtime_checkable

from .proxy          import PrivacyProxy, ProxyConfig, ProxyResult
from .presidio_proxy import PresidioPrivacyProxy

logger = logging.getLogger("rai_trust_sdk.privacy")

__all__ = [
    "PrivacyProxy",
    "PresidioPrivacyProxy",
    "ProxyConfig",
    "ProxyResult",
    "create_proxy",
    "PrivacyProxyProvider",
    "resolve_privacy_proxy",
    "register_provider",
    "DEFAULT_PROVIDER",
]


def create_proxy(
    provider: str = "regex",
    config: Optional[ProxyConfig] = None,
) -> "PrivacyProxy | PresidioPrivacyProxy":
    """
    Factory: create a privacy proxy from a provider name.

    Parameters
    ──────────
    provider : str
        ``"regex"``    — PrivacyProxy (default)
                         Pure Python regex patterns + entity tokenization.
                         Zero extra dependencies.  Best for environments where
                         ML packages cannot be installed or latency must be
                         sub-millisecond.

        ``"presidio"`` — PresidioPrivacyProxy
                         Microsoft Presidio NLP (spaCy NER) + credential regex
                         + entity tokenization.  Catches person names, org names,
                         IBANs, free-form SSN variations, and other PII that
                         regex cannot reliably detect.
                         Requires: pip install rai-trust-sdk[presidio]
                                   python -m spacy download en_core_web_lg

    config : ProxyConfig, optional
        Proxy configuration (project names, client names, etc.).
        Defaults to ProxyConfig() (no entity lists, classifier disabled).

    Returns
    ───────
    An object with a ``.process(text: str) → ProxyResult`` interface,
    suitable for passing to ``instrument(privacy_proxy=...)``.

    Examples
    ────────
    ::

        # Regex (default) — works out of the box
        proxy = create_proxy()

        # Regex with entity lists
        proxy = create_proxy("regex", ProxyConfig(
            project_names=["Project Titan"],
            client_names=["Acme Corp"],
        ))

        # Presidio NLP — install extras first
        proxy = create_proxy("presidio", ProxyConfig(
            project_names=["Project Titan"],
        ))

    Raises
    ──────
    ValueError
        If *provider* is not one of the recognised provider names.
    """
    cfg = config or ProxyConfig()

    if provider == "regex":
        return PrivacyProxy(cfg)

    if provider == "presidio":
        return PresidioPrivacyProxy(cfg)

    raise ValueError(
        f"Unknown privacy proxy provider: {provider!r}. "
        f"Valid values are: 'regex', 'presidio'."
    )


# ══════════════════════════════════════════════════════════════════════════════
#  SPI — Service Provider Interface for privacy proxies
#
#  A privacy proxy is ANY object with ``.process(text) -> ProxyResult``. The SDK
#  ships two providers (regex, presidio) and resolves a provider from a NAME, so an
#  app selects one with a single string and ZERO privacy imports:
#
#      instrument(app, ..., privacy_proxy="presidio")   # NLP (spaCy) + regex
#      instrument(app, ..., privacy_proxy="regex")      # zero-dependency
#      instrument(app, ..., privacy_proxy=None)         # disabled
#      instrument(app, ..., privacy_proxy=my_provider)  # custom (implements .process)
#
#  Register a new provider with register_provider("name", factory) — no change to
#  instrument() or the app is needed. Env RAI_PRIVACY_PROXY sets a global default.
# ══════════════════════════════════════════════════════════════════════════════

@runtime_checkable
class PrivacyProxyProvider(Protocol):
    """The provider contract (SPI). Any object exposing this method is a valid privacy
    proxy and may be passed to ``instrument(privacy_proxy=...)``."""
    def process(self, text: str) -> ProxyResult: ...


# Provider name → factory(ProxyConfig) -> provider instance.
_PROVIDERS = {
    "regex":    lambda cfg: PrivacyProxy(cfg),
    "presidio": lambda cfg: PresidioPrivacyProxy(cfg),
}
_ALIASES  = {"default": "regex", "nlp": "presidio", "spacy": "presidio"}
_DISABLED = frozenset({"none", "off", "false", "disabled", "no", "0", ""})

# Fallback provider for an UNKNOWN name (never for None/omit — those disable).
DEFAULT_PROVIDER = "regex"
_PROVIDER_ENV = "RAI_PRIVACY_PROXY"


def register_provider(name: str, factory) -> None:
    """Register a new privacy-proxy provider under ``name``. ``factory`` takes a
    ProxyConfig and returns an object implementing the SPI (``.process(text)``).
    Lets integrators plug in their own proxy without touching the SDK core."""
    _PROVIDERS[str(name).strip().lower()] = factory


def _coerce_config(config) -> ProxyConfig:
    """Accept a ProxyConfig, a plain dict (so the app needs no import), or None."""
    if isinstance(config, ProxyConfig):
        return config
    if isinstance(config, dict):
        try:
            return ProxyConfig(**config)
        except Exception as exc:  # noqa: BLE001
            logger.warning("privacy: invalid privacy_config dict (%s) — using defaults", exc)
    return ProxyConfig()


def resolve_privacy_proxy(
    spec: "Union[str, PrivacyProxyProvider, None]" = None,
    config: "Optional[Union[ProxyConfig, dict]]" = None,
) -> "Optional[PrivacyProxyProvider]":
    """Resolve a privacy_proxy SPEC into a provider instance, or None (disabled).

    ``spec`` may be:
      • an object with ``.process(text)``      → used as-is (a custom provider)
      • ``None`` / ``"none"`` / ``"off"`` / …  → disabled (returns None)
      • ``"regex"`` / ``"presidio"`` (+aliases) → the named bundled provider

    NEVER raises: an unknown name, or a provider that fails to construct (e.g. presidio
    extras not installed), degrades to the regex provider (or None) with a warning — so
    instrument() can never crash on a privacy-config mistake."""
    # Already a provider instance? (duck-typed on the SPI.)
    if spec is not None and not isinstance(spec, str) and hasattr(spec, "process"):
        return spec
    if spec is None:
        return None                                       # explicit disable

    # A str-Enum member (PrivacyProvider.PRESIDIO) IS a str, but str(member) yields
    # "PrivacyProvider.PRESIDIO" — so read the char data directly via the str methods.
    raw = (spec if isinstance(spec, str) else str(spec)).strip().lower()
    key = _ALIASES.get(raw, raw)
    if key in _DISABLED:
        logger.info("privacy: proxy DISABLED (spec=%r)", spec)
        return None

    factory = _PROVIDERS.get(key)
    if factory is None:
        logger.warning("privacy: unknown provider %r — valid: %s (or none/off). Falling back to %r.",
                       spec, sorted(_PROVIDERS), DEFAULT_PROVIDER)
        factory, key = _PROVIDERS[DEFAULT_PROVIDER], DEFAULT_PROVIDER

    cfg = _coerce_config(config)
    try:
        proxy = factory(cfg)
        logger.info("privacy: proxy provider=%r active", key)
        return proxy
    except Exception as exc:  # noqa: BLE001 — e.g. presidio extras missing at a strict layer
        logger.warning("privacy: provider %r failed to initialise (%s) — falling back to regex.", key, exc)
        try:
            return _PROVIDERS["regex"](cfg)
        except Exception:  # noqa: BLE001
            return None
