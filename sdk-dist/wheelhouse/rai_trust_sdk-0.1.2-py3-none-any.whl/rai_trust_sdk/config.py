"""
rai_trust_sdk.config — the single source of truth for SDK **deployment** configuration.

Config comes from ONE file (in your choice of format) and/or the environment — never a merge
of two config files. Resolution precedence (highest wins):

    kwargs  >  OS env (RAI_* / OTEL_*)  >  config file (rai.env OR rai.toml)  >  defaults

The config FILE is either of two interchangeable formats — pick ONE:
  • rai.env   — a dotenv file of UPPERCASE `RAI_*=value` lines (same names as OS env vars).
  • rai.toml  — a TOML file with lowercase field names under [rai] (or [tool.rai] in pyproject).
The SDK reads exactly one file: if BOTH rai.env and rai.toml exist it uses rai.env and logs a
warning (keep only one). Real OS env vars override whichever file is used.

The file is discovered by walking up from the current working directory (or via the RAI_ENV_FILE
/ RAI_CONFIG escape hatches), so a standalone app just drops a rai.env or rai.toml in its project;
a container injects `RAI_*` env vars instead. The SDK reads its OWN config here, at instrument()
time — no launcher, no change to how the app starts, and no dependency on the application's `.env`.

IDENTITY IS NOT HERE. `app_id` and `app_key` are app-owned and passed to instrument()
directly — the app holds its own credential and presents it explicitly. This object carries
only deployment / governance config (URLs, modes, privacy, observability, governance toggles).

Sources:
  • rai.env   — UPPERCASE `RAI_*` / `OTEL_*` `KEY=value` lines (dotenv); same names as OS env.
  • rai.toml  — FIELD names (lowercase) under [rai] (or [tool.rai] in pyproject.toml), typed.
  • OS env    — RAI_* / OTEL_* variables in the environment (the container channel; UPPERCASE).
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from .types import EvalMode, EnforcementMode, validate_modes

logger = logging.getLogger(__name__)

# Sentinel: distinguishes "kwarg not supplied" (fall through to env/file/default) from an
# explicit None (which for most fields means "off"). instrument() passes _UNSET when a caller
# omitted a config-backed kwarg.
_UNSET: Any = object()

# TOML parser — stdlib on 3.11+, optional `tomli` backport otherwise, else TOML is skipped.
try:  # pragma: no cover - import shape only
    import tomllib as _toml  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    try:
        import tomli as _toml  # type: ignore
    except ModuleNotFoundError:
        _toml = None  # type: ignore

# field name -> environment-variable name (used for the OS env override channel)
_ENV_NAME: Dict[str, str] = {
    "pe_url":           "RAI_PE_URL",
    "pap_url":          "RAI_PAP_URL",
    "eval_mode":        "RAI_EVAL_MODE",
    "enforcement_mode": "RAI_ENFORCEMENT_MODE",
    "timeout":          "RAI_TIMEOUT",
    "privacy_proxy":    "RAI_PRIVACY_PROXY",
    "otel_endpoint":    "OTEL_EXPORTER_OTLP_ENDPOINT",
    "otel_protocol":    "OTEL_EXPORTER_OTLP_PROTOCOL",
    "govern_returns":   "RAI_GOVERN_RETURNS",
    "govern_handoffs":  "RAI_GOVERN_HANDOFFS",
}
_FIELDS: Tuple[str, ...] = tuple(_ENV_NAME.keys())
_REQUIRED: Tuple[str, ...] = ("pe_url", "pap_url")

_TRUE = {"1", "true", "yes", "on"}


# ── per-field coercion (values may arrive typed from TOML or as strings from env/dotenv) ──
def _as_bool(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in _TRUE


def _as_float(v: Any) -> float:
    return float(v)


def _as_eval(v: Any) -> EvalMode:
    if isinstance(v, EvalMode):
        return v
    return EvalMode(str(v).strip().upper())


def _as_enf(v: Any) -> Optional[EnforcementMode]:
    if v is None:
        return None
    if isinstance(v, EnforcementMode):
        return v
    return EnforcementMode(str(v).strip().upper())


_COERCE = {
    "timeout":          _as_float,
    "eval_mode":        _as_eval,
    "enforcement_mode": _as_enf,
    "govern_returns":   _as_bool,
    "govern_handoffs":  _as_bool,
    # pe_url / pap_url / privacy_proxy / otel_endpoint / otel_protocol -> kept as str
}

_DEFAULTS: Dict[str, Any] = {
    "eval_mode":        EvalMode.ASYNC,        # observe-only out of the box (never blocks)
    "enforcement_mode": None,                  # None -> derived from eval_mode below
    "timeout":          5.0,
    "privacy_proxy":    "none",
    "otel_endpoint":    None,
    "otel_protocol":    "grpc",
    "govern_returns":   False,
    "govern_handoffs":  None,
    # pe_url / pap_url have NO default -> required.
}


# ── file discovery ───────────────────────────────────────────────────────────
def _find_up(start: Path, name: str) -> Optional[Path]:
    """Walk up from `start` (and its parents) looking for a file named `name`."""
    try:
        base = start.resolve()
    except Exception:  # noqa: BLE001 - resolve() can fail on odd cwd; degrade gracefully
        base = start
    for cur in (base, *base.parents):
        p = cur / name
        if p.is_file():
            return p
    return None


def _read_toml_source(environ, cwd: Path):
    """Return (field->raw dict, path or None) from rai.toml / [tool.rai] in pyproject.toml.
    RAI_CONFIG pointing at a .toml file wins over auto-discovery."""
    # Locate the candidate TOML FIRST, so we can distinguish "no rai.toml present" (fine,
    # silently skip) from "rai.toml present but no TOML parser installed" (a silent
    # config-loss trap on Python 3.10 without the tomli backport — fail LOUDLY instead).
    path: Optional[Path] = None
    cfg = environ.get("RAI_CONFIG")
    if cfg and cfg.endswith(".toml"):
        path = Path(cfg)
    else:
        path = _find_up(cwd, "rai.toml")

    if _toml is None:
        if path is not None and path.is_file():
            raise RuntimeError(
                f"RAI config: found '{path}' but no TOML parser is available to read it. "
                f"Python 3.11+ has tomllib built in; on 3.10 install the backport "
                f"(pip install tomli). Refusing to silently ignore a present config file."
            )
        return {}, None

    def _table_from(p: Path):
        try:
            data = _toml.loads(p.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            logger.warning("rai_trust_sdk.config: could not parse %s (%s) — ignoring.", p, exc)
            return None
        return data.get("rai") or data.get("tool", {}).get("rai")

    if path and path.is_file():
        table = _table_from(path)
        if table:
            return {k: v for k, v in table.items() if k in _FIELDS}, str(path)
    # pyproject.toml [tool.rai] fallback
    pp = _find_up(cwd, "pyproject.toml")
    if pp:
        table = _table_from(pp)
        if table:
            return {k: v for k, v in table.items() if k in _FIELDS}, str(pp)
    return {}, None


def _read_dotenv_source(environ, cwd: Path):
    """Return (field->raw dict, path or None) from a rai.env dotenv file.
    rai.env holds UPPERCASE `RAI_*=value` lines — the SAME names as OS env vars. A
    RAI_ENV_FILE path wins over auto-discovery (walk up from cwd for a file named rai.env)."""
    ef = environ.get("RAI_ENV_FILE")
    path = Path(ef) if ef else _find_up(cwd, "rai.env")
    if not (path and path.is_file()):
        return {}, None
    env_to_field = {envn: f for f, envn in _ENV_NAME.items()}
    vals: Dict[str, str] = {}
    try:
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line[:7].lower() == "export ":          # tolerate `export RAI_PE_URL=...`
                line = line[7:].lstrip()
            key, sep, val = line.partition("=")
            if not sep:
                continue
            field = env_to_field.get(key.strip())
            if field is None:
                continue
            v = val.strip()
            if v[:1] in ("\"", "'"):                 # quoted: value ends at the closing quote
                q = v[0]
                end = v.find(q, 1)
                v = v[1:end] if end != -1 else v[1:]
            else:                                    # unquoted: drop an inline "# comment"
                for i, ch in enumerate(v):
                    if ch == "#" and (i == 0 or v[i - 1] in " \t"):
                        v = v[:i]
                        break
                v = v.strip()
            if v == "":                              # empty value -> unset (fall to default)
                continue
            vals[field] = v
    except Exception as exc:  # noqa: BLE001
        logger.warning("rai_trust_sdk.config: could not parse %s (%s) — ignoring.", path, exc)
        return {}, None
    return vals, str(path)


def _read_os_env(environ) -> Dict[str, str]:
    return {
        f: environ[envn]
        for f, envn in _ENV_NAME.items()
        if environ.get(envn) not in (None, "")
    }


# ── the config object ────────────────────────────────────────────────────────
@dataclass(frozen=True)
class RaiConfig:
    """Resolved, validated, immutable SDK deployment config. Build via ``RaiConfig.load()``."""
    pe_url: str
    pap_url: str
    eval_mode: EvalMode = EvalMode.ASYNC
    enforcement_mode: EnforcementMode = EnforcementMode.NONE
    timeout: float = 5.0
    privacy_proxy: str = "none"
    otel_endpoint: Optional[str] = None
    otel_protocol: str = "grpc"
    govern_returns: bool = False
    govern_handoffs: Optional[bool] = None
    # provenance (not part of equality/repr): field -> source label; loaded file paths; self-test notes
    sources: Dict[str, str] = field(default_factory=dict, compare=False, repr=False)
    file_paths: Tuple[str, ...] = field(default=(), compare=False, repr=False)
    mode_notes: Tuple[str, ...] = ()

    @classmethod
    def load(cls, *, _environ=None, _cwd=None, **overrides) -> "RaiConfig":
        """Resolve config across all layers. `overrides` are field-named kwargs from
        instrument(); pass _UNSET (or omit) to defer a field to env/file/default.

        `_environ`/`_cwd` are test seams (default: os.environ / Path.cwd())."""
        environ = os.environ if _environ is None else _environ
        cwd = Path(_cwd) if _cwd is not None else Path.cwd()

        toml_vals, toml_path = _read_toml_source(environ, cwd)
        dotenv_vals, dotenv_path = _read_dotenv_source(environ, cwd)
        osenv_vals = _read_os_env(environ)
        kw_vals = {
            f: v for f, v in overrides.items()
            if f in _FIELDS and v is not _UNSET and v is not None
        }

        # EITHER/OR: the SDK uses exactly ONE config file — never a merge of two. rai.env
        # (dotenv) and rai.toml are interchangeable formats; if BOTH exist, rai.env wins and
        # rai.toml is ignored (with a warning). OS env vars still override whichever file is used.
        if dotenv_path and toml_path:
            logger.warning(
                "rai_trust_sdk.config: found BOTH rai.env (%s) and rai.toml (%s). Config is "
                "either/or - using rai.env and IGNORING rai.toml. Keep only one file.",
                dotenv_path, toml_path,
            )
        if dotenv_path:
            file_label, file_vals, file_path = "rai.env", dotenv_vals, dotenv_path
        else:
            file_label, file_vals, file_path = "rai.toml", toml_vals, toml_path

        # low -> high precedence; later layers overwrite and re-stamp the source
        values: Dict[str, Any] = {}
        sources: Dict[str, str] = {}
        for label, layer in ((file_label, file_vals),
                              ("env", osenv_vals), ("kwarg", kw_vals)):
            for f, v in layer.items():
                values[f] = v
                sources[f] = ("env:" + _ENV_NAME[f]) if label == "env" else label

        # coerce provided values to their field types
        for f in list(values):
            fn = _COERCE.get(f)
            if fn is not None:
                try:
                    values[f] = fn(values[f])
                except Exception as exc:  # noqa: BLE001
                    raise ValueError(
                        "RaiConfig: invalid value for %s=%r (%s)" % (f, values[f], exc)
                    ) from exc

        # required fields
        missing = [f for f in _REQUIRED if not values.get(f)]
        if missing:
            raise ValueError(
                "RaiConfig: missing required config: %s. Provide it in a config file "
                "(rai.env as %s, or rai.toml [rai] table) or as an OS environment variable."
                % (", ".join(missing), " / ".join(_ENV_NAME[m] for m in missing))
            )

        # defaults for anything still unset
        for f, dv in _DEFAULTS.items():
            if f not in values:
                values[f] = dv
                sources.setdefault(f, "default")

        # derive enforcement when not explicitly provided (SYNC -> RAISE, ASYNC -> NONE)
        eval_mode = values["eval_mode"]
        enf = values["enforcement_mode"]
        if enf is None:
            enf = EnforcementMode.RAISE if eval_mode == EvalMode.SYNC else EnforcementMode.NONE
            sources["enforcement_mode"] = "derived"

        # coherence self-test (coerces incoherent explicit combos + records notes)
        eval_mode, enf, notes = validate_modes(eval_mode, enf)

        return cls(
            pe_url=values["pe_url"],
            pap_url=values["pap_url"],
            eval_mode=eval_mode,
            enforcement_mode=enf,
            timeout=values["timeout"],
            privacy_proxy=values["privacy_proxy"],
            otel_endpoint=values["otel_endpoint"],
            otel_protocol=values["otel_protocol"],
            govern_returns=values["govern_returns"],
            govern_handoffs=values["govern_handoffs"],
            sources=sources,
            file_paths=tuple(p for p in (file_path,) if p),
            mode_notes=tuple(notes),
        )

    def banner_lines(self) -> Tuple[str, ...]:
        """Human-readable per-field resolution for the boot banner (value + where it came from)."""
        order = ("pe_url", "pap_url", "eval_mode", "enforcement_mode", "timeout",
                 "privacy_proxy", "otel_endpoint", "govern_returns")
        out = []
        for f in order:
            val = getattr(self, f)
            val = getattr(val, "value", val)
            out.append("    %-16s = %-28s [%s]" % (f, val, self.sources.get(f, "default")))
        return tuple(out)
