"""
Shared agent-registry registration — the ONE implementation every SDK adapter
(LangGraph, neuro-san, …) uses to publish its discovered agent topology to the
Policy Administration Point (PAP) so the app populates the Agent Registry
(``config_app_agents``) identically, regardless of framework.

Why this lives in the core
──────────────────────────
Each adapter DISCOVERS its topology in a framework-specific way (LangGraph walks a
compiled graph; neuro-san reads ``connectivity()``), then MAPS it onto one common
contract: ``{app_id, discovered_nodes, agent_nodes, a2a_tools, framework,
sdk_version, node_kinds}``. That mapping is framework-specific and stays in the
adapter. The TRANSPORT — the POST to ``/internal/register-agents``, the payload
envelope, the fail-open error handling, the optional ``X-RAI-App-Key`` credential,
and the daemon-thread fire-and-forget — is identical for every adapter and lives
here, so it can never drift between distributions again.

Stdlib-only (json / logging / threading / urllib): importing this pulls NO
langgraph / langchain / httpx, so the neuro-san distro can depend on it freely.

``app_id`` is authoritative: it is the id the app REGISTERS under, EVALS under,
and MUST be ONBOARDED under in PAP — pass the same value everywhere so the
registry, the audit trail and onboarding all reconcile on one identifier.
"""
from __future__ import annotations

import json as _json
import logging as _logging
import threading as _threading
import time as _time
import urllib.request as _urlreq
from typing import Dict, List, Optional

_DEFAULT_LOG = _logging.getLogger("rai_trust_sdk.registry")

REGISTER_PATH = "/internal/register-agents"


def build_registration_payload(
    *,
    app_id: str,
    discovered_nodes: List[str],
    agent_nodes: List[str],
    a2a_tools: Dict[str, str],
    framework: str,
    sdk_version: Optional[str] = None,
    node_kinds: Optional[Dict[str, Optional[str]]] = None,
) -> dict:
    """Assemble the register-agents request body from the common discovery contract.
    Kept separate so adapters/tests can inspect the exact payload without posting."""
    return {
        "app_id":           app_id,
        "discovered_nodes": sorted(set(discovered_nodes or [])),
        "agent_nodes":      sorted(set(agent_nodes or [])),
        "a2a_tools":        dict(a2a_tools or {}),
        "framework":        framework,
        "sdk_version":      sdk_version or "0.1.0",
        "node_kinds":       dict(node_kinds or {}),
    }


def register_agents(
    *,
    pap_url: str,
    app_id: str,
    discovered_nodes: List[str],
    agent_nodes: List[str],
    a2a_tools: Dict[str, str],
    framework: str,
    app_key: Optional[str] = None,
    sdk_version: Optional[str] = None,
    node_kinds: Optional[Dict[str, Optional[str]]] = None,
    logger: Optional[_logging.Logger] = None,
    timeout: float = 3.0,
    retries: int = 2,
    backoff: float = 0.5,
) -> bool:
    """Synchronously POST the discovered topology to ``{pap_url}{REGISTER_PATH}``.

    Fail-open: never raises. Returns True on a 2xx response, False otherwise (PAP
    down, network error, non-2xx) — registration failing must never degrade
    governance. Adapters typically call this inside a daemon thread (see
    :func:`register_agents_async`) so it never blocks instrumentation.
    """
    log = logger or _DEFAULT_LOG
    if not app_id:
        log.debug("register_agents: no app_id — skipping")
        return False
    if not (agent_nodes or discovered_nodes):
        log.debug("register_agents [%s]: nothing discovered — skipping", app_id)
        return False

    payload = build_registration_payload(
        app_id=app_id, discovered_nodes=discovered_nodes, agent_nodes=agent_nodes,
        a2a_tools=a2a_tools, framework=framework, sdk_version=sdk_version,
        node_kinds=node_kinds,
    )
    url = f"{str(pap_url).rstrip('/')}{REGISTER_PATH}"
    data = _json.dumps(payload).encode("utf-8")
    hdrs = {"Content-Type": "application/json"}
    if app_key:
        hdrs["X-RAI-App-Key"] = app_key

    # Retry connection-level failures (the common one: the app boots a beat before the PAP is
    # ready). A non-2xx RESPONSE reached the server, so retrying it is pointless — stop there.
    attempts = max(0, retries) + 1
    last = "unknown error"
    for attempt in range(attempts):
        try:
            req = _urlreq.Request(url, data=data, headers=hdrs, method="POST")
            with _urlreq.urlopen(req, timeout=timeout) as resp:
                status = int(getattr(resp, "status", 0))
                if 200 <= status < 300:
                    log.info("[%s/%s] registered %d nodes with PAP (HTTP %s)",
                             framework, app_id, len(payload["discovered_nodes"]), status)
                    return True
                last = "HTTP %s" % status
                break
        except Exception as exc:  # noqa: BLE001 — PAP may be down / still booting
            last = str(exc)
            if attempt < attempts - 1:
                _time.sleep(backoff * (2 ** attempt))
                continue
    # WARNING, not debug: a failed registration is why "agent topology is empty" while evaluate()
    # still works (evaluate → PE, register → PAP: two different services). Make the reason visible.
    log.warning("[%s/%s] agent registration to %s FAILED after %d attempt(s) — topology will NOT "
                "transfer. Is the PAP running / is pap_url|RAI_PAP_URL correct? (%s)",
                framework, app_id, url, attempts, last)
    return False


def register_agents_async(*, logger: Optional[_logging.Logger] = None, **kwargs) -> None:
    """Fire-and-forget wrapper: run :func:`register_agents` in a daemon thread.

    Use this when the caller has ALREADY built the fields on the main thread (e.g.
    the LangGraph adapter, whose discovery is fast static introspection). Adapters
    whose discovery may block (e.g. neuro-san ``connectivity()``) should instead run
    their discovery AND ``register_agents`` together inside their own daemon thread,
    so discovery is off the construction path too.
    """
    _threading.Thread(
        target=lambda: register_agents(logger=logger, **kwargs), daemon=True
    ).start()
