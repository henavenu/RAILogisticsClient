"""
TrustClient — synchronous HTTP client for the RAI Trust Platform Policy Engine.

Calls POST /v1/app/evaluate and returns a GovernanceResult.
Raises GovernanceBlock when the verdict is COERCIVE in SYNC mode.

Design notes
────────────
• Uses httpx.Client (sync) because LangChain / LangGraph enforcement must be
  synchronous — an async verdict cannot interrupt a sync execution graph.
• Transport errors are surfaced as httpx.HTTPError; callers decide whether to
  swallow or propagate.
• The client is safe to share across callback handler instances within a
  single thread.  For multi-threaded use, create one client per thread or
  wrap with a threading.Lock.

Arize / OpenInference compatibility
────────────────────────────────────
Every call to evaluate() automatically creates a GUARDRAIL span using the
global OpenTelemetry TracerProvider (set by arize.otel.register() or
phoenix.otel.register() at application startup).  When no provider is
configured the OTel API returns a no-op tracer — zero overhead, no spans.

Span attributes follow the OpenInference semantic conventions so spans appear
correctly in the Arize trace tree alongside LangChain / LangGraph spans and
are consumable by Arize evaluators (hallucination, toxicity, custom evals):

  openinference.span.kind  = "GUARDRAIL"
  input.value              = content being evaluated (raw text or JSON string)
  input.mime_type          = "text/plain" | "application/json"  (role-derived)
  output.value             = JSON: {verdict, violations, failed_evaluations}
  output.mime_type         = "application/json"
  session.id               = session_id (when present)
  metadata                 = JSON: full context (app_id, role, request_id,
                             policies, pack_trace, session_summary)

OTel status:
  COERCIVE  → StatusCode.ERROR  (appears as a failed span in Arize)
  NORMATIVE → StatusCode.OK     (surfaced through output.value only)
  PERMISSIVE→ StatusCode.OK
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from typing import Any, Callable, Dict, Generator, Optional

import httpx

from .contract import capture_eval, enforce_contract
from .identity import AgentIdentity
from .types import (
    ContentRole,
    EnforcementMode,
    EvalMode,
    GovernanceBlock,
    GovernanceResult,
    PolicyUnavailable,
    Verdict,
)

logger = logging.getLogger(__name__)

# Audit-metadata contract version — stamped into every evaluate() payload so each
# stored audit row is SELF-DESCRIBING across the metadata_json DB column: a consumer
# reads `_schema` and validates against the matching contract, and old/new rows can
# coexist in the same table. See docs/schemas/audit-metadata.schema.json.
AUDIT_SCHEMA_VERSION = "rai.audit/v1"

# Policy-unavailability contract — mirrors the PE (policy-engine/api/routes.py).
# The PE returns this distinct 5xx (NOT a verdict, NOT a generic 500) when it is up
# but has no policies loaded; the body carries error_code so the signal survives a
# proxy that rewrites the numeric status. The client retries a bounded number of times
# (honouring Retry-After) before raising PolicyUnavailable, because the PE self-heals
# within seconds once the seed Job populates config_policies.
POLICY_UNAVAILABLE_STATUS = 563
POLICY_UNAVAILABLE_CODE   = "policy_store_unavailable"
# Tunable via env so an operator can widen the bridge window without a code change.
_PU_RETRIES   = max(0, int(os.getenv("RAI_POLICY_UNAVAILABLE_RETRIES", "3")))
_PU_BACKOFF   = max(0.0, float(os.getenv("RAI_POLICY_UNAVAILABLE_BACKOFF_SECONDS", "1.0")))
_PU_BACKOFF_CAP = max(_PU_BACKOFF, float(os.getenv("RAI_POLICY_UNAVAILABLE_BACKOFF_CAP_SECONDS", "5.0")))


def _is_policy_unavailable(response: "httpx.Response") -> bool:
    """True iff this response is the PE's policy-store-unavailable signal. Keys off the
    563 status, and (to survive a proxy that rewrote the status) the typed error_code
    on any 5xx body."""
    if response.status_code == POLICY_UNAVAILABLE_STATUS:
        return True
    if 500 <= response.status_code < 600:
        try:
            return (response.json() or {}).get("error_code") == POLICY_UNAVAILABLE_CODE
        except Exception:
            return False
    return False


def _retry_after_seconds(response: "httpx.Response") -> Optional[float]:
    """Parse a numeric Retry-After header (seconds). Returns None if absent/unparseable."""
    raw = response.headers.get("Retry-After", "").strip()
    if not raw:
        return None
    try:
        return max(0.0, float(raw))
    except (TypeError, ValueError):
        return None


def _echo_eval_request(payload: Dict[str, Any]) -> None:
    """Pretty-print the Policy Evaluation Request to stdout so an integrator can SEE
    exactly what the SDK sends the Policy Engine — above all, the agent identity that
    the platform uses to attribute the eval. Enabled by default; set
    ``RAI_ECHO_EVAL_REQUEST=0`` (or false/no/off) to silence. ASCII-only so it renders
    in any console. NEVER raises — telemetry printing must not break governance."""
    try:
        if os.environ.get("RAI_ECHO_EVAL_REQUEST", "1").strip().lower() in ("0", "false", "no", "off"):
            return
        meta = payload.get("metadata") or {}
        agent = meta.get("agent_name")
        content = payload.get("content") or ""
        if not isinstance(content, str):
            content = str(content)
        one_line = " ".join(content.split())
        clen = len(one_line)
        if clen > 180:
            one_line = one_line[:180] + "..."
        bar = "=" * 70
        lines = [
            bar,
            " RAI Trust . Policy Evaluation Request  ->  POST /v1/app/evaluate",
            bar,
            "  app_id       : %s" % payload.get("app_id", "-"),
            "  request_id   : %s" % payload.get("request_id", "-"),
            "  interception : %s   (role)" % payload.get("role", "-"),
            "  eval_mode    : %s" % payload.get("eval_mode", "-"),
        ]
        if payload.get("enforcement_mode"):
            lines.append("  enforcement  : %s" % payload["enforcement_mode"])
        if payload.get("session_id"):
            lines.append("  session_id   : %s" % payload["session_id"])
        # THE agent identity the platform attributes the eval to — top-level agent_id (canonical).
        aid = payload.get("agent_id")
        if aid:
            lines.append("  agent_id     : %s   (top-level, canonical)" % aid)
        else:
            lines.append("  agent_id     : <MISSING>  (platform cannot attribute this eval to an agent)")
        if agent and agent != aid:
            lines.append("  agent_name   : %s   (governance label, in metadata)" % agent)
        if meta.get("tool_name"):
            lines.append("  tool_name    : %s" % meta["tool_name"])
        if meta.get("source_agent") or meta.get("target_agent"):
            lines.append("  a2a          : %s -> %s"
                         % (meta.get("source_agent", "?"), meta.get("target_agent", "?")))
        lines.append("  content      : \"%s\"  (%d chars)" % (one_line, clen))
        lines.append(bar)
        print("\n".join(lines), flush=True)
    except Exception:
        pass

# ── OpenTelemetry / OpenInference imports (graceful no-op if absent) ──────────
# opentelemetry-api and openinference-semantic-conventions are listed in base
# dependencies so these imports should always succeed.  The try/except is a
# defensive guard against environments where only rai-trust-sdk is installed
# from source without its dependencies.

try:
    from opentelemetry import trace as _otel_trace
    from opentelemetry.trace import StatusCode as _OtelStatusCode
    _OTEL_AVAILABLE = True
except ImportError:  # pragma: no cover
    _OTEL_AVAILABLE = False

try:
    from openinference.semconv.trace import (
        SpanAttributes              as _OIAttrs,
        OpenInferenceSpanKindValues as _OIKind,
    )
    # Resolved attribute name constants (use spec constants, never raw strings)
    _ATTR_SPAN_KIND   = _OIAttrs.OPENINFERENCE_SPAN_KIND   # "openinference.span.kind"
    _ATTR_INPUT_VAL   = _OIAttrs.INPUT_VALUE                # "input.value"
    _ATTR_INPUT_MIME  = _OIAttrs.INPUT_MIME_TYPE            # "input.mime_type"
    _ATTR_OUTPUT_VAL  = _OIAttrs.OUTPUT_VALUE               # "output.value"
    _ATTR_OUTPUT_MIME = _OIAttrs.OUTPUT_MIME_TYPE           # "output.mime_type"
    _ATTR_SESSION_ID  = _OIAttrs.SESSION_ID                 # "session.id"
    _ATTR_METADATA    = _OIAttrs.METADATA                   # "metadata"
    _ATTR_USER_ID     = _OIAttrs.USER_ID                    # "user.id"
    _ATTR_AGENT_NAME  = _OIAttrs.AGENT_NAME                 # "agent.name"
    _ATTR_TOOL_NAME   = _OIAttrs.TOOL_NAME                  # "tool.name"
    _ATTR_TAG_TAGS    = _OIAttrs.TAG_TAGS                   # "tag.tags"
    _KIND_GUARDRAIL   = _OIKind.GUARDRAIL.value             # "GUARDRAIL"
    _OI_AVAILABLE     = True
except ImportError:  # pragma: no cover
    # Fall back to raw string literals — values are stable across spec versions.
    _ATTR_SPAN_KIND   = "openinference.span.kind"
    _ATTR_INPUT_VAL   = "input.value"
    _ATTR_INPUT_MIME  = "input.mime_type"
    _ATTR_OUTPUT_VAL  = "output.value"
    _ATTR_OUTPUT_MIME = "output.mime_type"
    _ATTR_SESSION_ID  = "session.id"
    _ATTR_METADATA    = "metadata"
    _ATTR_USER_ID     = "user.id"
    _ATTR_AGENT_NAME  = "agent.name"
    _ATTR_TOOL_NAME   = "tool.name"
    _ATTR_TAG_TAGS    = "tag.tags"
    _KIND_GUARDRAIL   = "GUARDRAIL"
    _OI_AVAILABLE     = False

# MIME type to use for each content role:
#   user/llm text → plain text;  structured agent/tool payloads → JSON
_ROLE_MIME: Dict[str, str] = {
    ContentRole.USER_PROMPT.value:    "text/plain",
    ContentRole.LLM_RESPONSE.value:   "text/plain",
    ContentRole.TOOL_CALL.value:      "application/json",
    ContentRole.AGENT_TO_AGENT.value: "application/json",
}

_RAI_TRACER_NAME = "rai-trust-sdk"


# ── Span helpers ──────────────────────────────────────────────────────────────

@contextmanager
def _guardrail_span(
    content:    str,
    role:       ContentRole,
    session_id: Optional[str],
    request_id: str,
    app_id:     str,
) -> Generator[Any, None, None]:
    """
    Context manager that wraps a governance call in an OpenInference GUARDRAIL
    span.  Yields the span (or None when OTel is not available) so the caller
    can record output attributes after the HTTP call completes.

    The span is created from the *global* TracerProvider, so it automatically
    becomes a child of whatever LangChain / LangGraph span is currently active
    on the OTel context stack — no parent plumbing required.
    """
    if not _OTEL_AVAILABLE:
        yield None
        return

    tracer = _otel_trace.get_tracer(_RAI_TRACER_NAME)
    with tracer.start_as_current_span(f"rai.guardrail.{role.value}") as span:
        # ── Input attributes (set before the HTTP call) ──────────────────────
        span.set_attribute(_ATTR_SPAN_KIND,  _KIND_GUARDRAIL)
        span.set_attribute(_ATTR_INPUT_VAL,  content)
        span.set_attribute(_ATTR_INPUT_MIME, _ROLE_MIME.get(role.value, "text/plain"))
        if session_id:
            span.set_attribute(_ATTR_SESSION_ID, session_id)
        # Seed metadata with request context — enriched with verdict detail
        # after the call completes via _record_span_output().
        span.set_attribute(
            _ATTR_METADATA,
            json.dumps({"app_id": app_id, "role": role.value, "request_id": request_id}),
        )
        yield span


def _record_span_output(span: Any, result: GovernanceResult, app_id: str, role: str) -> None:
    """
    Attach verdict detail to a completed GUARDRAIL span.

    output.value is a JSON object structured so Arize custom evaluators can
    parse it:  {"verdict": "...", "violations": [...], "failed_evaluations": [...]}

    metadata is updated with the full policy context (policies, pack_trace,
    session_summary) so engineers can inspect the complete evaluation in Arize's
    span detail panel without needing to query the audit store.
    """
    if span is None:
        return

    # ── output.value ─────────────────────────────────────────────────────────
    output_doc: Dict[str, Any] = {
        "verdict":            result.verdict.value,
        "violations":         result.violations,
        "failed_evaluations": [fe.to_dict(exclude_none=True) for fe in result.failed_evaluations],
    }
    if result.directives:
        output_doc["directives"] = [
            {"action": d.action.value, "category": d.category.value if d.category else None,
             "source": d.source.value}
            for d in result.directives
        ]
    if result.response_text:
        output_doc["response_text"] = result.response_text
    elif result.remediations:
        output_doc["remediations"] = result.remediations   # deprecated path
    span.set_attribute(_ATTR_OUTPUT_VAL,  json.dumps(output_doc))
    span.set_attribute(_ATTR_OUTPUT_MIME, "application/json")

    # ── metadata — rich context for Arize span detail ─────────────────────────
    meta: Dict[str, Any] = {
        "app_id":     app_id,
        "role":       role,
        "request_id": result.request_id,
        "verdict":    result.verdict.value,
    }
    if result.policies:
        meta["policies"] = [p.to_dict(exclude_none=True) for p in result.policies]
    if result.pack_trace:
        meta["pack_trace"] = result.pack_trace
    if result.session_summary:
        meta["session_summary"] = result.session_summary.to_dict()
    span.set_attribute(_ATTR_METADATA, json.dumps(meta))

    # ── tag.tags — list of "key:value" strings for Arize dataset filtering ───────
    # Arize uses tag.tags as a faceted list so analysts can filter/group by role,
    # verdict, or app without querying into the metadata JSON blob.
    span.set_attribute(_ATTR_TAG_TAGS, (
        f"role:{role}",
        f"verdict:{result.verdict.value}",
        f"app_id:{app_id}",
    ))

    # ── OTel status ───────────────────────────────────────────────────────────
    # COERCIVE → ERROR  so the span shows as a failure in Arize dashboards and
    # alert rules can fire on guardrail-blocked requests.
    if result.verdict == Verdict.COERCIVE:
        span.set_status(
            _OtelStatusCode.ERROR,
            f"Governance block: {'; '.join(result.violations) or 'policy violation'}",
        )
    else:
        span.set_status(_OtelStatusCode.OK)


# ── Client ────────────────────────────────────────────────────────────────────

class TrustClient:
    """
    Synchronous client for ``POST /v1/app/evaluate``.

    Parameters
    ──────────
    base_url : str
        Base URL of the Policy Engine, e.g. ``"http://localhost:3000"``.
    app_id : str
        Application identifier scoping the policy lookup.
    identity : AgentIdentity, optional
        NHI credential provider.  When supplied, ``agent_id`` is included in
        every payload and credential headers are injected automatically.
    timeout : float
        Per-request timeout in seconds (default 5.0).
    api_key : str, optional
        Bearer token for PAP / PE authentication.

    Usage
    ─────
    ::

        client = TrustClient(base_url="http://pe:3000", app_id="finapp")

        # Evaluate a user prompt (raises GovernanceBlock if COERCIVE)
        result = client.evaluate(
            content="Transfer $10,000 to account 9821",
            role=ContentRole.USER_PROMPT,
        )

        # As a context manager (closes connection pool on exit)
        with TrustClient(...) as client:
            result = client.evaluate(...)

    Arize tracing
    ─────────────
    If the host application has initialised a TracerProvider (e.g. via
    ``arize.otel.register()`` or ``phoenix.otel.register()``), every
    ``evaluate()`` call automatically emits a GUARDRAIL span.  No extra
    configuration is needed in the SDK.
    """

    def __init__(
        self,
        base_url: str,
        app_id: str,
        identity: Optional[AgentIdentity] = None,
        timeout: float = 5.0,
        api_key: Optional[str] = None,
        app_key: Optional[str] = None,
        on_result: Optional[Callable[[GovernanceResult, ContentRole], None]] = None,
        enforcement_mode: Optional[EnforcementMode] = None,
    ) -> None:
        self._app_id   = app_id
        self._identity = identity

        # on_result / enforcement_mode are set here or patched by instrument() AFTER the
        # startup self-test has resolved the effective posture. on_result is the single
        # owner of the hook for the ASYNC path (the background worker fires it with the
        # REAL verdict). enforcement_mode is advertised to the Platform on every request
        # so it can shape the remediation (see REDACT contract in types.EnforcementMode).
        self._on_result        = on_result
        self._enforcement_mode = enforcement_mode

        # Background dispatcher for ASYNC (observe-only) evaluations — created lazily so a
        # SYNC-only app never spawns it. Bounded pool; each task is bounded by the httpx
        # timeout, so a stuck PE cannot pile up unbounded work on the request path.
        self._async_executor: Optional[ThreadPoolExecutor] = None
        self._async_lock = threading.Lock()

        headers: Dict[str, str] = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        if app_key:
            # App credential = the client_secret issued at onboarding — the PE/PAP
            # verify it against config_app_credentials. See onboarding spec §6.
            headers["X-RAI-App-Key"] = app_key
        if identity:
            headers.update(identity.get_headers())

        self._http = httpx.Client(
            base_url=str(base_url or "").rstrip("/"),   # never crash on a None/non-str base_url
            headers=headers,
            timeout=timeout,
        )
        logger.debug(f"TrustClient initialised: base_url={base_url!r} app_id={app_id!r}")

    # ── Core API ───────────────────────────────────────────────────────────────

    def evaluate(
        self,
        content: str,
        role: ContentRole,
        *,
        request_id: Optional[str] = None,
        session_id: Optional[str] = None,
        eval_mode: EvalMode = EvalMode.SYNC,
        enforcement_mode: Optional[EnforcementMode] = None,
        metadata: Optional[Dict[str, Any]] = None,
        raise_on_block: bool = True,
    ) -> GovernanceResult:
        """
        Evaluate ``content`` through the Trust Platform.

        Parameters
        ──────────
        content : str
            The text to evaluate (post-privacy-proxy sanitised).
        role : ContentRole
            Semantic role of the content.
        request_id : str, optional
            OTel trace ID.  Auto-generated (UUID4) if omitted.
        session_id : str, optional
            Multi-turn session correlation ID.  When supplied the PE accumulates
            per-dimension scores across turns.
        eval_mode : EvalMode
            ``SYNC`` (default) blocks and returns a verdict.
            ``ASYNC`` is truly non-blocking: the request is dispatched onto a
            background worker and this call returns IMMEDIATELY with a synthetic
            PERMISSIVE acknowledgement (``async_dispatched=True``). The real verdict
            is computed off-thread (audit trail + ``on_result`` hook), never blocks
            the caller, and never raises.
        enforcement_mode : EnforcementMode, optional
            The caller's configured enforcement posture. Advertised to the Platform
            as an optional request attribute so it can shape the remediation — most
            importantly, so it knows a REDACT caller needs substitution ``response_text``
            (see the REDACT contract in ``types.EnforcementMode``). Defaults to the
            client-level ``enforcement_mode`` set at construction / by instrument().
        metadata : dict, optional
            Arbitrary caller metadata written to the audit trail only.
        raise_on_block : bool
            When ``True`` (default) and verdict is ``COERCIVE`` in SYNC mode,
            raises ``GovernanceBlock``.  Set to ``False`` to inspect the result
            without raising.

        Returns
        ───────
        GovernanceResult

        Raises
        ──────
        GovernanceBlock
            When ``raise_on_block=True``, ``eval_mode=SYNC``, and the PE
            returns ``COERCIVE``.
        PolicyUnavailable
            When the PE is reachable but has no policies loaded (HTTP 563),
            after the client's bounded retry (honouring ``Retry-After``) is
            exhausted. The PE self-heals once its policy store is seeded; the
            middleware treats this as a transient-server, fail-open condition.
        httpx.HTTPStatusError
            On other 4xx/5xx responses from the PE.
        httpx.TimeoutException
            When the PE does not respond within ``timeout`` seconds.
        """
        rid = request_id or str(uuid.uuid4())

        # Always include 'source' for audit trail and backward-compatible context
        # routing (apps not yet in app_stacks fall back to context_routing.yaml).
        # For registered apps, pack activation is driven by the app_stack assignment
        # in the PE — not by this field.  Caller-supplied metadata is merged in
        # so tool_name, agent_id, etc. are preserved.
        merged_metadata: Dict[str, Any] = {"source": self._app_id}
        if metadata:
            merged_metadata.update(metadata)
        # Stamp the audit-metadata contract version AUTHORITATIVELY (after the merge, so
        # caller metadata cannot override it). This is the single choke point every
        # interception point (user_prompt / agent_to_agent / tool_call / llm_response)
        # passes through, so one line makes every audit row self-describing.
        merged_metadata["_schema"] = AUDIT_SCHEMA_VERSION

        payload: Dict[str, Any] = {
            "app_id":     self._app_id,
            "request_id": rid,
            "role":       role.value,
            "content":    content,
            "eval_mode":  eval_mode.value,
            "metadata":   merged_metadata,
        }
        # Advertise the caller's enforcement posture (optional attribute). Lets the
        # Platform generate the correct remediation — e.g. REDACT needs response_text.
        _enf = enforcement_mode if enforcement_mode is not None else self._enforcement_mode
        if _enf is not None:
            payload["enforcement_mode"] = getattr(_enf, "value", str(_enf))
        if session_id:
            payload["session_id"] = session_id
        # ── Actor resolution — the ONE choke point every eval passes through ──────────────
        # Guarantees audit.agent_id is never blank and always names the ACTING agent, so a new
        # emit site can never reintroduce the blank/mis-attributed rows we chased for weeks.
        # Priority:
        #   NHI verified identity                         (crypto identity, when configured)
        #   > metadata.agent_id                           (explicit caller override)
        #   > metadata.from_agent                         (CANONICAL source actor; "user" for prompts)
        #   > metadata.source_agent                       (A2A current-wire source alias)
        #   > metadata.agent_name / agent                 (LEGACY alias — at A2A this is the TARGET,
        #                                                   so it is the LAST resort, never above source)
        # from_agent/source_agent rank ABOVE agent_name precisely so agent_to_agent rows attribute to
        # the SOURCE (the actor that handed off), not the receiver.
        _agent_id = (self._identity.agent_id if self._identity else None) \
            or merged_metadata.get("agent_id") \
            or merged_metadata.get("from_agent") \
            or merged_metadata.get("source_agent") \
            or merged_metadata.get("agent_name") \
            or merged_metadata.get("agent")
        # A user_prompt has no agent actor — the user IS the actor. Non-negotiable: never blank.
        if not _agent_id and role == ContentRole.USER_PROMPT:
            _agent_id = "user"
        if not _agent_id:
            # An agent-scoped eval with no resolvable actor is a DEFECT (an emit site failed to
            # stamp from_agent). Surface it LOUDLY and tag it so it is trivially found in the audit
            # trail and by the attribution test — never silently blank, never a fabricated name.
            logger.error(
                "TrustClient: agent_id UNRESOLVED for role=%s request_id=%s metadata_keys=%s — "
                "an emit site did not stamp from_agent", role.value, rid,
                sorted((metadata or {}).keys()),
            )
            _agent_id = "unattributed"
        payload["agent_id"] = _agent_id
        # Mirror the resolved actor into metadata.from_agent so the audit edge and every downstream
        # reader see the SAME actor the platform attributes the eval to (idempotent — never overwrites
        # an explicit source already set by an emit site).
        merged_metadata.setdefault("from_agent", _agent_id)

        # ── TARGET-side guarantee — symmetric to the actor resolution above ───────────────
        # The SOURCE has been guaranteed non-blank for months; the TARGET (to_agent) never got
        # the same treatment, so a destination could go SILENTLY missing (a conditional entry
        # node, or any emit site that forgot it). Give it the same choke-point guarantee: fill
        # the deterministic targets, and surface an unresolved agent_to_agent target LOUDLY
        # instead of dropping it. A user_prompt MAY omit it (entry node can be conditional).
        if not merged_metadata.get("to_agent"):
            if role == ContentRole.LLM_RESPONSE:
                merged_metadata["to_agent"] = "user"            # an llm_response always terminates at the user
            elif role == ContentRole.TOOL_CALL:
                merged_metadata["to_agent"] = merged_metadata.get("tool_name") or "unattributed_tool"
            elif role == ContentRole.AGENT_TO_AGENT:
                logger.error(
                    "TrustClient: to_agent UNRESOLVED for role=agent_to_agent request_id=%s metadata_keys=%s "
                    "— an emit site did not stamp the handoff target", rid, sorted((metadata or {}).keys()),
                )
                merged_metadata["to_agent"] = "unattributed"
            elif role == ContentRole.USER_PROMPT:
                logger.debug(
                    "TrustClient: user_prompt to_agent absent (conditional entry node) request_id=%s", rid
                )

        # ── Contract gate — the ONE invariant every eval must satisfy before it leaves ──
        # The resolution above guarantees from/to are non-BLANK; this guarantees they are
        # VALID (no self-loop, correct terminus per role). A violation here is an upstream
        # emit-site defect: it is logged LOUD + counted always, and raises in strict/CI so a
        # regression fails the suite instead of shipping a wrong interaction edge. This is the
        # single place that makes the from/to class of bug impossible to ship silently.
        enforce_contract(role, merged_metadata, request_id=rid)

        # Certification capture (off unless RAI_EVAL_CAPTURE names a file): record EVERY
        # outbound message + its contract verdict so a run can be certified exhaustively.
        capture_eval(role, merged_metadata, content, request_id=rid, session_id=session_id or "")

        _echo_eval_request(payload)     # visible request echo (RAI_ECHO_EVAL_REQUEST=0 to silence)
        logger.debug(f"TrustClient.evaluate role={role.value} request_id={rid} eval_mode={eval_mode.value}")

        # ── ASYNC = truly non-blocking (observe-only) ─────────────────────────
        # Dispatch the evaluation off the caller's thread and return immediately.
        # The verdict is computed on a background worker (audit + on_result). This
        # is the single seam that makes every ASYNC call site non-blocking without
        # per-site changes: callers get a valid result object (PERMISSIVE) and the
        # ASYNC enforcement guards elsewhere ensure it never blocks or enforces.
        if eval_mode == EvalMode.ASYNC:
            self._dispatch_async(payload, content, role, session_id, rid, metadata)
            return GovernanceResult(
                request_id=rid, verdict=Verdict.PERMISSIVE, async_dispatched=True,
            )

        # ── SYNC = blocking gate ──────────────────────────────────────────────
        result = self._post_evaluate(payload, content, role, session_id, rid, metadata)

        if raise_on_block and result.verdict == Verdict.COERCIVE and eval_mode == EvalMode.SYNC:
            raise GovernanceBlock(result)

        return result

    # ── HTTP + async dispatch internals ─────────────────────────────────────────

    def _post_evaluate(
        self,
        payload: Dict[str, Any],
        content: str,
        role: ContentRole,
        session_id: Optional[str],
        rid: str,
        metadata: Optional[Dict[str, Any]],
    ) -> GovernanceResult:
        """Blocking POST to the PE + parse + span output. Shared by the SYNC path and
        the ASYNC background worker. Raises on transport/HTTP error (callers decide)."""
        # ── GUARDRAIL span wraps the HTTP call ────────────────────────────────
        # _guardrail_span() resolves to a no-op context manager when no
        # TracerProvider is configured, so there is no performance cost unless
        # the host application has explicitly initialised OTel.
        with _guardrail_span(content, role, session_id, rid, self._app_id) as span:
            response = self._post_evaluate_http(payload, rid)
            response.raise_for_status()

            result = GovernanceResult.from_response(response.json())
            logger.debug(
                f"TrustClient verdict={result.verdict.value} "
                f"violations={result.violations} request_id={rid}"
            )

            # Record output attributes on the span before it closes
            _record_span_output(span, result, self._app_id, role.value)

            # ── Agent / tool context from caller metadata ─────────────────────
            # These are first-class OpenInference attributes so Arize can filter
            # and group spans by agent or tool without parsing the metadata blob.
            if span is not None and metadata:
                _agent = metadata.get("agent_name")
                if _agent:
                    span.set_attribute(_ATTR_AGENT_NAME, str(_agent))
                _tool = metadata.get("tool_name")
                if _tool:
                    span.set_attribute(_ATTR_TOOL_NAME, str(_tool))

        return result

    def _post_evaluate_http(self, payload: Dict[str, Any], rid: str) -> "httpx.Response":
        """POST to the PE, transparently retrying the policy-store-unavailable (563) case.

        The PE returns 563 when it is reachable but has no policies loaded yet (unseeded
        config_policies, or the DB briefly down). That is RETRYABLE and self-healing, so
        we retry a bounded number of times (honouring Retry-After, capped) to bridge the
        seed window, then raise PolicyUnavailable so the caller/middleware applies its
        transient-server disposition. All OTHER responses (including other 5xx) are
        returned unchanged for raise_for_status() to handle as before."""
        attempts = _PU_RETRIES + 1
        for i in range(1, attempts + 1):
            response = self._http.post("/v1/app/evaluate", json=payload)
            if not _is_policy_unavailable(response):
                return response
            retry_after = _retry_after_seconds(response)
            if i >= attempts:
                logger.warning(
                    "[RAI Trust] PE policy store unavailable (HTTP %s) after %d attempt(s) — "
                    "raising PolicyUnavailable. request_id=%s",
                    response.status_code, attempts, rid,
                )
                raise PolicyUnavailable(
                    request_id=rid, status=response.status_code, retry_after=retry_after,
                )
            delay = min(retry_after if retry_after is not None else _PU_BACKOFF, _PU_BACKOFF_CAP)
            logger.warning(
                "[RAI Trust] PE policy store unavailable (HTTP %s) — retrying in %.1fs (%d/%d). "
                "request_id=%s", response.status_code, delay, i, attempts, rid,
            )
            if delay > 0:
                time.sleep(delay)
        # Unreachable (loop either returns or raises), but keep mypy/readers happy.
        raise PolicyUnavailable(request_id=rid, status=POLICY_UNAVAILABLE_STATUS)

    def _ensure_async_executor(self) -> Optional[ThreadPoolExecutor]:
        """Lazily create the background dispatcher (SYNC-only apps never spawn it)."""
        ex = self._async_executor
        if ex is not None:
            return ex
        with self._async_lock:
            if self._async_executor is None:
                self._async_executor = ThreadPoolExecutor(
                    max_workers=4, thread_name_prefix="rai-async-eval",
                )
            return self._async_executor

    def _dispatch_async(
        self,
        payload: Dict[str, Any],
        content: str,
        role: ContentRole,
        session_id: Optional[str],
        rid: str,
        metadata: Optional[Dict[str, Any]],
    ) -> None:
        """Submit an observe-only evaluation to the background pool. Never raises into
        the caller — a dispatch failure degrades to a skipped (permissive) eval."""
        try:
            ex = self._ensure_async_executor()
            ex.submit(self._async_worker, payload, content, role, session_id, rid, metadata)
        except Exception as exc:
            logger.warning(
                "[RAI Trust] ASYNC dispatch failed — this observe-only evaluation was "
                "skipped (host unaffected). error=%s", exc,
            )

    def _async_worker(
        self,
        payload: Dict[str, Any],
        content: str,
        role: ContentRole,
        session_id: Optional[str],
        rid: str,
        metadata: Optional[Dict[str, Any]],
    ) -> None:
        """Runs on a background thread: POST the eval, then forward the REAL verdict to
        on_result. Swallows every error — a worker exception must never surface."""
        try:
            result = self._post_evaluate(payload, content, role, session_id, rid, metadata)
        except Exception as exc:
            logger.warning(
                "[RAI Trust] ASYNC eval failed on the background worker (observe-only, "
                "not enforced). error=%s", exc,
            )
            return
        if self._on_result is not None:
            try:
                self._on_result(result, role)
            except Exception:
                pass

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def close(self) -> None:
        """Close the underlying HTTP connection pool and drain the async dispatcher."""
        ex = self._async_executor
        if ex is not None:
            # wait=False: don't hang shutdown on a slow PE. Each task is bounded by the
            # httpx timeout, so in-flight observe-only evals finish (or time out) shortly.
            try:
                ex.shutdown(wait=False)
            except Exception:
                pass
        self._http.close()

    def __enter__(self) -> "TrustClient":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return (
            f"TrustClient(base_url={self._http.base_url!r}, "
            f"app_id={self._app_id!r})"
        )
