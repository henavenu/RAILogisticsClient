"""
Core types for the RAI Trust SDK.

These mirror the Policy Engine's request/response schemas (SRS §4.5) so the
SDK has no runtime dependency on the PE codebase.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Mapping, Optional

# The SDK has NO third-party model dependency: response types are hand-written
# dataclasses parsed by explicit from_response()/from_dict() classmethods (see
# ResponseParseError). This is deliberate — the inbound PE response is untrusted
# JSON on a governance-critical path, and explicit parsing with a documented
# fail direction is more predictable (and dependency-free) than validator magic.

# ── Wire-boundary coercions ───────────────────────────────────────────────────
# The Policy Engine's JSON contract is generous: any OPTIONAL field can arrive as
# `null` on the wire (a rendering path that produced nothing, a legacy response
# shape, a proxy that stripped fields, future schema drift). The parsers below
# coerce every such null to the field's normal empty value so a null never fails
# the parse — which would otherwise risk a silent governance bypass. The verdict
# is the ONE field that fails CLOSED (see GovernanceResult.from_response): an
# unknown/missing verdict raises ResponseParseError, never a silent PERMISSIVE.
# See feedback_no_broad_except_on_governance.md for the 2026-09-01 incident.

def _as_str(v: Any) -> str:
    """Wire null / missing → empty string (keeps downstream `str` type stable)."""
    return "" if v is None else str(v)


def _as_list(v: Any) -> list:
    """Wire null / falsy → empty list (keeps downstream `List[...]` type stable)."""
    return list(v) if v else []


def _as_opt_int(v: Any) -> Optional[int]:
    try:
        return int(v) if v is not None else None
    except (TypeError, ValueError):
        return None


# ── Enums ─────────────────────────────────────────────────────────────────────

class ContentRole(str, Enum):
    """Content classification for governance evaluation."""
    USER_PROMPT     = "user_prompt"
    LLM_RESPONSE    = "llm_response"
    AGENT_TO_AGENT  = "agent_to_agent"
    TOOL_CALL       = "tool_call"       # Phase 4+ — pre/post tool execution
    HITL_CHECKPOINT = "hitl_checkpoint" # governance pause event — pass-through, not evaluated


class EvalMode(str, Enum):
    """Evaluation execution mode — decides *whether the verdict blocks the request path*.

    Only two coherent postures exist (the SDK self-test at instrument() time coerces
    any other pairing with EnforcementMode and logs a WARNING):

        SYNC  + {RAISE | REDACT}   → the enforcing GATE
        ASYNC + NONE               → observe-only

    SYNC+NONE (pay the round-trip, enforce nothing) auto-corrects to SYNC+RAISE;
    ASYNC+{RAISE,REDACT} (can't enforce what you never wait for) auto-corrects to
    ASYNC+NONE.
    """
    SYNC  = "SYNC"   # Block on the verdict; enforcement acts on it (the gate).
    ASYNC = "ASYNC"  # Truly non-blocking: the evaluation is dispatched OFF the request
                     # path onto a background worker and returns immediately. It never
                     # blocks, redacts, raises, or interrupts (observe-only); the verdict
                     # is recorded server-side (PAP audit / dashboard) and, if an
                     # on_result hook is set, delivered from the worker thread.


class PrivacyProvider(str, Enum):
    """Which in-process privacy proxy the SDK runs before content reaches the Policy
    Engine — a first-class configuration peer of EvalMode / EnforcementMode. Passed to
    ``instrument(privacy_proxy=...)`` (global override: env RAI_PRIVACY_PROXY). A plain
    string ("regex"/"presidio"/"none") or a custom object with ``.process(text)`` is also
    accepted, but this enum gives type-safety and IDE completion like the other modes.

    NONE
        No privacy proxy — content reaches the PE unmasked (explicit opt-out).
    REGEX  *(zero-dependency)*
        Pattern + entity-name tokenization (credentials, account/routing numbers,
        emails, …). Pure Python, sub-millisecond, no ML dependency.
    PRESIDIO
        REGEX plus Microsoft Presidio NLP (spaCy NER) for names/orgs/free-form PII.
        Needs ``pip install rai-trust-sdk[presidio]``; degrades to REGEX + entity
        tokenization automatically when the extra is not installed.
    """
    NONE     = "none"
    REGEX    = "regex"
    PRESIDIO = "presidio"


class EnforcementMode(str, Enum):
    """
    Controls how the SDK acts on a COERCIVE policy verdict.

    NONE
        Log the result, then continue execution unchanged. This is the canonical
        enforcement value for the observe-only posture (``eval_mode=ASYNC``); the
        two are paired automatically by the instrument() self-test. It is NOT a
        valid pairing with ``eval_mode=SYNC`` (that would pay the round-trip and
        enforce nothing) — SYNC+NONE auto-corrects to SYNC+RAISE.

    REDACT  *(default)*
        Substitute safe content for COERCIVE verdicts without raising an exception.
        Layer 1 (USER_PROMPT): graph is not invoked; a policy-safe refusal is returned.
        Layer 2 (TOOL_CALL): tool is blocked; a safe refusal is returned as the reply.
        Layer 3 (LLM_RESPONSE): the LLM output is replaced with a safe refusal.
        Applications need zero error-handling code.

        CONTRACT — REDACT depends on the Trust Platform SUPPLYING the substitution
        content. The SDK substitutes ``GovernanceResult.response_text`` (the
        PE-rendered, context-aware refusal via MessageWriter), falling back to
        ``remediations[0]`` and finally a generic built-in refusal. So for REDACT to
        produce a *useful* reply the Platform must return response_text/remediations;
        if the Platform returns none, the app still stays safe (generic refusal) but
        loses the tailored wording. Because of this, the SDK advertises its
        enforcement_mode on every evaluate request (see client.evaluate) so the
        Platform knows a caller is in REDACT and can generate the correct remediation.
        REDACT is also useful for NORMATIVE (advisory) outcomes with no HITL — the
        Platform can hand back softened/annotated content the SDK surfaces in place of
        the raw output, without pausing for a human.

    RAISE
        Raise ``GovernanceBlock`` on COERCIVE verdicts.
        Opt-in for applications that want rich exception data (violations list,
        verdict, request_id) to build custom UI responses such as flagging the
        blocked action in a chat widget. Needs no Platform-supplied substitution.
    """
    NONE   = "NONE"
    REDACT = "REDACT"
    RAISE  = "RAISE"

    @classmethod
    def _from_on_block(cls, on_block: str) -> "EnforcementMode":
        """Map the modern ``on_block`` selector ('redact' | 'raise') to an
        EnforcementMode. ``on_block`` names the COERCIVE-block behaviour directly,
        separate from ``eval_mode`` (which decides whether to block at all)."""
        key = (on_block or "").strip().lower()
        mapping = {"redact": cls.REDACT, "raise": cls.RAISE}
        if key not in mapping:
            raise ValueError(f"on_block must be 'redact' or 'raise', got {on_block!r}")
        return mapping[key]


def validate_modes(eval_mode: "EvalMode", enforcement_mode: "EnforcementMode"):
    """Startup self-test for the (eval_mode, enforcement_mode) pair — shared by every
    SDK distribution so the coherence rules never diverge between frameworks.

    Only two coherent postures exist:
        SYNC  + {RAISE | REDACT}   -> the enforcing gate
        ASYNC + NONE               -> observe-only

    Any other pairing is silently useless, so it is coerced to the coherent neighbour
    and a human-readable note is returned for the caller to log loudly and print in the
    boot banner. Never raises.

    Returns ``(eval_mode, enforcement_mode, notes)`` — ``notes`` is a list of correction
    strings (empty when the pair was already valid).
    """
    notes: list = []
    if eval_mode == EvalMode.ASYNC and enforcement_mode in (
        EnforcementMode.RAISE, EnforcementMode.REDACT,
    ):
        notes.append(
            "eval_mode=ASYNC + enforcement_mode=%s is not a valid combination — "
            "ASYNC is observe-only and never enforces. Defaulting to ASYNC + NONE."
            % enforcement_mode.value
        )
        enforcement_mode = EnforcementMode.NONE
    elif eval_mode == EvalMode.SYNC and enforcement_mode == EnforcementMode.NONE:
        notes.append(
            "eval_mode=SYNC + enforcement_mode=NONE is not a valid combination — it pays "
            "the blocking round-trip and enforces nothing. Defaulting to SYNC + RAISE."
        )
        enforcement_mode = EnforcementMode.RAISE
    return eval_mode, enforcement_mode, notes


class Verdict(str, Enum):
    """Policy verdict returned by the Trust Platform."""
    PERMISSIVE = "PERMISSIVE"  # All evaluations within safe band — proceed
    NORMATIVE  = "NORMATIVE"   # One or more warnings — proceed with caution
    COERCIVE   = "COERCIVE"    # Policy violation — block in SYNC mode


# ── Directive taxonomy ─────────────────────────────────────────────────────────
#
# Directives are *actionable instructions* from the PE to the SDK.
# Distinct from verdicts (which describe what was detected).
# The SDK processes directives after receiving a GovernanceResult — these are
# mirrored from policy-engine/schemas/response.py and must stay in sync.

class DirectiveAction(str, Enum):
    """Action the SDK must take upon receiving a directive."""
    REDACT               = "redact"
    REQUIRE_HUMAN_REVIEW = "require_human_review"
    EVICT_AGENT          = "evict_agent"


class HITLCategory(str, Enum):
    """
    Category of human review required.
    Drives which reviewer options the HITL UI presents.
    """
    AGENT_ARBITRATION = "agent_arbitration"
    # Deadlocked multi-agent negotiation (propose-and-dispose pattern).

    SANCTIONS_REVIEW  = "sanctions_review"
    # AML/sanctions flag requiring compliance sign-off.


class DirectiveSource(str, Enum):
    """Component that issued the directive."""
    PE          = "pe"
    SENTINEL    = "sentinel"
    COORDINATOR = "coordinator"


# Default reviewer options per HITL category.
HITL_DEFAULT_OPTIONS: Dict[str, List[str]] = {
    HITLCategory.AGENT_ARBITRATION.value: [
        "approve_recommendation",
        "select_alternative",
        "reject_all",
        "request_more_information",
        "escalate_to_advisor",
    ],
    HITLCategory.SANCTIONS_REVIEW.value: [
        "approve",
        "approve_with_waiver",
        "temporary_exemption",
        "reject",
        "update_policy",
        "escalate_to_compliance",
        "file_sar",
    ],
}


@dataclass
class Directive:
    """
    Structured, actionable instruction from the PE (or Sentinel via PE) to the SDK.

    The SDK processes directives in priority order after receiving GovernanceResult:
        REQUIRE_HUMAN_REVIEW  →  raise HITLInterrupt (highest priority)
        REDACT                →  substitute response with response_text
    """
    action:   DirectiveAction
    category: Optional[HITLCategory] = None
    reason:   str                    = ""
    options:  List[str]              = field(default_factory=list)
    source:   DirectiveSource        = DirectiveSource.PE
    metadata: Dict[str, Any]         = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Auto-populate reviewer options from defaults when not explicitly set."""
        if (
            self.action == DirectiveAction.REQUIRE_HUMAN_REVIEW
            and not self.options
            and self.category is not None
            and self.category.value in HITL_DEFAULT_OPTIONS
        ):
            self.options = list(HITL_DEFAULT_OPTIONS[self.category.value])

    @classmethod
    def from_dict(cls, d: Mapping[str, Any]) -> "Directive":
        """Parse one PE directive. An unknown action/category is contract DRIFT and
        raises (caught by GovernanceResult.from_response → ResponseParseError, fail-closed):
        the SDK must never silently ignore an instruction it cannot understand."""
        action = DirectiveAction(d.get("action"))                       # unknown -> ValueError (drift)
        cat = d.get("category")
        category = HITLCategory(cat) if cat else None                   # unknown -> ValueError (drift)
        src = d.get("source") or DirectiveSource.PE.value
        try:
            source = DirectiveSource(src)
        except ValueError:
            source = DirectiveSource.PE                                 # unknown source is non-critical -> default
        return cls(
            action=action, category=category, reason=_as_str(d.get("reason")),
            options=[_as_str(o) for o in _as_list(d.get("options"))],
            source=source, metadata=dict(d.get("metadata") or {}),
        )

    def to_dict(self, exclude_none: bool = False) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "action":   self.action.value,
            "category": self.category.value if self.category is not None else None,
            "reason":   self.reason,
            "options":  list(self.options),
            "source":   self.source.value,
            "metadata": dict(self.metadata),
        }
        return {k: v for k, v in out.items() if v is not None} if exclude_none else out


# Priority order for SDK directive processing (highest first)
_DIRECTIVE_PRIORITY: Dict[DirectiveAction, int] = {
    DirectiveAction.REQUIRE_HUMAN_REVIEW: 10,
    DirectiveAction.REDACT:               5,
}


# ── Exception ─────────────────────────────────────────────────────────────────

class GovernanceBlock(Exception):
    """
    Raised in SYNC mode when the Policy Engine returns a COERCIVE verdict.

    Propagates naturally through both LangChain chains and LangGraph graph
    execution, terminating the run without requiring explicit check-and-raise
    boilerplate in application code.

    Attributes:
        result: The full GovernanceResult that triggered the block.
    """
    def __init__(self, result: GovernanceResult):
        self.result = result
        violations = "; ".join(result.violations) if result.violations else "policy violation"
        super().__init__(
            f"[RAI Trust] COERCIVE verdict — {violations} "
            f"(request_id={result.request_id})"
        )


class GovernanceHold(Exception):
    """
    Raised when the Policy Engine returns a NORMATIVE verdict that carries a
    remediation to effect.

    NORMATIVE's contract is a GATED HOLD — the request cannot be processed UNTIL
    the remediation is effected — and is therefore a THIRD actuation, distinct
    from both COERCIVE and HITL:

      • COERCIVE (GovernanceBlock) — TERMINAL. Posture-dependent: RAISE propagates,
        REDACT substitutes a refusal. The request is refused outright.
      • NORMATIVE (GovernanceHold) — a HOLD. The withheld action's place carries
        the remediation INSTRUCTION, in BOTH enforcement postures (a hold is never
        a terminal raise). It is RE-ATTEMPTABLE: the caller effects the remediation
        (e.g. obtains the required consent) and the SAME request then passes on a
        later attempt. "cannot proceed UNTIL …", not "cannot proceed."
      • HITLInterrupt — a PAUSE pending a human reviewer's decision.

    A NORMATIVE verdict with NO remediation to effect does NOT raise this: there is
    nothing to hold for, so it degrades to an advisory and proceeds (logged loudly —
    a NORMATIVE policy that names no remediation is an authoring gap, never a silent
    pass).

    Attributes:
        result: the full GovernanceResult that triggered the hold.
    """
    def __init__(self, result: GovernanceResult):
        self.result = result
        super().__init__(
            f"[RAI Trust] NORMATIVE hold — request withheld pending remediation "
            f"(request_id={result.request_id})"
        )

    @property
    def remediation_text(self) -> str:
        """The remediation instruction to surface in place of the withheld action."""
        return (
            self.result.response_text
            or (self.result.remediations[0] if self.result.remediations else "")
        )


class HITLInterrupt(Exception):
    """
    Raised when a PE directive requires human-in-the-loop (HITL) review.

    Triggered when the Policy Engine returns a ``Directive`` with
    ``action=REQUIRE_HUMAN_REVIEW`` in the evaluation response.  Unlike
    ``GovernanceBlock`` (which terminates on COERCIVE verdicts), HITLInterrupt
    signals a governance pause — execution is held pending a reviewer decision
    via the /api/hitl/resolve endpoint.

    Propagates through LangGraph node execution the same way GovernanceBlock
    does, allowing GovernedGraph and the application server to catch it and
    implement the HITL workflow.

    Attributes:
        payload: Context dict with keys:
            reason      — operator-facing explanation from the Directive
            category    — HITLCategory value (e.g. "agent_arbitration")
            options     — reviewer choices to present in the HITL UI
            source      — who issued the directive ("pe" | "sentinel" | "coordinator")
            session_id  — session the review belongs to
            directive   — full Directive to_dict() for downstream consumers
    """
    def __init__(self, payload: dict):
        self.payload = payload
        super().__init__(
            f"[RAI Trust] HITL required — {payload.get('reason', 'governance_review')} "
            f"(session={payload.get('session_id', '?')} "
            f"category={payload.get('category', '?')} "
            f"source={payload.get('source', '?')})"
        )


class AgentEvicted(Exception):
    """
    Raised when an agent that has been evicted attempts to act. Eviction is a
    STANDING block on a specific agent (via an EVICT_AGENT directive or the platform
    eviction manifest) — distinct from GovernanceBlock (a per-action COERCIVE block)
    and HITLInterrupt (a pause). The evicted agent is prevented from taking its next
    step. Enforced from the SDK's local evicted set, so it works in SYNC and ASYNC.

    Attributes:
        agent:  the evicted agent (node) name
        reason: operator-facing explanation
    """
    def __init__(self, agent: str, reason: str = "agent evicted by platform"):
        self.agent = agent
        self.reason = reason
        super().__init__(f"[RAI Trust] Agent evicted — '{agent}': {reason}")


class ResponseParseError(Exception):
    """
    Raised when a PE response cannot be parsed into a GovernanceResult — a
    missing/unknown verdict, an unknown directive action, or a malformed body.

    This signals SDK<->PE CONTRACT DRIFT and is a FAIL-CLOSED signal: the caller
    (middleware) surfaces it loudly and denies, rather than treating an
    unparseable governance verdict as PERMISSIVE. It replaces the pydantic
    ValidationError the SDK used to catch, with the same fail-loud semantics.
    """


class PolicyUnavailable(Exception):
    """
    Raised by the evaluate-client when the Policy Engine is REACHABLE but has NO
    policies loaded — HTTP 563 with body ``error_code='policy_store_unavailable'``.

    This is a DISTINCT, RETRYABLE signal: not a verdict, not a generic 5xx, not an
    SDK/PE contract break. It means the PE could not govern the request because its
    policy store is unseeded/empty (or the DB was briefly unavailable). The client
    retries a bounded number of times (honouring ``Retry-After``) before raising
    this; the middleware then applies its TRANSIENT-SERVER disposition — fail-open
    (skip = PERMISSIVE, loud WARN), the same class as a 5xx or an unreachable PE.
    The PE self-heals once the seed Job populates ``config_policies``.

    Mirrors the PE's ``POLICY_UNAVAILABLE_STATUS`` (policy-engine/api/routes.py).

    Attributes:
        request_id:  the evaluation's request id (for correlation)
        status:      the HTTP status seen (563)
        retry_after: seconds from the Retry-After header, if any
    """
    def __init__(self, request_id: Optional[str] = None, status: int = 563,
                 retry_after: Optional[float] = None):
        self.request_id = request_id
        self.status = status
        self.retry_after = retry_after
        super().__init__(
            f"[RAI Trust] policy store unavailable (HTTP {status}); the Policy Engine "
            f"has no policies loaded (request_id={request_id})"
        )


# ── Response models ────────────────────────────────────────────────────────────

@dataclass
class FailedEvaluation:
    """Per-dimension detail for non-permissive results."""
    dimension: str
    status:    str                       # WARNING | FLAGGED
    score:     Optional[int] = None
    provider:  Optional[str] = None

    @classmethod
    def from_dict(cls, d: Mapping[str, Any]) -> "FailedEvaluation":
        return cls(dimension=_as_str(d.get("dimension")), status=_as_str(d.get("status")),
                   score=_as_opt_int(d.get("score")), provider=d.get("provider"))

    def to_dict(self, exclude_none: bool = False) -> Dict[str, Any]:
        out = {"dimension": self.dimension, "status": self.status,
               "score": self.score, "provider": self.provider}
        return {k: v for k, v in out.items() if v is not None} if exclude_none else out


@dataclass
class PolicyResult:
    """Per-policy verdict detail."""
    policy_name: str
    verdict:     Verdict
    severity:    int                     # 1 (low) – 3 (high)
    score:       Optional[int] = None
    remediation: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Mapping[str, Any]) -> "PolicyResult":
        # verdict drift fails closed (raises → ResponseParseError upstream)
        return cls(policy_name=_as_str(d.get("policy_name")), verdict=Verdict(d.get("verdict")),
                   severity=int(d.get("severity") or 0), score=_as_opt_int(d.get("score")),
                   remediation=d.get("remediation"))

    def to_dict(self, exclude_none: bool = False) -> Dict[str, Any]:
        out = {"policy_name": self.policy_name, "verdict": self.verdict.value,
               "severity": self.severity, "score": self.score, "remediation": self.remediation}
        return {k: v for k, v in out.items() if v is not None} if exclude_none else out


@dataclass
class SessionSummary:
    """
    Multi-turn session trust snapshot.

    Attached to every response when a session_id is present.
    composite_score: 1.0 = fully trusted, 0.0 = maximum risk.
    """
    turn_count:       int = 0
    composite_score:  float = 1.0        # 0.0 – 1.0
    worst_verdict:    str = ""
    dimension_scores: Dict[str, int] = field(default_factory=dict)  # worst raw score (1-9) per dimension
    escalated:        bool = False

    @classmethod
    def from_dict(cls, d: Mapping[str, Any]) -> "SessionSummary":
        try:
            score = float(d.get("composite_score"))
        except (TypeError, ValueError):
            score = 1.0
        return cls(turn_count=int(d.get("turn_count") or 0), composite_score=score,
                   worst_verdict=_as_str(d.get("worst_verdict")),
                   dimension_scores=dict(d.get("dimension_scores") or {}),
                   escalated=bool(d.get("escalated", False)))

    def to_dict(self) -> Dict[str, Any]:
        return {"turn_count": self.turn_count, "composite_score": self.composite_score,
                "worst_verdict": self.worst_verdict, "dimension_scores": dict(self.dimension_scores),
                "escalated": self.escalated}


@dataclass
class GovernanceResult:
    """Full response from POST /v1/app/evaluate.

    Parsed by from_response(): every OPTIONAL field null-coerces to its empty
    value so a wire `null` never fails the parse (a null on a COERCIVE response
    must not become a silent bypass — see feedback_no_broad_except_on_governance).
    The `verdict` is the ONE field that fails CLOSED: an unknown/missing verdict
    raises ResponseParseError rather than defaulting to PERMISSIVE.
    """
    request_id:         str
    verdict:            Verdict
    async_dispatched:   bool = False
    # True only for the synthetic acknowledgement returned immediately by an ASYNC
    # (observe-only) evaluate() call — the real verdict is computed off-thread and,
    # if an on_result hook is set, delivered from the background worker.
    violations:         List[str] = field(default_factory=list)
    # DEPRECATED: kept for one release cycle; use response_text + directives instead.
    remediations:       List[str] = field(default_factory=list)
    response_text:      str = ""
    # Human-readable text the SDK should present when a REDACT directive is present.
    directives:         List["Directive"] = field(default_factory=list)
    # Actionable SDK instructions processed in priority order via _DIRECTIVE_PRIORITY.
    failed_evaluations: List["FailedEvaluation"] = field(default_factory=list)
    policies:           List["PolicyResult"] = field(default_factory=list)
    session_summary:    Optional[SessionSummary] = None
    pack_trace:         List[Dict[str, Any]] = field(default_factory=list)
    evicted_agents:     List[str] = field(default_factory=list)
    # Platform-authoritative eviction manifest for this app_id. The SDK reconciles
    # this into its standing evicted-set on every response (add + reinstate).
    decision:           Optional[str] = None
    # Reviewer's decision, populated ONLY on the native-interrupt HITL path after a resume.

    @classmethod
    def from_response(cls, d: Any) -> "GovernanceResult":
        """Parse a PE /v1/app/evaluate response body. Fail-CLOSED on the verdict and on
        any nested directive/policy drift (raises ResponseParseError); null-tolerant on
        every optional field. Replaces pydantic model_validate with explicit, dependency-free
        parsing on this governance-critical inbound path."""
        if not isinstance(d, Mapping):
            raise ResponseParseError(f"PE response is not a JSON object: {type(d).__name__}")
        try:
            verdict = Verdict(d.get("verdict"))
        except (ValueError, KeyError, TypeError) as exc:
            raise ResponseParseError(
                f"missing/unknown verdict {d.get('verdict')!r} — SDK<->PE contract drift"
            ) from exc
        try:
            directives = [Directive.from_dict(x) for x in _as_list(d.get("directives"))]
            failed = [FailedEvaluation.from_dict(x) for x in _as_list(d.get("failed_evaluations"))]
            policies = [PolicyResult.from_dict(x) for x in _as_list(d.get("policies"))]
        except (ValueError, KeyError, TypeError) as exc:
            raise ResponseParseError(
                f"unparseable directive/policy in PE response — SDK<->PE contract drift "
                f"({type(exc).__name__})"
            ) from exc
        ss = d.get("session_summary")
        return cls(
            request_id=_as_str(d.get("request_id")),
            verdict=verdict,
            async_dispatched=bool(d.get("async_dispatched", False)),
            violations=[_as_str(v) for v in _as_list(d.get("violations"))],
            remediations=[_as_str(v) for v in _as_list(d.get("remediations"))],
            response_text=_as_str(d.get("response_text")),
            directives=directives,
            failed_evaluations=failed,
            policies=policies,
            session_summary=(SessionSummary.from_dict(ss) if ss else None),
            pack_trace=list(_as_list(d.get("pack_trace"))),
            evicted_agents=[_as_str(v) for v in _as_list(d.get("evicted_agents"))],
            decision=d.get("decision"),
        )
