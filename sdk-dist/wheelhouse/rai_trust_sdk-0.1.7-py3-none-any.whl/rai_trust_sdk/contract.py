"""
Interaction-metadata contract — the ONE invariant every evaluation must satisfy
BEFORE it leaves the SDK for the Policy Engine.

Why this exists (read before touching): from/to agent attribution is computed at
many emit sites (L1 user_prompt, L2 tool_call, L2 agent_to_agent, L3 llm_response,
the a2a return, the Command-handoff path). Each site reinvented the attribution, so
each site could break in a NEW way, and the bug only ever surfaced downstream as a
wrong edge in the interaction graph — days later, per-scenario. The client.py choke
point guaranteed from/to were non-BLANK, but never that they were CORRECT (a
self-loop from==to has both fields populated, so it passed silently).

This module makes the contract EXPLICIT and ENFORCEABLE at the single choke point:
`validate_interaction_contract()` returns every violation; `enforce_contract()` wires
it in — loud ERROR + a counter always, and raises in strict mode (CI / tests). A new
bad emit site now fails immediately and visibly instead of shipping a wrong edge.

The 4 interception points and their invariants (the "vanilla schema"):

  user_prompt     from_agent == "user"        ; to_agent optional (conditional entry),
                                                 but if present must be a real agent
  agent_to_agent  from_agent = source agent   ; to_agent = target agent ;
                  from != to (NO self-loop)   ; neither is "user"
  tool_call       from_agent = calling agent  ; to_agent = the tool ; from != to
  llm_response    from_agent = generating node ; to_agent == "user"

An "unattributed*" sentinel in from/to is itself a violation: it means an emit site
failed to stamp the value and the choke point had to guess.
"""
from __future__ import annotations

import json
import logging
import os
import time
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

VALID_ROLES = {"user_prompt", "agent_to_agent", "tool_call", "llm_response"}
_UNRESOLVED = {"unattributed", "unattributed_tool", "unattributed_agent", ""}

# Observable, process-wide counter so a host can surface "N contract violations"
# on a health/metrics endpoint even when not running strict. Never silent.
CONTRACT_VIOLATIONS = 0


class MetadataContractError(ValueError):
    """Raised (strict mode only) when an evaluation's from/to metadata violates the
    interaction contract. In non-strict mode the violation is logged + counted, never
    silently dropped."""


def _s(v: Any) -> str:
    return v.strip() if isinstance(v, str) else ("" if v is None else str(v).strip())


def validate_interaction_contract(role: Any, metadata: Dict[str, Any]) -> List[str]:
    """Return a list of human-readable contract violations (empty list = valid).

    PURE: no logging, no raising, no mutation — so it is trivially unit-testable and
    callers decide how to react. `role` may be a ContentRole or its string value.
    """
    r = getattr(role, "value", None) or str(role)
    md = metadata or {}
    frm = _s(md.get("from_agent"))
    to = _s(md.get("to_agent"))
    errs: List[str] = []

    if r not in VALID_ROLES:
        return [f"unknown role {r!r} (expected one of {sorted(VALID_ROLES)})"]

    # ── from_agent: every role has an actor (user_prompt's actor is the literal "user") ──
    if not frm:
        errs.append("from_agent missing/empty — the acting agent must be named")
    elif frm in _UNRESOLVED:
        errs.append(f"from_agent is the unresolved sentinel {frm!r} — an emit site did not stamp it")

    if r == "user_prompt":
        if frm and frm != "user":
            errs.append(f"user_prompt from_agent must be 'user', got {frm!r}")
        # to_agent MAY be absent (entry node can be conditional); if present, sanity-check it.
        if to and to in _UNRESOLVED:
            errs.append(f"user_prompt to_agent is the unresolved sentinel {to!r}")
        if to == "user":
            errs.append("user_prompt to_agent must be the entry node, not 'user'")

    elif r == "llm_response":
        if frm == "user":
            errs.append("llm_response from_agent must be the generating agent, not 'user'")
        if to != "user":
            errs.append(f"llm_response to_agent must be 'user' (a response terminates at the user), got {to!r}")

    elif r == "tool_call":
        if not to:
            errs.append("tool_call to_agent (the tool) missing/empty")
        elif to in _UNRESOLVED:
            errs.append(f"tool_call to_agent is the unresolved sentinel {to!r}")
        if frm and to and frm == to:
            errs.append(f"tool_call from==to self-loop ({frm!r}) — the caller and the tool must differ")

    elif r == "agent_to_agent":
        if not to:
            errs.append("agent_to_agent to_agent (the target agent) missing/empty")
        elif to in _UNRESOLVED:
            errs.append(f"agent_to_agent to_agent is the unresolved sentinel {to!r} — an emit site did not stamp the target")
        if frm == "user":
            errs.append("agent_to_agent from_agent must be an agent, not 'user'")
        if to == "user":
            errs.append("agent_to_agent to_agent must be an agent, not 'user'")
        if frm and to and frm == to:
            errs.append(
                f"agent_to_agent from==to SELF-LOOP ({frm!r}) — an agent cannot hand off to "
                f"itself; this is an agent invoking its own tool, govern it as tool_call"
            )

    return errs


def capture_eval(role: Any, metadata: Dict[str, Any], content: Any,
                 request_id: str = "", session_id: str = "") -> None:
    """Append one outbound evaluation to the capture file named by RAI_EVAL_CAPTURE
    (a JSON-lines artifact — the 'metadata.jsonl' a certification run validates). OFF
    unless the env var is set; wrapped so capture can NEVER break an evaluation. Each
    line also carries the contract violations for THIS message, so the artifact is both
    the evidence and the verdict."""
    path = os.getenv("RAI_EVAL_CAPTURE")
    if not path:
        return
    try:
        md = metadata or {}
        rec = {
            "ts":              round(time.time(), 3),
            "request_id":      request_id,
            "session_id":      session_id,
            "role":            getattr(role, "value", None) or str(role),
            "from_agent":      md.get("from_agent"),
            "to_agent":        md.get("to_agent"),
            "tool_name":       md.get("tool_name"),
            "direction":       md.get("direction"),
            "violations":      validate_interaction_contract(role, md),
            "metadata":        md,
            "content_preview": (content if isinstance(content, str) else str(content))[:200],
        }
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, default=str) + "\n")
    except Exception as exc:                       # capture is observability — never fatal
        logger.debug("capture_eval failed (non-fatal): %s", exc)


def _strict() -> bool:
    """Strict mode raises on any violation. ON by default under test runners / CI, so a
    regression fails the suite; OFF in prod by default so a validator false-positive can
    never break governance enforcement (the violation is still logged + counted)."""
    v = os.getenv("RAI_CONTRACT_STRICT")
    if v is not None:
        return v.strip().lower() in ("1", "true", "yes", "on")
    return bool(os.getenv("PYTEST_CURRENT_TEST"))   # auto-strict inside tests


def enforce_contract(role: Any, metadata: Dict[str, Any], request_id: str = "") -> List[str]:
    """Validate at the choke point. ALWAYS loud + counted on a violation; raises in
    strict mode. Returns the violations (empty = clean) so the caller can also tag the
    outbound payload. Never silent — a wrong edge can no longer leave the SDK unnoticed."""
    errs = validate_interaction_contract(role, metadata)
    if not errs:
        return errs
    global CONTRACT_VIOLATIONS
    CONTRACT_VIOLATIONS += 1
    r = getattr(role, "value", None) or str(role)
    md = metadata or {}
    logger.error(
        "RAI contract VIOLATION role=%s request_id=%s from_agent=%r to_agent=%r tool=%r — %s",
        r, request_id, md.get("from_agent"), md.get("to_agent"), md.get("tool_name"),
        "; ".join(errs),
    )
    if _strict():
        raise MetadataContractError(
            f"interaction-metadata contract violated (role={r}, request_id={request_id}): "
            + "; ".join(errs)
        )
    return errs
